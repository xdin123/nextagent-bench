import struct, collections, math

with open("scan_data.stl","rb") as f:
    data=f.read()
ntri=struct.unpack("<I",data[80:84])[0]
tris=[]
off=84
for i in range(ntri):
    v=struct.unpack_from("<9f",data,off+12)
    a=struct.unpack_from("<H",data,off+48)[0]
    tris.append((v,a))
    off+=50

def sv(v):
    x1,y1,z1=v[0],v[1],v[2]; x2,y2,z2=v[3],v[4],v[5]; x3,y3,z3=v[6],v[7],v[8]
    return (x1*(y2*z3-z2*y3)-y1*(x2*z3-z2*x3)+z1*(x2*y3-y2*x3))/6.0

def edge(v,i,j):
    a=(v[i],v[i+1],v[i+2]); b=(v[j],v[j+1],v[j+2])
    return (a,b) if a<b else (b,a)

for M in (42,1,0):
    g=[t for t in tris if t[1]==M]
    signed=sum(sv(t[0]) for t in g)
    ec=collections.Counter()
    for t in g:
        v=t[0]
        for e in (edge(v,0,3),edge(v,3,6),edge(v,6,0)):
            ec[e]+=1
    shared=sum(1 for c in ec.values() if c==2)
    print("M=%d tris=%d signed_vol=%.4f edge_pairs_shared=%d/%d"%(M,len(g),signed,shared,len(ec)))

# vertex gap analysis on M=42
pts=[]
for t in tris:
    if t[1]==42:
        v=t[0]
        for k in (0,3,6):
            pts.append(v[k:k+3])
print("M42 unique vertex tuples:",len(set(pts)))
gaps=[]
for i in range(len(pts)):
    for j in range(i+1,len(pts)):
        d=math.dist(pts[i],pts[j])
        if 1e-6<d<0.5:
            gaps.append(d)
gaps.sort()
print("M42 vertex gaps in (1e-6,0.5): count=%d min=%.8g max=%.8g"%(len(gaps),gaps[0] if gaps else 0,gaps[-1] if gaps else 0))
print("  first 15 gaps:",[round(x,8) for x in gaps[:15]])

# tolerance sweep: connected components by shared vertex (exact tuple match within tol via rounding)
def components(tol):
    def q(v): return (round(v[0]/tol),round(v[1]/tol),round(v[2]/tol))
    parent={}
    def find(x):
        parent.setdefault(x,x)
        while parent[x]!=x:
            parent[x]=parent[parent[x]]; x=parent[x]
        return x
    def union(a,b):
        ra,rb=find(a),find(b)
        if ra!=rb: parent[ra]=rb
    vmap={}
    for t in tris:
        v=t[0]
        for k in (0,3,6):
            kk=q(v[k:k+3])
            if kk not in vmap:
                vmap[kk]=len(vmap)
            else:
                pass
            # union all triangles sharing this quantized vertex
    # build tri->vertex keys
    trikeys=[]
    for t in tris:
        v=t[0]
        trikeys.append([q(v[0:3]),q(v[3:6]),q(v[6:9])])
    # union triangles that share a vertex key
    vkey2tri=collections.defaultdict(list)
    for ti,ks in enumerate(trikeys):
        for kk in ks:
            vkey2tri[kk].append(ti)
    for kk,tl in vkey2tri.items():
        for x in tl[1:]:
            union(tl[0],x)
    comp=collections.Counter(find(ti) for ti in range(ntri))
    # main = max signed volume
    best=None
    for c,ct in comp.items():
        vol=sum(sv(tris[ti][0]) for ti in range(ntri) if find(ti)==c)
        if best is None or abs(vol)>abs(best[1]):
            best=(c,vol)
    return len(comp),best[1]

for tol in (1e-5,5e-5,1e-4,5e-4,1e-3,5e-3,1e-2):
    n,vol=components(tol)
    print("tol=%.0e  components=%d  main_signed_vol=%.4f"%(tol,n,vol))
