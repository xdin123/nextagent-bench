import struct, json, math

path = "scan_data.stl"
with open(path, "rb") as f:
    data = f.read()

header = data[:80]
ntri = struct.unpack("<I", data[80:84])[0]
print("header:", header)
print("triangles:", ntri)
print("expected size:", 84 + 50 * ntri, "actual:", len(data))

tris = []
off = 84
for i in range(ntri):
    normal = struct.unpack_from("<3f", data, off)
    verts = struct.unpack_from("<9f", data, off + 12)
    attr = struct.unpack_from("<H", data, off + 48)[0]
    tris.append((normal, verts, attr))
    off += 50

# Material IDs present
from collections import Counter
mc = Counter(t[2] for t in tris)
print("material id histogram:", dict(mc))

# Union-find over vertices with spatial hashing (tolerance for float mismatch)
TOL = 1e-4
def key(v):
    return (round(v[0] / TOL), round(v[1] / TOL), round(v[2] / TOL))

parent = {}
def find(x):
    parent.setdefault(x, x)
    while parent[x] != x:
        parent[x] = parent[parent[x]]
        x = parent[x]
    return x
def union(a, b):
    ra, rb = find(a), find(b)
    if ra != rb:
        parent[ra] = rb

# map each unique vertex to a representative key (also handle near-duplicates via neighbor keys)
vmap = {}  # key -> canonical vertex index
vlist = []
for ti, (n, v, a) in enumerate(tris):
    for k in range(3):
        vx = v[3*k:3*k+3]
        kk = key(vx)
        # check 27 neighbor cells for a near-duplicate
        found = None
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    nk = (kk[0]+dx, kk[1]+dy, kk[2]+dz)
                    if nk in vmap:
                        found = vmap[nk]
                        break
                    if found: break
                if found: break
            if found: break
        if found is None:
            found = len(vlist)
            vlist.append(vx)
            vmap[kk] = found
        # union with all near-duplicates in neighbor cells
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    nk = (kk[0]+dx, kk[1]+dy, kk[2]+dz)
                    if nk in vmap:
                        union(found, vmap[nk])

# component of each triangle = union of its 3 vertices
comp_of_tri = []
for ti, (n, v, a) in enumerate(tris):
    r0 = find(vmap[key(v[0:3])])
    r1 = find(vmap[key(v[3:6])])
    r2 = find(vmap[key(v[6:9])])
    union(r0, r1)
    union(r0, r2)
    comp_of_tri.append(find(r0))

comps = Counter(comp_of_tri)
print("components (by triangle count):", dict(comps))
largest = comps.most_common(1)[0][0]
print("largest component triangles:", comps[largest])

# Material ID of largest component (mode)
lmat = Counter(tris[i][2] for i in range(ntri) if comp_of_tri[i] == largest)
print("largest component material ids:", dict(lmat))
mat_id = lmat.most_common(1)[0][0]

# Volume of largest component: sum signed tetra volumes
def tri_volume(v):
    # (v0 x v1) . v2 / 6
    x1, y1, z1 = v[0], v[1], v[2]
    x2, y2, z2 = v[3], v[4], v[5]
    x3, y3, z3 = v[6], v[7], v[8]
    return (x1*(y2*z3 - z2*y3) - y1*(x2*z3 - z2*x3) + z1*(x2*y3 - y2*x3)) / 6.0

vol = 0.0
for i in range(ntri):
    if comp_of_tri[i] == largest:
        vol += abs(tri_volume(tris[i][1]))
print("largest component volume (STL units^3):", vol)

# Also volume of all components for reference
for c in comps:
    v = sum(abs(tri_volume(tris[i][1])) for i in range(ntri) if comp_of_tri[i] == c)
    print(f"  comp {c}: {comps[c]} tris, vol={v}")

# Check unit scale: print bounding box of largest component
xs, ys, zs = [], [], []
for i in range(ntri):
    if comp_of_tri[i] == largest:
        v = tris[i][1]
        xs += [v[0], v[3], v[6]]
        ys += [v[1], v[4], v[7]]
        zs += [v[2], v[5], v[8]]
print("bbox:", (min(xs), max(xs)), (min(ys), max(ys)), (min(zs), max(zs)))

densities = {1: 0.10, 10: 7.85, 25: 2.70, 42: 5.55, 99: 11.34}
density = densities[mat_id]
mass = vol * density
print("material_id:", mat_id, "density:", density, "mass:", mass)

report = {"main_part_mass": round(mass, 2), "material_id": mat_id}
with open("mass_report.json", "w") as f:
    json.dump(report, f, indent=1)
print("saved:", report)
