

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import ezdxf
from collections import defaultdict

doc = ezdxf.readfile("workspace/input/ada_bath_input.dxf")
msp = doc.modelspace()

print("DXF version:", doc.dxfversion)
print("Header units:", doc.header.get("$INSUNITS", "n/a"))

layers = defaultdict(lambda: defaultdict(int))
for e in msp:
    layers[e.dxf.layer][e.dxftype()] += 1

for ln in sorted(layers):
    types = dict(layers[ln])
    total = sum(types.values())
    print(f"{ln}: total={total} types={types}")
print("Total entities:", sum(sum(v.values()) for v in layers.values()))
