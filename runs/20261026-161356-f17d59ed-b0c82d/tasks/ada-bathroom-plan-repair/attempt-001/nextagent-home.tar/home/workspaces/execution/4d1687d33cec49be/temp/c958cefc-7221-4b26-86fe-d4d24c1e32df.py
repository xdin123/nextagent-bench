

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import ezdxf
from collections import defaultdict

doc = ezdxf.readfile("workspace/input/ada_bath_input.dxf")
msp = doc.modelspace()

def bbox_of(e):
    try:
        return e.extents
    except Exception:
        return None

for layer in ["WALL", "DOOR", "CLEARANCE"]:
    print("="*20, layer, "="*20)
    for e in msp.query(f'*[layer=="{layer}"]'):
        t = e.dxftype()
        info = []
        if t == "LINE":
            info = [f"start=({e.dxf.start.x:.3f},{e.dxf.start.y:.3f})", f"end=({e.dxf.end.x:.3f},{e.dxf.end.y:.3f})"]
        elif t == "CIRCLE":
            info = [f"c=({e.dxf.center.x:.3f},{e.dxf.center.y:.3f}) r={e.dxf.radius:.3f}"]
        elif t == "ARC":
            info = [f"c=({e.dxf.center.x:.3f},{e.dxf.center.y:.3f}) r={e.dxf.radius:.3f}",
                    f"a0={e.dxf.start_angle:.1f} a1={e.dxf.end_angle:.1f}"]
        elif t in ("POLYLINE", "LWPOLYLINE"):
            try:
                pts = [(p[0], p[1]) for p in e.get_points(format="xy")]
            except Exception:
                pts = []
            closed = e.closed if hasattr(e, "closed") else "?"
            info = [f"closed={closed}", "pts=" + " ".join(f"({x:.3f},{y:.3f})" for x, y in pts[:12])]
        elif t == "SPLINE":
            pts = list(e.control_points)
            info = ["spline ctrl=" + " ".join(f"({p[0]:.3f},{p[1]:.3f})" for p in pts[:12])]
        elif t == "POINT":
            info = [f"p=({e.dxf.location.x:.3f},{e.dxf.location.y:.3f})"]
        elif t == "DIMENSION":
            info = [f"type={e.dxf.dimtype}", f"def=({e.dxf.defpoint.x:.3f},{e.dxf.defpoint.y:.3f})",
                    f"ins=({e.dxf.insert.x:.3f},{e.dxf.insert.y:.3f})"]
            if hasattr(e.dxf, 'text'):
                info.append(f"text={e.dxf.text}")
        print(f"  {t}: " + " | ".join(info))
