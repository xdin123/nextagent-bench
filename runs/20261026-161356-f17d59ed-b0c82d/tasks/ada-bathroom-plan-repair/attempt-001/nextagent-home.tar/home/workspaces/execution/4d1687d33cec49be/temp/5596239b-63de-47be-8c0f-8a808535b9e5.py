

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import ezdxf
doc = ezdxf.readfile("workspace/input/ada_bath_input.dxf")
msp = doc.modelspace()

def poly_pts(e):
    if e.dxftype() == "LWPOLYLINE":
        return [(p[0], p[1]) for p in e.get_points(format="xy")], bool(e.closed)
    # old-style POLYLINE
    pts = [(v.dxf.location.x, v.dxf.location.y) for v in e.vertices]
    return pts, bool(e.closed)

for layer in ["WALL", "DOOR", "CLEARANCE"]:
    print("="*20, layer, "="*20)
    for e in msp.query(f'*[layer=="{layer}"]'):
        if e.dxftype() in ("POLYLINE", "LWPOLYLINE"):
            pts, closed = poly_pts(e)
            print(f"  {e.dxftype()} closed={closed}: " + " ".join(f"({x:.3f},{y:.3f})" for x, y in pts))
