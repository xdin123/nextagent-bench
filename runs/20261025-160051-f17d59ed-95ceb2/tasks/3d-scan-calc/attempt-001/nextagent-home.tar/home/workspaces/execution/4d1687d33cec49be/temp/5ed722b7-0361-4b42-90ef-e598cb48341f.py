
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sys
sys.path.append('workspace/skills/mesh-analysis/scripts')
from mesh_tool import MeshAnalyzer
import collections, json

analyzer = MeshAnalyzer('workspace/scan_data.stl')
comps = analyzer.get_components()

# Per-component report: volume + material IDs present
rows = []
for c in comps:
    vol = analyzer.get_volume(c)
    ids = collections.Counter(t[3] for t in c)
    rows.append((vol, ids))
rows.sort(key=lambda x: x[0], reverse=True)

print("Top 10 components by volume (vol, {mat_id: count}):")
for vol, ids in rows[:10]:
    print(f"  vol={vol:.6f}  ids={dict(ids)}")

largest_vol, largest_ids = rows[0]
assert len(largest_ids) == 1, f"Largest component has non-uniform material IDs: {largest_ids}"
mat_id = list(largest_ids.keys())[0]
density = {1: 0.10, 10: 7.85, 25: 2.70, 42: 5.55, 99: 11.34}[mat_id]
mass = largest_vol * density

print(f"\nlargest component: volume={largest_vol!r}, mat_id={mat_id}, density={density}")
print(f"mass = {mass!r}")

report = {"main_part_mass": mass, "material_id": mat_id}
with open('workspace/mass_report.json', 'w') as f:
    json.dump(report, f, indent=1)
print("\nWrote workspace/mass_report.json:")
print(json.dumps(report, indent=1))
