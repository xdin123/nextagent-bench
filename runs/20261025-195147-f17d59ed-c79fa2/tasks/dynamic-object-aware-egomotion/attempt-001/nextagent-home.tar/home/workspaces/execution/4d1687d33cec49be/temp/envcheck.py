import cv2, numpy
print('cv2', cv2.__version__)
print('numpy', numpy.__version__)
cap = cv2.VideoCapture('workspace/input.mp4')
print('frames', int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 'fps', cap.get(cv2.CAP_PROP_FPS),
      'size', int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
cap.release()
