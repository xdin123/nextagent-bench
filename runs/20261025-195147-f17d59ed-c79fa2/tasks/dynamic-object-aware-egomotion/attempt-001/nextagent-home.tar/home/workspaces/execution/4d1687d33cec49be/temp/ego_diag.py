import cv2, numpy as np, json

VIDEO = 'workspace/input.mp4'
FPS_SAMPLE = 5
cap = cv2.VideoCapture(VIDEO)
n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
fps = cap.get(cv2.CAP_PROP_FPS)
stride = int(round(fps / FPS_SAMPLE))
sample_ids = list(range(0, n, stride))
print('n_frames', n, 'fps', fps, 'stride', stride, 'sample_ids', sample_ids)

grays = []
for fid in sample_ids:
    cap.set(cv2.CAP_PROP_POS_FRAMES, fid)
    ok, frame = cap.read()
    if not ok:
        raise RuntimeError(f'failed to read frame {fid}')
    grays.append(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
cap.release()

H, W = grays[0].shape
print('H,W', H, W)

def estimate(prev, curr):
    p0 = cv2.goodFeaturesToTrack(prev, maxCorners=1200, qualityLevel=0.01,
                                 minDistance=8, blockSize=7)
    p1, st, err = cv2.calcOpticalFlowPyrLK(prev, curr, p0, None,
                                           winSize=(21, 21), maxLevel=3,
                                           criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
    good0 = p0[st == 1]; good1 = p1[st == 1]
    diag = npts=int(len(good0))
    if len(good0) < 20:
        return None, diag
    M, inl = cv2.estimateAffinePartial2D(good0, good1, method=cv2.RANSAC,
                                         ransacReprojThreshold=3.0,
                                         confidence=0.999, maxIters=4000)
    if M is None:
        return None, diag
    inl = inl.reshape(-1).astype(bool)
    s = float(np.sqrt(M[0, 0] ** 2 + M[1, 0] ** 2))
    theta = float(np.arctan2(M[1, 0], M[0, 0]))
    tx, ty = float(M[0, 2]), float(M[1, 2])
    d = good1 - good0
    med_dx = float(np.median(d[inl, 0])) if inl.any() else float(np.median(d[:, 0]))
    med_dy = float(np.median(d[inl, 1])) if inl.any() else float(np.median(d[:, 1]))
    return (M, s, theta, tx, ty, med_dx, med_dy, int(inl.sum())), diag

rows = []
for i in range(len(grays) - 1):
    res, npts = estimate(grays[i], grays[i + 1])
    if res is None:
        print(f'interval {i}->{i+1}: FAILED npts={npts}')
        rows.append(dict(interval=f'{i}->{i+1}', failed=True, npts=npts))
        continue
    M, s, theta, tx, ty, med_dx, med_dy, ninl = res
    rows.append(dict(interval=f'{i}->{i+1}', failed=False, npts=npts, inliers=ninl,
                     tx=round(tx, 3), ty=round(ty, 3), scale=round(s, 5),
                     rot_deg=round(np.degrees(theta), 4),
                     med_dx=round(med_dx, 3), med_dy=round(med_dy, 3)))
    print(f'interval {i}->{i+1}: npts={npts} inl={ninl} tx={tx:8.3f} ty={ty:8.3f} '
          f'scale={s:.5f} rot={np.degrees(theta):8.4f}deg med_dx={med_dx:8.3f} med_dy={med_dy:8.3f}')

with open('temp/ego_diag.json', 'w') as f:
    json.dump({'sample_ids': sample_ids, 'rows': rows}, f, indent=2)
print('saved temp/ego_diag.json')
