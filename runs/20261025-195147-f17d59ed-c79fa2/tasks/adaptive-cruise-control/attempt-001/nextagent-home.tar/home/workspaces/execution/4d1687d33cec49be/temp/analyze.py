import csv
rows = list(csv.DictReader(open('workspace/sensor_data.csv')))
print('total rows:', len(rows))
lead_rows = [r for r in rows if r['lead_speed'].strip() != '']
print('rows with lead vehicle:', len(lead_rows))
if lead_rows:
    print('first lead row:', lead_rows[0])
    print('last lead row:', lead_rows[-1])
    for i, r in enumerate(rows):
        has = r['lead_speed'].strip() != ''
        if i > 0:
            prev = rows[i-1]['lead_speed'].strip() != ''
            if has != prev:
                print(f'transition at t={r["time"]}: lead={"present" if has else "absent"}, distance={r["distance"]}, lead_speed={r["lead_speed"]}, ego_speed={r["ego_speed"]}')
# sample some lead rows
print('--- sample lead rows ---')
for r in lead_rows[:: max(1, len(lead_rows)//15)]:
    print(r)
