
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv
rows = list(csv.DictReader(open('workspace/sensor_data.csv')))
print('total rows:', len(rows))
lead_rows = [r for r in rows if r['lead_speed'].strip() != '']
print('rows with lead vehicle:', len(lead_rows))
if lead_rows:
    print('first lead row:', lead_rows[0])
    print('last lead row:', lead_rows[-1])
    for i, r in enumerate(rows):
        has = r['lead_speed'].strip() != ''
        if i > 0:
            prev = rows[i-1]['lead_speed'].strip() != ''
            if has != prev:
                print(f'transition at t={r["time"]}: lead={"present" if has else "absent"}, distance={r["distance"]}, lead_speed={r["lead_speed"]}')
