import csv
rows = list(csv.DictReader(open('workspace/sensor_data.csv')))
# Print full lead-vehicle segment (t=30..130) sampled every 2s, plus the critical low-distance region
print("t, lead_speed, distance, ego_speed")
for r in rows:
    t = float(r['time'])
    if 30.0 <= t <= 130.0 and r['lead_speed'].strip() != '' and abs(t - round(t*2)/2) < 1e-9:
        print(f"{t:.1f}, {r['lead_speed']}, {r['distance']}, {r['ego_speed']}")
