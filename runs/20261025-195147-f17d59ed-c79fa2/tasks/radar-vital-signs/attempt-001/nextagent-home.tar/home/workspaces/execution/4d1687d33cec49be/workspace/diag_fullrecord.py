"""Full-record PSD (60 s, 1 bpm resolution) to resolve PSD-vs-AC ties.

For each recording, compute the single full-record PSD of the decimated
phase (resolution 1/60 Hz = 1 bpm, zero-padded to ~0.05 bpm) and print the
top peaks in the BR and HR bands with their relative power.
"""
import json
import os
import numpy as np
from scipy.signal import decimate

REC_DIR = "workspace/recordings"
BR_LO, BR_HI = 0.08, 0.5
HR_LO, HR_HI = 0.7, 3.0
FS_TARGET = 50.0


def load_phase(rec_id):
    with open(os.path.join(REC_DIR, f"{rec_id}.json")) as fh:
        meta = json.load(fh)
    n = meta["radar"]["num_samples"]
    raw = np.fromfile(os.path.join(REC_DIR, f"{rec_id}.bin"), dtype="<f4")
    iq = raw[0::2] + 1j * raw[1::2]
    fs = meta["radar"]["sample_rate_hz"]
    iq = iq - iq.mean()
    phase = np.unwrap(np.angle(iq))
    phase = phase - phase.mean()
    q = int(round(fs / FS_TARGET))
    fs_new = fs / q
    return decimate(phase, q=q, ftype="iir", zero_phase=True), fs_new


def full_psd(x, fs):
    x = x - x.mean()
    nfft = 8 * len(x)
    f = np.fft.rfftfreq(nfft, 1.0 / fs)
    p = np.abs(np.fft.rfft(x, nfft)) ** 2
    return f, p


def top_in_band(f, p, lo, hi, k=8):
    m = (f >= lo) & (f <= hi)
    ff, pp = f[m], p[m]
    # merge neighboring bins (peak width ~ a few bins) by taking local maxima
    order = np.argsort(pp)[::-1]
    picked = []
    for i in order:
        if all(abs(ff[i] - pf) > 0.15 for pf, _ in picked):  # >=9 bpm apart
            picked.append((ff[i], pp[i]))
        if len(picked) == k:
            break
    return picked


for i in range(1, 16):
    rec = f"rec_{i:03d}"
    x, fs = load_phase(rec)
    f, p = full_psd(x, fs)
    print(f"\n=== {rec} ===")
    print("  BR band (full-record PSD, top peaks):")
    for fp, pp in top_in_band(f, p, BR_LO, BR_HI, 5):
        print(f"    {fp*60:6.1f} bpm  rel {pp/max(p[(f>=BR_LO)&(f<=BR_HI)]):.3f}")
    print("  HR band (full-record PSD, top peaks):")
    for fp, pp in top_in_band(f, p, HR_LO, HR_HI, 5):
        print(f"    {fp*60:6.1f} bpm  rel {pp/max(p[(f>=HR_LO)&(f<=HR_HI)]):.3f}")
