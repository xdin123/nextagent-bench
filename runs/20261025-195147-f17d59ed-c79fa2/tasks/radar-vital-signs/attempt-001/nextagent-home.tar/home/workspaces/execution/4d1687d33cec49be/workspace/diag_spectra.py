"""Diagnostic: top PSD peaks in HR/BR bands for flagged recordings."""
import json
import os
import numpy as np
from scipy.signal import butter, filtfilt, decimate, welch, find_peaks

REC_DIR = "workspace/recordings"
BR_LO, BR_HI = 0.08, 0.5
HR_LO, HR_HI = 0.7, 3.0
FS_TARGET = 50.0


def load(rec_id):
    with open(os.path.join(REC_DIR, f"{rec_id}.json")) as fh:
        meta = json.load(fh)
    n = meta["radar"]["num_samples"]
    raw = np.fromfile(os.path.join(REC_DIR, f"{rec_id}.bin"), dtype="<f4")
    iq = raw[0::2] + 1j * raw[1::2]
    fs = meta["radar"]["sample_rate_hz"]
    iq = iq - iq.mean()
    phase = np.unwrap(np.angle(iq))
    phase = phase - phase.mean()
    q = int(round(fs / FS_TARGET))
    fs_new = fs / q
    return decimate(phase, q=q, ftype="iir", zero_phase=True), fs_new


def top_peaks(x, fs, lo, hi, k=6):
    nperseg = min(len(x), int(fs * 25))
    f, p = welch(x, fs=fs, nperseg=nperseg, noverlap=nperseg // 2,
                 nfft=8 * nperseg, detrend="constant")
    mask = (f >= lo) & (f <= hi)
    ff, pp = f[mask], p[mask]
    order = np.argsort(pp)[::-1][:k]
    return ff[order], pp[order]


def ac_bpm(x, fs, lo, hi):
    x = x - x.mean()
    ac = np.correlate(x, x, mode="full")
    ac = ac[len(ac) // 2:] / ac[len(ac) // 2]
    lag = int(fs / hi) + np.argmax(ac[int(fs / hi):int(fs / lo)])
    return 60.0 * fs / lag, ac


for rec in ["rec_002", "rec_006", "rec_010", "rec_015", "rec_003", "rec_007"]:
    x, fs = load(rec)
    b_br, a_br = butter(4, [BR_LO, BR_HI], btype="band", fs=fs)
    b_hr, a_hr = butter(4, [HR_LO, HR_HI], btype="band", fs=fs)
    br_sig = filtfilt(b_br, a_br, x)
    hr_sig = filtfilt(b_hr, a_hr, x)

    ff, pp = top_peaks(hr_sig, fs, HR_LO, HR_HI)
    print(f"\n=== {rec} HR band top peaks (Hz, rel power) ===")
    for f, p in zip(ff, pp):
        print(f"  {f*60:6.1f} bpm  {p/pp[0]:.3f}")
    hr_ac, ac = ac_bpm(hr_sig, fs, HR_LO, HR_HI)
    print(f"  AC: {hr_ac:.1f} bpm")
    # AC values at candidate lags near PSD peak
    f0 = ff[0]
    lag0 = int(round(fs / f0))
    print(f"  AC at PSD-peak lag {lag0}: {ac[lag0]:.3f}; max AC in band: {ac[int(fs/HR_HI):int(fs/HR_LO)].max():.3f}")

    ff2, pp2 = top_peaks(br_sig, fs, BR_LO, BR_HI)
    print(f"=== {rec} BR band top peaks (Hz, rel power) ===")
    for f, p in zip(ff2, pp2):
        print(f"  {f*60:6.1f} bpm  {p/pp2[0]:.3f}")
    br_ac, _ = ac_bpm(br_sig, fs, BR_LO, BR_HI)
    print(f"  AC: {br_ac:.1f} bpm")
