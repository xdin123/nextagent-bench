"""CW radar vital-signs extraction: HR & BR from 24 GHz I/Q recordings.

Pipeline (per skill):
  parse I/Q -> clutter removal -> phase unwrap -> decimate to 50 Hz
  -> BR bandpass (0.08-0.5 Hz) + HR bandpass (0.7-3.0 Hz)
  -> zero-padded Welch PSD peak -> HR 2nd-harmonic rejection
  -> autocorrelation cross-check + peak-count sanity check
"""
import json
import os
import numpy as np
from scipy.signal import butter, filtfilt, decimate, welch, find_peaks

REC_DIR = "workspace/recordings"
OUT_CSV = "workspace/results.csv"

BR_LO, BR_HI = 0.08, 0.5    # Hz
HR_LO, HR_HI = 0.7, 3.0     # Hz
FS_TARGET = 50.0


def load_iq(rec_id):
    with open(os.path.join(REC_DIR, f"{rec_id}.json")) as fh:
        meta = json.load(fh)
    n = meta["radar"]["num_samples"]
    raw = np.fromfile(os.path.join(REC_DIR, f"{rec_id}.bin"), dtype="<f4")
    assert raw.size == 2 * n, f"{rec_id}: expected {2*n} floats, got {raw.size}"
    iq = raw[0::2] + 1j * raw[1::2]
    return iq, meta


def peak_freq(x, fs, lo, hi):
    nperseg = min(len(x), int(fs * 25))
    f, p = welch(x, fs=fs, nperseg=nperseg, noverlap=nperseg // 2,
                 nfft=8 * nperseg, detrend="constant")
    mask = (f >= lo) & (f <= hi)
    idx = np.argmax(p[mask])
    return f[mask][idx], f, p


def autocorr_bpm(x, fs, lo, hi):
    x = x - x.mean()
    ac = np.correlate(x, x, mode="full")
    ac = ac[len(ac) // 2:] / ac[len(ac) // 2]
    lag = int(fs / hi) + np.argmax(ac[int(fs / hi):int(fs / lo)])
    return 60.0 * fs / lag, ac


def extract(rec_id):
    iq, meta = load_iq(rec_id)
    fs = meta["radar"]["sample_rate_hz"]

    # 3. clutter removal (before angle)
    iq = iq - iq.mean()

    # 5. phase unwrap
    phase = np.unwrap(np.angle(iq))
    phase = phase - phase.mean()

    # 6. decimate to ~50 Hz
    q = int(round(fs / FS_TARGET))
    fs_new = fs / q
    phase_ds = decimate(phase, q=q, ftype="iir", zero_phase=True)

    # 7. two separate bandpasses
    b_br, a_br = butter(4, [BR_LO, BR_HI], btype="band", fs=fs_new)
    b_hr, a_hr = butter(4, [HR_LO, HR_HI], btype="band", fs=fs_new)
    br_sig = filtfilt(b_br, a_br, phase_ds)
    hr_sig = filtfilt(b_hr, a_hr, phase_ds)

    # 8. PSD peaks
    f_br, f_grid, p_br = peak_freq(br_sig, fs_new, BR_LO, BR_HI)
    f_hr, f_grid, p_hr = peak_freq(hr_sig, fs_new, HR_LO, HR_HI)

    # 9. HR 2nd-harmonic rejection
    f_sub = f_hr / 2.0
    harmonic_fix = False
    if BR_HI < f_sub <= HR_HI:
        p_sub = np.interp(f_sub, f_grid, p_hr)
        p_top = np.interp(f_hr, f_grid, p_hr)
        if p_sub > 0.5 * p_top:
            f_hr = f_sub
            harmonic_fix = True

    # 10. autocorrelation cross-check
    hr_ac, _ = autocorr_bpm(hr_sig, fs_new, HR_LO, HR_HI)
    br_ac, _ = autocorr_bpm(br_sig, fs_new, BR_LO, BR_HI)

    # sanity: peak count ~ rate * minutes
    n_min = len(phase_ds) / fs_new / 60.0
    hr_peaks, _ = find_peaks(hr_sig, height=np.std(hr_sig) * 0.5)
    br_peaks, _ = find_peaks(br_sig, height=np.std(br_sig) * 0.5)

    hr_bpm = f_hr * 60.0
    br_bpm = f_br * 60.0
    return {
        "recording_id": rec_id,
        "hr_bpm": hr_bpm,
        "br_bpm": br_bpm,
        "hr_ac_bpm": hr_ac,
        "br_ac_bpm": br_ac,
        "hr_peak_count": len(hr_peaks),
        "br_peak_count": len(br_peaks),
        "hr_exp_peaks": hr_bpm * n_min,
        "br_exp_peaks": br_bpm * n_min,
        "harmonic_fix": harmonic_fix,
        "hr_ac_diff": abs(hr_ac - hr_bpm),
        "br_ac_diff": abs(br_ac - br_bpm),
    }


def main():
    recs = [f"rec_{i:03d}" for i in range(1, 16)]
    rows = []
    for r in recs:
        res = extract(r)
        rows.append(res)
        print(f"{res['recording_id']}: HR={res['hr_bpm']:.1f} "
              f"(AC {res['hr_ac_bpm']:.1f}, d={res['hr_ac_diff']:.1f}, "
              f"peaks {res['hr_peak_count']}/{res['hr_exp_peaks']:.0f}, "
              f"fix={res['harmonic_fix']}) | "
              f"BR={res['br_bpm']:.1f} "
              f"(AC {res['br_ac_bpm']:.1f}, d={res['br_ac_diff']:.1f}, "
              f"peaks {res['br_peak_count']}/{res['br_exp_peaks']:.0f})")

    # sanity flags
    for res in rows:
        flags = []
        if res["br_bpm"] >= res["hr_bpm"]:
            flags.append("BR>=HR (swapped?)")
        if not (40 <= res["hr_bpm"] <= 180):
            flags.append("HR out of plausible range")
        if not (5 <= res["br_bpm"] <= 40):
            flags.append("BR out of plausible range")
        if res["hr_ac_diff"] > 5:
            flags.append("HR PSD/AC disagree >5bpm (low confidence)")
        if res["br_ac_diff"] > 5:
            flags.append("BR PSD/AC disagree >5bpm (low confidence)")
        if res["hr_peak_count"] > 0 and abs(res["hr_peak_count"] - res["hr_exp_peaks"]) > max(3, 0.25 * res["hr_exp_peaks"]):
            flags.append(f"HR peak count {res['hr_peak_count']} vs ~{res['hr_exp_peaks']:.0f} expected (harmonic error?)")
        if flags:
            print(f"  !! {res['recording_id']}: " + "; ".join(flags))

    with open(OUT_CSV, "w") as fh:
        fh.write("recording_id,heart_rate_bpm,breathing_rate_bpm\n")
        for res in rows:
            fh.write(f"{res['recording_id']},{res['hr_bpm']:.1f},{res['br_bpm']:.1f}\n")
    print(f"\nwrote {OUT_CSV}")


if __name__ == "__main__":
    main()
