"""Resolve BR fundamental vs 2nd-harmonic for slow-breather recordings.

1. Fine spectrum 0-0.15 Hz in 0.25 bpm steps (line width check).
2. Time-domain cycle counting on a wide bandpass (0.03-0.5 Hz):
   count peaks/zero-crossings over 60 s -> dominant period.
3. ACF peak search over lags 8-40 s on the wide-bandpassed signal.
"""
import json
import os
import numpy as np
from scipy.signal import decimate, butter, filtfilt, find_peaks

REC_DIR = "workspace/recordings"
FS_TARGET = 50.0


def load_phase(rec_id):
    with open(os.path.join(REC_DIR, f"{rec_id}.json")) as fh:
        meta = json.load(fh)
    n = meta["radar"]["num_samples"]
    raw = np.fromfile(os.path.join(REC_DIR, f"{rec_id}.bin"), dtype="<f4")
    iq = raw[0::2] + 1j * raw[1::2]
    fs = meta["radar"]["sample_rate_hz"]
    iq = iq - iq.mean()
    phase = np.unwrap(np.angle(iq))
    phase = phase - phase.mean()
    q = int(round(fs / FS_TARGET))
    fs_new = fs / q
    return decimate(phase, q=q, ftype="iir", zero_phase=True), fs_new


for i in range(1, 16):
    rec = f"rec_{i:03d}"
    x, fs = load_phase(rec)

    # fine spectrum
    nfft = 8 * len(x)
    f = np.fft.rfftfreq(nfft, 1.0 / fs)
    p = np.abs(np.fft.rfft(x - x.mean(), nfft)) ** 2
    m = (f >= 0.0) & (f <= 0.15)
    ff, pp = f[m], p[m]
    # print every 0.25 bpm
    step = 0.25 / 60.0
    print(f"\n=== {rec} spectrum 0-0.15 Hz (dB rel max in 0-0.05Hz) ===")
    ref = p[(f >= 0) & (f <= 0.05)].max()
    for t in np.arange(0, 0.15, step):
        i2 = np.argmin(np.abs(ff - t))
        dbv = 10 * np.log10(pp[i2] / ref)
        bar = "#" * max(0, int((dbv + 20) / 2))
        print(f"  {t*60:5.2f} bpm {dbv:6.1f} dB {bar}")

    # wide bandpass 0.03-0.5 Hz
    b, a = butter(4, [0.03, 0.5], btype="band", fs=fs)
    y = filtfilt(b, a, x)
    # peak count
    pk, props = find_peaks(y, height=np.std(y) * 0.3, distance=int(fs * 5))
    if len(pk) >= 2:
        periods = np.diff(pk) / fs
        med_period = np.median(periods)
        print(f"  peaks={len(pk)} median period={med_period:.1f}s -> {60/med_period:.1f} bpm")
    # ACF
    y0 = y - y.mean()
    ac = np.correlate(y0, y0, "full")[len(y0) // 2:]
    ac = ac / ac[0]
    # search lags 5-40 s
    lo, hi = int(fs * 5), int(fs * 40)
    lag = lo + int(np.argmax(ac[lo:hi]))
    print(f"  ACF best lag={lag/fs:.1f}s -> {60/(lag/fs):.1f} bpm (ac={ac[lag]:.2f})")
    # zero crossings
    zc = np.sum(np.diff(np.sign(y0)) != 0)
    print(f"  zero crossings={zc} -> {zc/2*60/60:.1f} cycles/min")
