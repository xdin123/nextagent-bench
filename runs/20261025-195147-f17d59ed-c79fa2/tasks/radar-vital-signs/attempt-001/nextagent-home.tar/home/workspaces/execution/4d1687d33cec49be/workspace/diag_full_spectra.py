"""Full-phase-spectrum diagnostic: break PSD-vs-AC ties for all recordings.

Computes the PSD of the *unfiltered* decimated phase signal (no bandpass
distortion), finds the dominant peak in the HR and BR bands directly, and
compares against the bandpassed-PSD and autocorrelation estimates.
"""
import json
import os
import numpy as np
from scipy.signal import decimate, welch

REC_DIR = "workspace/recordings"
BR_LO, BR_HI = 0.08, 0.5
HR_LO, HR_HI = 0.7, 3.0
FS_TARGET = 50.0


def load_phase(rec_id):
    with open(os.path.join(REC_DIR, f"{rec_id}.json")) as fh:
        meta = json.load(fh)
    n = meta["radar"]["num_samples"]
    raw = np.fromfile(os.path.join(REC_DIR, f"{rec_id}.bin"), dtype="<f4")
    iq = raw[0::2] + 1j * raw[1::2]
    fs = meta["radar"]["sample_rate_hz"]
    iq = iq - iq.mean()
    phase = np.unwrap(np.angle(iq))
    phase = phase - phase.mean()
    q = int(round(fs / FS_TARGET))
    fs_new = fs / q
    return decimate(phase, q=q, ftype="iir", zero_phase=True), fs_new


def band_peak(x, fs, lo, hi):
    nperseg = min(len(x), int(fs * 25))
    f, p = welch(x, fs=fs, nperseg=nperseg, noverlap=nperseg // 2,
                 nfft=8 * nperseg, detrend="constant")
    m = (f >= lo) & (f <= hi)
    ff, pp = f[m], p[m]
    i = np.argmax(pp)
    # prominence vs local median (SNR-ish)
    med = np.median(pp)
    return ff[i], pp[i] / max(med, 1e-30), f, p


def ac_bpm(x, fs, lo, hi):
    x = x - x.mean()
    ac = np.correlate(x, x, mode="full")
    ac = ac[len(ac) // 2:] / ac[len(ac) // 2]
    lag = int(fs / hi) + int(np.argmax(ac[int(fs / hi):int(fs / lo)]))
    return 60.0 * fs / lag


print(f"{'rec':8} | {'HRfull':>7} {'prom':>5} | {'HRac':>6} | {'BRfull':>7} {'prom':>5} | {'BRac':>6} | ratio BRfull/2")
print("-" * 78)
for i in range(1, 16):
    rec = f"rec_{i:03d}"
    x, fs = load_phase(rec)
    hf, hpr, f, p = band_peak(x, fs, HR_LO, HR_HI)
    bf, bpr, _, _ = band_peak(x, fs, BR_LO, BR_HI)
    hac = ac_bpm(x, fs, HR_LO, HR_HI)
    bac = ac_bpm(x, fs, BR_LO, BR_HI)
    print(f"{rec:8} | {hf*60:7.1f} {hpr:5.1f} | {hac:6.1f} | {bf*60:7.1f} {bpr:5.1f} | {bac:6.1f} | {bf*30:6.1f}")
