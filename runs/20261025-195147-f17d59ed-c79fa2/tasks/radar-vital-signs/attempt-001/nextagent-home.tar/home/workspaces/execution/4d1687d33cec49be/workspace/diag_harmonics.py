"""Harmonic-structure analysis on full-record PSD (1 bpm resolution).

For each recording, examine:
  BR: power at candidate f0, f0/2, 2f0, 3f0  (2nd-harmonic dominance check)
  HR: power at candidate f, 2f, 3f           (harmonic-support scoring)
  HR: power at k*BR for k=4..10              (respiration-harmonic impostor check)
dB values relative to the strongest line in the HR band.
"""
import json
import os
import numpy as np
from scipy.signal import decimate

REC_DIR = "workspace/recordings"
BR_LO, BR_HI = 0.08, 0.5
HR_LO, HR_HI = 0.7, 3.0
FS_TARGET = 50.0


def load_phase(rec_id):
    with open(os.path.join(REC_DIR, f"{rec_id}.json")) as fh:
        meta = json.load(fh)
    n = meta["radar"]["num_samples"]
    raw = np.fromfile(os.path.join(REC_DIR, f"{rec_id}.bin"), dtype="<f4")
    iq = raw[0::2] + 1j * raw[1::2]
    fs = meta["radar"]["sample_rate_hz"]
    iq = iq - iq.mean()
    phase = np.unwrap(np.angle(iq))
    phase = phase - phase.mean()
    q = int(round(fs / FS_TARGET))
    fs_new = fs / q
    return decimate(phase, q=q, ftype="iir", zero_phase=True), fs_new


def full_psd(x, fs):
    x = x - x.mean()
    nfft = 8 * len(x)
    f = np.fft.rfftfreq(nfft, 1.0 / fs)
    p = np.abs(np.fft.rfft(x, nfft)) ** 2
    return f, p


def p_at(f, p, target_hz, win=0.004):
    """max power within +-win Hz of target (win ~ 0.5 bpm)."""
    m = (f >= target_hz - win) & (f <= target_hz + win)
    return p[m].max() if m.any() else 0.0


def db(x, ref):
    return 10 * np.log10(x / ref) if x > 0 else -np.inf


for i in range(1, 16):
    rec = f"rec_{i:03d}"
    x, fs = load_phase(rec)
    f, p = full_psd(x, fs)

    # BR candidate: PSD peak in BR band
    mbr = (f >= BR_LO) & (f <= BR_HI)
    br_c = f[mbr][np.argmax(p[mbr])]
    # HR candidate: PSD peak in HR band
    mhr = (f >= HR_LO) & (f <= HR_HI)
    hr_c = f[mhr][np.argmax(p[mhr])]
    ref = p[mhr].max()

    print(f"\n=== {rec}  BR_cand={br_c*60:.1f}  HR_cand={hr_c*60:.1f} bpm ===")
    print(f"  BR structure (dB rel HR-band max): "
          f"f0={db(p_at(f,p,br_c),ref):6.1f}  f0/2={db(p_at(f,p,br_c/2),ref):6.1f}  "
          f"2f0={db(p_at(f,p,2*br_c),ref):6.1f}  3f0={db(p_at(f,p,3*br_c),ref):6.1f}")
    print(f"  HR structure: f={db(p_at(f,p,hr_c),ref):6.1f}  "
          f"2f={db(p_at(f,p,2*hr_c),ref):6.1f}  3f={db(p_at(f,p,3*hr_c),ref):6.1f}")
    kh = "  ".join(f"k{k}={db(p_at(f,p,k*br_c),ref):5.1f}" for k in range(4, 11))
    print(f"  k*BR lines: {kh}")
