
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

from pycbc.waveform import get_td_waveform
import warnings
warnings.filterwarnings('ignore')

delta_t = 1.0/2048.0
for a in ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']:
    for (m1, m2) in [(20, 30), (10, 40)]:  # m1 < m2
        try:
            hp, hc = get_td_waveform(approximant=a, mass1=m1, mass2=m2, delta_t=delta_t, f_lower=20)
            print(f'{a} m1={m1} m2={m2}: OK len={len(hp)}')
        except Exception as e:
            print(f'{a} m1={m1} m2={m2}: {type(e).__name__}: {e}')
