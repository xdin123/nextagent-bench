"""Full matched-filtering grid search.

For each approximant in {SEOBNRv4_opt, IMRPhenomD, TaylorT4}, sweep
mass1, mass2 in 10..40 (integer steps), generate time-domain templates
(f_lower=20 Hz), match against the conditioned strain, and record the
peak |SNR|. Report the strongest (mass1, mass2) per approximant.
"""
import time
import warnings
import multiprocessing as mp
import numpy as np
from pycbc.types import TimeSeries, FrequencySeries
from pycbc.waveform import get_td_waveform
from pycbc.filter import matched_filter

warnings.filterwarnings('ignore')

APPROXIMANTS = ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']
MASSES = list(range(10, 41))  # 10..40 inclusive
F_LOWER = 20.0

# Globals inherited by forked workers
_CONDITIONED = None
_PSD = None


def _init_worker(conditioned, psd):
    global _CONDITIONED, _PSD
    _CONDITIONED = conditioned
    _PSD = psd


def _run_one(args):
    approx, m1, m2 = args
    try:
        hp, hc = get_td_waveform(approximant=approx, mass1=m1, mass2=m2,
                                 delta_t=_CONDITIONED.delta_t, f_lower=F_LOWER)
        hp.resize(len(_CONDITIONED))
        template = hp.cyclic_time_shift(hp.start_time)
        snr = matched_filter(template, _CONDITIONED, psd=_PSD,
                             low_frequency_cutoff=F_LOWER)
        snr = snr.crop(8, 4)
        peak_idx = int(np.argmax(np.abs(snr)))
        peak_snr = float(np.abs(snr[peak_idx]))
        peak_time = float(snr.start_time + peak_idx * snr.delta_t)
        return (approx, m1, m2, peak_snr, peak_time)
    except Exception as e:
        return (approx, m1, m2, -1.0, float('nan'), f'{type(e).__name__}: {e}')


def main():
    global _CONDITIONED, _PSD
    t0 = time.time()
    meta = np.load('temp/condition_meta.npy', allow_pickle=True).item()
    _CONDITIONED = TimeSeries(np.load('temp/conditioned_strain.npy'),
                              delta_t=float(meta['delta_t']))
    _PSD = FrequencySeries(np.load('temp/psd.npy'),
                           delta_f=float(meta['delta_f']))

    jobs = [(a, m1, m2) for a in APPROXIMANTS for m1 in MASSES for m2 in MASSES]
    print(f'Total jobs: {len(jobs)}', flush=True)

    n_workers = min(16, mp.cpu_count())
    results = []
    with mp.Pool(n_workers, initializer=_init_worker,
                 initargs=(_CONDITIONED, _PSD)) as pool:
        for i, res in enumerate(pool.imap_unordered(_run_one, jobs, chunksize=8)):
            results.append(res)
            if (i + 1) % 300 == 0:
                print(f'  {i+1}/{len(jobs)} done ({time.time()-t0:.0f}s)', flush=True)

    # Summarize per approximant
    print(f'\nAll {len(results)} templates done in {time.time()-t0:.1f}s')
    np.save('temp/grid_results.npy',
            np.array([(r[0], r[1], r[2], r[3], r[4]) for r in results],
                    dtype=object), allow_pickle=True)

    for a in APPROXIMANTS:
        rows = [r for r in results if r[0] == a and r[3] >= 0]
        failed = [r for r in results if r[0] == a and r[3] < 0]
        best = max(rows, key=lambda r: r[3])
        print(f'\n{a}: {len(rows)} ok, {len(failed)} failed')
        print(f'  BEST: m1={best[1]} m2={best[2]} total={best[1]+best[2]} '
              f'peak_snr={best[3]:.4f} at t={best[4]:.2f}s')
        top5 = sorted(rows, key=lambda r: -r[3])[:5]
        for r in top5:
            print(f'    m1={r[1]:2d} m2={r[2]:2d} total={r[1]+r[2]:2d} '
                  f'snr={r[3]:8.4f} t={r[4]:7.2f}s')
        if failed:
            print(f'  failed examples: {failed[:3]}')


if __name__ == '__main__':
    main()
