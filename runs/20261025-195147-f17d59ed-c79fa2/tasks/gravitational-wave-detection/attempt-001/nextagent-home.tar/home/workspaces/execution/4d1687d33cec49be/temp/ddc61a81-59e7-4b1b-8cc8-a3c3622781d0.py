
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import inspect
from pycbc.types import TimeSeries, FrequencySeries
print('TimeSeries members:', [m for m in dir(TimeSeries) if not m.startswith('_') and 'from' in m.lower() or m in ('__init__',)])
print()
print('TimeSeries.__init__ sig:', inspect.signature(TimeSeries.__init__))
print()
print('FrequencySeries.__init__ sig:', inspect.signature(FrequencySeries.__init__))
