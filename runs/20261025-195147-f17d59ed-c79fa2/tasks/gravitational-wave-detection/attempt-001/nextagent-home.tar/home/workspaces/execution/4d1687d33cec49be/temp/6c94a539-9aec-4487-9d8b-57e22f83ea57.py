
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import numpy as np

results = np.load('temp/grid_results.npy', allow_pickle=True)
# each element: (approx, m1, m2, peak_snr, peak_time)
rows = [tuple(r) for r in results]

best = {}
for approx, m1, m2, snr, t in rows:
    if snr < 0:
        continue
    if approx not in best or snr > best[approx][0]:
        best[approx] = (snr, m1, m2, t)

order = ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']
lines = ['approximant,snr,total_mass']
for a in order:
    snr, m1, m2, t = best[a]
    total = m1 + m2
    lines.append(f'{a},{snr:.4f},{total}')
    print(f'{a}: snr={snr:.4f} m1={m1} m2={m2} total={total} t={t:.2f}s')

with open('workspace/detection_results.csv', 'w') as f:
    f.write('\n'.join(lines) + '\n')
print('\nWrote workspace/detection_results.csv')
print(open('workspace/detection_results.csv').read())
