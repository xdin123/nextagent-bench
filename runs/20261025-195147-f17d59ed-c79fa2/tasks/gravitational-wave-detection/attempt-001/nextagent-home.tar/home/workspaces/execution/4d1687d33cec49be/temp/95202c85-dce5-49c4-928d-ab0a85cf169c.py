
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

from pycbc.waveform import get_fd_waveform, get_td_waveform, get_available_approximants

avail = get_available_approximants()
for a in ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']:
    print(a, '->', 'available' if a in avail else 'NOT in list')

# Test FD generation with a sample mass pair
delta_f = 1.0/128.0
for a in ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']:
    try:
        hp, hc = get_fd_waveform(approximant=a, mass1=30, mass2=20, delta_f=delta_f, f_lower=20)
        print(f'FD {a}: OK, len={len(hp)}')
    except Exception as e:
        print(f'FD {a}: FAILED - {type(e).__name__}: {e}')

# Test TD generation
delta_t = 1.0/4096.0
for a in ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']:
    try:
        hp, hc = get_td_waveform(approximant=a, mass1=30, mass2=20, delta_t=delta_t, f_lower=20)
        print(f'TD {a}: OK, len={len(hp)}')
    except Exception as e:
        print(f'TD {a}: FAILED - {type(e).__name__}: {e}')
