
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

from pycbc.types import load_timeseries

path = 'workspace/data/PyCBC_T2_2.gwf'
strain = load_timeseries(path, 'H1:TEST-STRAIN')
print('type:', type(strain))
print('sample_rate:', strain.sample_rate)
print('delta_t:', strain.delta_t)
print('duration:', strain.duration, 's')
print('length:', len(strain))
print('start_time:', strain.start_time)
print('stop_time:', strain.stop_time)
print('mean:', float(strain.mean()), 'std:', float(strain.std()))
