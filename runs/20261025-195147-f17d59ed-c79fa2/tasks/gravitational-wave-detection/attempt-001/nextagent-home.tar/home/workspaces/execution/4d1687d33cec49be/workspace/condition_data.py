"""Condition raw detector strain from PyCBC_T2_2.gwf (H1:TEST-STRAIN).

Pipeline (per conditioning skill):
1. High-pass filter at 15 Hz
2. Resample to 2048 Hz
3. Crop 2 s from both ends (filter wraparound)
4. PSD: Welch (4 s segments) -> interpolate -> inverse_spectrum_truncation
"""
import time
import numpy as np
from pycbc.frame import read_frame
from pycbc.filter import highpass, resample_to_delta_t
from pycbc.psd import interpolate, inverse_spectrum_truncation

t0 = time.time()

# --- Load raw strain ---
strain = read_frame('workspace/data/PyCBC_T2_2.gwf', 'H1:TEST-STRAIN')
print(f'Raw: sample_rate={strain.sample_rate} Hz, duration={strain.duration} s, len={len(strain)}')

# --- 1. High-pass filter at 15 Hz ---
strain_hp = highpass(strain, 15.0)
print(f'High-pass 15 Hz done ({time.time()-t0:.1f}s)')

# --- 2. Resample to 2048 Hz ---
delta_t = 1.0 / 2048
strain_rs = resample_to_delta_t(strain_hp, delta_t)
print(f'Resampled to {strain_rs.sample_rate} Hz: duration={strain_rs.duration} s, len={len(strain_rs)} ({time.time()-t0:.1f}s)')

# --- 3. Crop 2 s from both ends ---
conditioned = strain_rs.crop(2, 2)
print(f'Cropped: duration={conditioned.duration} s, len={len(conditioned)} ({time.time()-t0:.1f}s)')

# --- 4. PSD estimation ---
psd_raw = conditioned.psd(4)  # Welch, 4 s segments
psd = interpolate(psd_raw, conditioned.delta_f)
psd = inverse_spectrum_truncation(psd, int(4 * conditioned.sample_rate), low_frequency_cutoff=15)
print(f'PSD: len={len(psd)}, delta_f={psd.delta_f}, freq range {psd.sample_frequencies[0]:.3f}-{psd.sample_frequencies[-1]:.3f} Hz ({time.time()-t0:.1f}s)')

# --- Save for the grid search ---
np.save('temp/conditioned_strain.npy', np.ascontiguousarray(conditioned.numpy(), dtype=np.float64))
np.save('temp/psd.npy', np.ascontiguousarray(psd.numpy(), dtype=np.float64))
meta = {
    'sample_rate': float(conditioned.sample_rate),
    'delta_t': float(conditioned.delta_t),
    'delta_f': float(conditioned.delta_f),
    'duration': float(conditioned.duration),
    'len': int(len(conditioned)),
    'psd_len': int(len(psd)),
    'start_time': float(conditioned.start_time),
}
np.save('temp/condition_meta.npy', np.array(meta, dtype=object), allow_pickle=True)
print('Saved temp/conditioned_strain.npy, temp/psd.npy, temp/condition_meta.npy')
print(f'Total conditioning time: {time.time()-t0:.1f}s')
