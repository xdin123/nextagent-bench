import time
import numpy as np
from pycbc.types import TimeSeries, FrequencySeries
from pycbc.waveform import get_td_waveform
from pycbc.filter import matched_filter

# Load conditioned data
meta = np.load('temp/condition_meta.npy', allow_pickle=True).item()
conditioned = TimeSeries(np.load('temp/conditioned_strain.npy'), delta_t=float(meta['delta_t']))
psd = FrequencySeries(np.load('temp/psd.npy'), delta_f=float(meta['delta_f']))
print(f'conditioned: len={len(conditioned)}, sample_rate={conditioned.sample_rate}')
print(f'psd: len={len(psd)}, delta_f={psd.delta_f}')

def run_one(approximant, mass1, mass2):
    t0 = time.time()
    hp, hc = get_td_waveform(approximant=approximant, mass1=mass1, mass2=mass2,
                             delta_t=conditioned.delta_t, f_lower=20)
    hp.resize(len(conditioned))
    template = hp.cyclic_time_shift(hp.start_time)
    snr = matched_filter(template, conditioned, psd=psd, low_frequency_cutoff=20)
    snr = snr.crop(8, 4)
    peak_idx = int(np.argmax(np.abs(snr)))
    peak_snr = float(np.abs(snr[peak_idx]))
    peak_time = float(snr.start_time + peak_idx * snr.delta_t)
    return peak_snr, peak_time, time.time() - t0

for approx in ['SEOBNRv4_opt', 'IMRPhenomD', 'TaylorT4']:
    for (m1, m2) in [(30, 20), (20, 20)]:
        ps, pt, dt = run_one(approx, m1, m2)
        print(f'{approx} m1={m1} m2={m2}: peak_snr={ps:.3f} at t={pt:.2f}s  ({dt:.2f}s)')
