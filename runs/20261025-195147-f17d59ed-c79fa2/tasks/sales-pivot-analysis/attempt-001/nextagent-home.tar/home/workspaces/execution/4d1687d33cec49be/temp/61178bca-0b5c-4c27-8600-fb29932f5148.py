
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np

# Load sources
pop = pd.read_csv("temp/population_extracted.csv", dtype={'SA2_CODE': str})
inc = pd.read_excel("workspace/income.xlsx", sheet_name='Data', dtype={'SA2_CODE': str})

# Clean 'np' placeholders -> NaN
for col in ['EARNERS', 'MEDIAN_INCOME', 'MEAN_INCOME']:
    inc[col] = pd.to_numeric(inc[col].astype(str).replace('np', np.nan), errors='coerce')

# Join: population (has STATE) + income on SA2_CODE
merged = pop.merge(inc, on='SA2_CODE', how='left', suffixes=('', '_inc'))

# Drop the redundant SA2_NAME from income (should match population's)
if 'SA2_NAME_inc' in merged.columns:
    merged = merged.drop(columns=['SA2_NAME_inc'])

# Column order
merged = merged[['SA2_CODE', 'SA2_NAME', 'STATE', 'POPULATION_2023',
                 'EARNERS', 'MEDIAN_INCOME', 'MEAN_INCOME']]

# Quartiles on MEDIAN_INCOME across all regions
valid = merged['MEDIAN_INCOME'].dropna()
b25, b50, b75 = valid.quantile([0.25, 0.50, 0.75])
print(f"Quartile boundaries: Q1<={b25}, Q2<={b50}, Q3<={b75}")

def assign_quarter(v):
    if pd.isna(v):
        return None
    if v <= b25:
        return 'Q1'
    if v <= b50:
        return 'Q2'
    if v <= b75:
        return 'Q3'
    return 'Q4'

merged['Quarter'] = merged['MEDIAN_INCOME'].apply(assign_quarter)
merged['Total'] = merged['EARNERS'] * merged['MEDIAN_INCOME']

print("\nEnriched shape:", merged.shape)
print("Quarter counts:\n", merged['Quarter'].value_counts().sort_index())
print("\nNulls:\n", merged.isna().sum())
print("\nSample rows:")
print(merged.head(3).to_string())
print(merged.tail(5).to_string())

merged.to_csv("temp/enriched_data.csv", index=False)
print("\nSaved temp/enriched_data.csv")
