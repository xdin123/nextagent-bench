
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np

inc = pd.read_excel("workspace/income.xlsx", sheet_name='Data', dtype={'SA2_CODE': str})

# Convert 'np' to NaN
for col in ['EARNERS', 'MEDIAN_INCOME', 'MEAN_INCOME']:
    inc[col] = pd.to_numeric(inc[col].replace('np', np.nan), errors='coerce')

mi = inc['MEDIAN_INCOME'].dropna()
print("Regions with MEDIAN_INCOME:", len(mi))
print("Unique values:", mi.nunique())
print("Min:", mi.min(), "Max:", mi.max())
print("\nQuartile boundaries (25/50/75):")
print(mi.quantile([0.25, 0.5, 0.75]))

# Check for duplicates at the quantile boundaries (qcut issue)
for q in [0.25, 0.5, 0.75]:
    b = mi.quantile(q)
    print(f"Boundary {q}: {b}, count at boundary = {(mi == b).sum()}")

# Try qcut
try:
    labels = pd.qcut(mi, 4, labels=['Q1','Q2','Q3','Q4'])
    print("\nqcut succeeded:")
    print(labels.value_counts().sort_index())
    print("\nBin ranges:")
    print(pd.qcut(mi, 4, retbins=True, labels=False))
except Exception as e:
    print("qcut failed:", e)
