
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np

sd = pd.read_excel("workspace/demographic_analysis.xlsx", sheet_name="SourceData", dtype={'SA2_CODE': str})
inc = pd.read_excel("workspace/income.xlsx", sheet_name='Data', dtype={'SA2_CODE': str})

m = sd.merge(inc[['SA2_CODE','SA2_NAME']], on='SA2_CODE', suffixes=('_sd','_inc'))
mism = m[m['SA2_NAME_sd'] != m['SA2_NAME_inc']]
print(f"Name mismatches: {len(mism)} of {len(m)}")
print(mism[['SA2_CODE','SA2_NAME_sd','SA2_NAME_inc']].head(15).to_string())

# Are they just whitespace/case differences?
def norm(s):
    return ' '.join(str(s).split()).lower()
mism2 = mism[mism['SA2_NAME_sd'].apply(norm) != mism['SA2_NAME_inc'].apply(norm)]
print(f"\nSubstantive (non-whitespace/case) mismatches: {len(mism2)}")
print(mism2[['SA2_CODE','SA2_NAME_sd','SA2_NAME_inc']].head(15).to_string())
