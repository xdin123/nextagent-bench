
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np

xl = pd.ExcelFile("workspace/demographic_analysis.xlsx")
print("Sheets:", xl.sheet_names)
print("=" * 60)

# Read each pivot sheet (skip title rows)
for sheet, hdr_row in [("Population by State", 3), ("Earners by State", 3),
                       ("Regions by State", 3), ("State Income Quartile", 3)]:
    d = pd.read_excel(xl, sheet_name=sheet, header=hdr_row - 1)
    print(f"\n=== {sheet} ===")
    print(d.to_string(index=False))

# Read SourceData
sd = pd.read_excel(xl, sheet_name="SourceData", dtype={'SA2_CODE': str})
print(f"\n=== SourceData === shape: {sd.shape}")
print("Columns:", list(sd.columns))
print(sd.head(3).to_string())
print("Quarter counts:\n", sd['Quarter'].value_counts(dropna=False).sort_index())
print("Null rows (no income):", sd['EARNERS'].isna().sum())

# ---- Cross-checks against source data ----
print("\n" + "=" * 60)
print("CROSS-CHECKS")
pop = pd.read_csv("temp/population_extracted.csv", dtype={'SA2_CODE': str})
inc = pd.read_excel("workspace/income.xlsx", sheet_name='Data', dtype={'SA2_CODE': str})
for col in ['EARNERS', 'MEDIAN_INCOME']:
    inc[col] = pd.to_numeric(inc[col].astype(str).replace('np', np.nan), errors='coerce')

# 1. Population total
p1 = pd.read_excel(xl, sheet_name="Population by State", header=2)
p1 = p1[p1['STATE'] != 'Grand Total']
src_pop = pop.groupby('STATE')['POPULATION_2023'].sum().sort_index()
ok1 = all(int(p1[p1['STATE']==s]['Sum of POPULATION_2023'].iloc[0]) == src_pop[s] for s in src_pop.index)
print(f"1. Population by State matches source: {ok1}  (total={int(p1['Sum of POPULATION_2023'].sum())})")

# 2. Earners total
p2 = pd.read_excel(xl, sheet_name="Earners by State", header=2)
p2 = p2[p2['STATE'] != 'Grand Total']
merged = pop.merge(inc, on='SA2_CODE', how='left')
src_earn = merged.groupby('STATE')['EARNERS'].sum().sort_index()
ok2 = all(int(p2[p2['STATE']==s]['Sum of EARNERS'].iloc[0]) == int(src_earn[s]) for s in src_earn.index)
print(f"2. Earners by State matches source: {ok2}  (total={int(p2['Sum of EARNERS'].sum())})")

# 3. Region counts
p3 = pd.read_excel(xl, sheet_name="Regions by State", header=2)
p3 = p3[p3['STATE'] != 'Grand Total']
src_cnt = pop.groupby('STATE').size().sort_index()
ok3 = all(int(p3[p3['STATE']==s]['Count of SA2 regions'].iloc[0]) == src_cnt[s] for s in src_cnt.index)
print(f"3. Regions by State matches source: {ok3}  (total={int(p3['Count of SA2 regions'].sum())})")

# 4. Quartile pivot: recompute independently
valid = merged['MEDIAN_INCOME'].dropna()
b = valid.quantile([0.25, 0.5, 0.75])
def q(v):
    if pd.isna(v): return None
    if v <= b[0.25]: return 'Q1'
    if v <= b[0.5]: return 'Q2'
    if v <= b[0.75]: return 'Q3'
    return 'Q4'
merged['Quarter'] = merged['MEDIAN_INCOME'].apply(q)
src_q = merged.dropna(subset=['Quarter']).pivot_table(index='STATE', columns='Quarter', values='EARNERS', aggfunc='sum', fill_value=0)
p4 = pd.read_excel(xl, sheet_name="State Income Quartile", header=2)
p4 = p4[p4['STATE'] != 'Grand Total'].set_index('STATE')
ok4 = True
for s in src_q.index:
    for c in ['Q1','Q2','Q3','Q4']:
        if int(p4.loc[s, c]) != int(src_q.loc[s, c]):
            ok4 = False
print(f"4. State Income Quartile matches recomputed: {ok4}")
print(f"   Grand total earners in pivots: {int(p4[['Q1','Q2','Q3','Q4']].values.sum())} vs source valid: {int(valid.sum())} (income rows w/ earners={int(merged['EARNERS'].sum())})")

# 5. SourceData row count + Total formula check
print(f"5. SourceData rows: {len(sd)} (expect 2454)")
tot_check = (sd['EARNERS'] * sd['MEDIAN_INCOME'] - sd['Total']).abs().max()
print(f"   Max |Total - EARNERS*MEDIAN_INCOME|: {tot_check}")
