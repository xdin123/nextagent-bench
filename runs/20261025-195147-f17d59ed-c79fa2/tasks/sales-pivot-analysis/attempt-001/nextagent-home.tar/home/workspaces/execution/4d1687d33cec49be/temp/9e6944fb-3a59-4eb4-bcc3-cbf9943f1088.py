
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd

pop = pd.read_csv("temp/population_extracted.csv", dtype={'SA2_CODE': str})
inc = pd.read_excel("workspace/income.xlsx", sheet_name='Data', dtype={'SA2_CODE': str})

# Check overlap
pop_codes = set(pop['SA2_CODE'])
inc_codes = set(inc['SA2_CODE'])
print("Pop codes:", len(pop_codes), "Inc codes:", len(inc_codes))
print("In pop not in inc:", len(pop_codes - inc_codes))
print("In inc not in pop:", len(inc_codes - pop_codes))
missing_in_inc = pop[~pop['SA2_CODE'].isin(inc_codes)]
print("\nRegions in population but missing from income:")
print(missing_in_inc.to_string())
extra_in_inc = inc[~inc['SA2_CODE'].isin(pop_codes)]
print("\nRegions in income but missing from population:")
print(extra_in_inc.to_string())

# Check non-numeric values in income columns
for col in ['EARNERS', 'MEDIAN_INCOME', 'MEAN_INCOME']:
    non_num = inc[pd.to_numeric(inc[col], errors='coerce').isna()]
    print(f"\n{col}: {len(non_num)} non-numeric values")
    if len(non_num):
        print(non_num.head(10).to_string())
        print("Unique bad values:", non_num[col].unique()[:10])
