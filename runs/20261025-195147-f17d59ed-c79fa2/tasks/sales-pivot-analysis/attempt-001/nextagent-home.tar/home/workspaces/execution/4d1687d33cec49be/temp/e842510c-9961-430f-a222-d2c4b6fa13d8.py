
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np

sd = pd.read_excel("workspace/demographic_analysis.xlsx", sheet_name="SourceData", dtype={'SA2_CODE': str})

# Total formula check (only where income exists)
mask = sd['EARNERS'].notna() & sd['MEDIAN_INCOME'].notna()
diff = (sd.loc[mask, 'EARNERS'] * sd.loc[mask, 'MEDIAN_INCOME'] - sd.loc[mask, 'Total']).abs().max()
print(f"5. SourceData rows: {len(sd)} (expect 2454)")
print(f"   Total = EARNERS x MEDIAN_INCOME, max abs diff: {diff}")
print(f"   Rows with income: {mask.sum()}, rows without (null): {(~mask).sum()}")

# Confirm the 49 nulls = 45 'np' placeholders + 4 Other Territories
inc = pd.read_excel("workspace/income.xlsx", sheet_name='Data', dtype={'SA2_CODE': str})
np_count = inc['EARNERS'].astype(str).str.strip().eq('np').sum()
print(f"   Source 'np' placeholders: {np_count}; + 4 Other Territories = {np_count + 4} (expect 49)")

# Confirm SourceData STATE matches population source
pop = pd.read_csv("temp/population_extracted.csv", dtype={'SA2_CODE': str})
m = sd.merge(pop[['SA2_CODE','STATE']], on='SA2_CODE', suffixes=('_sd','_pop'))
state_match = (m['STATE_sd'] == m['STATE_pop']).all()
print(f"6. SourceData STATE matches population PDF for all {len(m)} rows: {state_match}")

# Confirm SA2_NAME consistency (population vs income)
inc2 = inc[['SA2_CODE','SA2_NAME']]
m2 = sd.merge(inc2, on='SA2_CODE', suffixes=('_sd','_inc'))
name_match = (m2['SA2_NAME_sd'] == m2['SA2_NAME_inc']).all()
print(f"7. SA2_NAME consistent between PDF and Excel: {name_match}")

print("\nAll checks complete.")
