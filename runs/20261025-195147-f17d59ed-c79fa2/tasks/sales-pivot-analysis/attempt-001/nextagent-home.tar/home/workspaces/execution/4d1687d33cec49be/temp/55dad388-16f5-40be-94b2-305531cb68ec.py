
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

df = pd.read_csv("temp/enriched_data.csv", dtype={'SA2_CODE': str})
# None strings from CSV -> NaN for Quarter
df['Quarter'] = df['Quarter'].replace('None', np.nan)
for col in ['EARNERS', 'MEDIAN_INCOME', 'MEAN_INCOME', 'Total']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

valid = df['MEDIAN_INCOME'].dropna()
b25, b50, b75 = valid.quantile([0.25, 0.50, 0.75])

# ---- Build pivot data ----
# 1. Population by State
p1 = df.groupby('STATE')['POPULATION_2023'].sum().reset_index()
p1.columns = ['STATE', 'Sum of POPULATION_2023']
p1 = p1.sort_values('STATE').reset_index(drop=True)

# 2. Earners by State
p2 = df.groupby('STATE')['EARNERS'].sum().reset_index()
p2.columns = ['STATE', 'Sum of EARNERS']
p2 = p2.sort_values('STATE').reset_index(drop=True)

# 3. Regions by State (count of SA2 regions)
p3 = df.groupby('STATE').size().reset_index(name='Count of SA2 regions')
p3.columns = ['STATE', 'Count of SA2 regions']
p3 = p3.sort_values('STATE').reset_index(drop=True)

# 4. State Income Quartile: rows STATE, cols Q1-Q4, values Sum of EARNERS
p4 = df.dropna(subset=['Quarter']).pivot_table(
    index='STATE', columns='Quarter', values='EARNERS', aggfunc='sum', fill_value=0)
p4 = p4.reindex(columns=['Q1', 'Q2', 'Q3', 'Q4'], fill_value=0)
p4 = p4.reset_index().sort_values('STATE').reset_index(drop=True)
print("Pivot 4:\n", p4.to_string())

# ---- Styles ----
header_fill = PatternFill("solid", fgColor="4472C4")
header_font = Font(bold=True, color="FFFFFF")
title_font = Font(bold=True, size=12)
thin = Side(style="thin", color="BFBFBF")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
total_fill = PatternFill("solid", fgColor="D9E1F2")
total_font = Font(bold=True)

def style_header(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        cell.border = border

def style_body(ws, r1, r2, ncols, num_fmts):
    for r in range(r1, r2 + 1):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=r, column=c)
            cell.border = border
            if num_fmts and c <= len(num_fmts) and num_fmts[c-1]:
                cell.number_format = num_fmts[c-1]

def autofit(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

wb = Workbook()

# ===== Sheet 1: Population by State =====
ws = wb.active
ws.title = "Population by State"
ws["A1"] = "Population by State"
ws["A1"].font = title_font
ws.append([])
ws.append(["STATE", "Sum of POPULATION_2023"])
style_header(ws, 3, 2)
for _, row in p1.iterrows():
    ws.append([row['STATE'], int(row['Sum of POPULATION_2023'])])
n = len(p1)
style_body(ws, 4, 3 + n, 2, [None, '#,##0'])
# Grand total row
ws.append(["Grand Total", int(p1['Sum of POPULATION_2023'].sum())])
for c in range(1, 3):
    cell = ws.cell(row=4 + n, column=c)
    cell.fill = total_fill; cell.font = total_font; cell.border = border
ws.cell(row=4 + n, column=2).number_format = '#,##0'
autofit(ws, [30, 24])
ws.freeze_panes = "A4"

# ===== Sheet 2: Earners by State =====
ws = wb.create_sheet("Earners by State")
ws["A1"] = "Earners by State"
ws["A1"].font = title_font
ws.append([])
ws.append(["STATE", "Sum of EARNERS"])
style_header(ws, 3, 2)
for _, row in p2.iterrows():
    ws.append([row['STATE'], None if pd.isna(row['Sum of EARNERS']) else int(row['Sum of EARNERS'])])
n = len(p2)
style_body(ws, 4, 3 + n, 2, [None, '#,##0'])
ws.append(["Grand Total", int(p2['Sum of EARNERS'].sum())])
for c in range(1, 3):
    cell = ws.cell(row=4 + n, column=c)
    cell.fill = total_fill; cell.font = total_font; cell.border = border
ws.cell(row=4 + n, column=2).number_format = '#,##0'
autofit(ws, [30, 18])
ws.freeze_panes = "A4"

# ===== Sheet 3: Regions by State =====
ws = wb.create_sheet("Regions by State")
ws["A1"] = "Regions by State (Count of SA2 regions)"
ws["A1"].font = title_font
ws.append([])
ws.append(["STATE", "Count of SA2 regions"])
style_header(ws, 3, 2)
for _, row in p3.iterrows():
    ws.append([row['STATE'], int(row['Count of SA2 regions'])])
n = len(p3)
style_body(ws, 4, 3 + n, 2, [None, '#,##0'])
ws.append(["Grand Total", int(p3['Count of SA2 regions'].sum())])
for c in range(1, 3):
    cell = ws.cell(row=4 + n, column=c)
    cell.fill = total_fill; cell.font = total_font; cell.border = border
ws.cell(row=4 + n, column=2).number_format = '#,##0'
autofit(ws, [30, 22])
ws.freeze_panes = "A4"

# ===== Sheet 4: State Income Quartile =====
ws = wb.create_sheet("State Income Quartile")
ws["A1"] = "State Income Quartile (Sum of EARNERS by MEDIAN_INCOME quartile)"
ws["A1"].font = title_font
ws.append([])
ws.append(["STATE", "Q1", "Q2", "Q3", "Q4"])
style_header(ws, 3, 5)
for _, row in p4.iterrows():
    ws.append([row['STATE'], int(row['Q1']), int(row['Q2']), int(row['Q3']), int(row['Q4'])])
n = len(p4)
style_body(ws, 4, 3 + n, 5, [None, '#,##0', '#,##0', '#,##0', '#,##0'])
ws.append(["Grand Total", int(p4['Q1'].sum()), int(p4['Q2'].sum()), int(p4['Q3'].sum()), int(p4['Q4'].sum())])
for c in range(1, 6):
    cell = ws.cell(row=4 + n, column=c)
    cell.fill = total_fill; cell.font = total_font; cell.border = border
    if c > 1:
        cell.number_format = '#,##0'
autofit(ws, [30, 14, 14, 14, 14])
ws.freeze_panes = "B4"
# Note about quartile boundaries
note_row = 6 + n
ws.cell(row=note_row, column=1, value=f"Quartile boundaries (MEDIAN_INCOME): Q1 ≤ {b25:,.0f} | Q2 ≤ {b50:,.0f} | Q3 ≤ {b75:,.0f} | Q4 > {b75:,.0f}")
ws.cell(row=note_row, column=1).font = Font(italic=True, size=9, color="808080")

# ===== Sheet 5: SourceData =====
ws = wb.create_sheet("SourceData")
cols = ['SA2_CODE', 'SA2_NAME', 'STATE', 'POPULATION_2023', 'EARNERS', 'MEDIAN_INCOME', 'MEAN_INCOME', 'Quarter', 'Total']
ws.append(cols)
style_header(ws, 1, len(cols))
for _, row in df.iterrows():
    ws.append([
        row['SA2_CODE'],
        row['SA2_NAME'],
        row['STATE'],
        int(row['POPULATION_2023']),
        None if pd.isna(row['EARNERS']) else int(row['EARNERS']),
        None if pd.isna(row['MEDIAN_INCOME']) else float(row['MEDIAN_INCOME']),
        None if pd.isna(row['MEAN_INCOME']) else float(row['MEAN_INCOME']),
        None if pd.isna(row['Quarter']) else row['Quarter'],
        None if pd.isna(row['Total']) else float(row['Total']),
    ])
style_body(ws, 2, len(df) + 1, len(cols),
           [None, None, None, '#,##0', '#,##0', '#,##0', '#,##0', None, '#,##0'])
autofit(ws, [12, 32, 24, 16, 12, 15, 14, 9, 16])
ws.freeze_panes = "A2"
ws.auto_filter.ref = f"A1:I{len(df) + 1}"

wb.save("workspace/demographic_analysis.xlsx")
print("Saved workspace/demographic_analysis.xlsx")
print("Sheets:", wb.sheetnames)
