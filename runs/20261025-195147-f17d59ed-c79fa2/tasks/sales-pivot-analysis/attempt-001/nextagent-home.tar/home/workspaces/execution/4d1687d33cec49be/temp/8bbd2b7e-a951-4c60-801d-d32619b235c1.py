
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pdfplumber
import pandas as pd

rows = []
with pdfplumber.open("workspace/population.pdf") as pdf:
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            if not table:
                continue
            header = [str(c).strip() if c else '' for c in table[0]]
            if 'SA2_CODE' in header:
                # header row: find column indices
                for row in table[1:]:
                    rows.append(row)
            else:
                # continuation: all rows are data
                for row in table:
                    rows.append(row)

df = pd.DataFrame(rows, columns=['SA2_CODE', 'SA2_NAME', 'STATE', 'POPULATION_2023'])
print("Total rows:", len(df))
print("Unique SA2_CODE:", df['SA2_CODE'].nunique())
print("States:", df['STATE'].unique())
# check for any nulls or bad data
print("Nulls per col:\n", df.isna().sum())
# check population values are numeric
df['POPULATION_2023'] = pd.to_numeric(df['POPULATION_2023'], errors='coerce')
print("Non-numeric population count:", df['POPULATION_2023'].isna().sum())
print(df.head())
print(df.tail())
# any duplicate codes?
dups = df[df.duplicated('SA2_CODE', keep=False)]
print("Duplicate SA2_CODE rows:", len(dups))
df.to_csv("temp/population_extracted.csv", index=False)
print("Saved to temp/population_extracted.csv")
