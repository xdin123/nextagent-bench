
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
mes = pd.read_csv("workspace/data/mes_log.csv", dtype=str)
mes["conveyor_speed_cm_min"] = mes.conveyor_speed_cm_min.astype(float)
mes["board_length_cm"] = mes.board_length_cm.astype(float)
mes["loading_factor"] = mes.loading_factor.astype(float)
mes["boards_per_min"] = mes.boards_per_min.astype(float)

print("conveyor_speed_cm_min overall range:", mes.conveyor_speed_cm_min.min(), "-", mes.conveyor_speed_cm_min.max())
print("\nPer-family conveyor speed ranges:")
print(mes.groupby("board_family")["conveyor_speed_cm_min"].agg(["min","max","count"]))
print("\nPer-family board_length_cm:")
print(mes.groupby("board_family")["board_length_cm"].agg(["min","max","unique"]))
print("\nPer-family loading_factor:", mes.groupby("board_family")["loading_factor"].unique().to_dict())
print("Per-family boards_per_min:", mes.groupby("board_family")["boards_per_min"].unique().to_dict())
print("\noven_model per family:", mes.groupby("board_family")["oven_model"].unique().to_dict())
