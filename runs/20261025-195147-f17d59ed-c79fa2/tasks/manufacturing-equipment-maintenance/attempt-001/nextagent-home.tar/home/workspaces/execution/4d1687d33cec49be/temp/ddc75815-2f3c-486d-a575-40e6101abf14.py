
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
df = pd.read_csv("workspace/data/test_defects.csv", dtype=str)
print("Columns:", list(df.columns))
print("Rows:", len(df), "unique runs:", df.run_id.nunique())
print("\ninspection_stage:", df.inspection_stage.unique())
print("defect_type:", df.defect_type.unique())
print("severity:", df.severity.unique())
print("\nSample:")
print(df.head(12).to_string())
print("\nPer-run record counts:")
print(df.groupby("run_id").size().describe())
print("\nfp_yield_pct range:", pd.to_numeric(df.fp_yield_pct).min(), pd.to_numeric(df.fp_yield_pct).max())
print("count range:", pd.to_numeric(df.count).min(), pd.to_numeric(df.count).max())
