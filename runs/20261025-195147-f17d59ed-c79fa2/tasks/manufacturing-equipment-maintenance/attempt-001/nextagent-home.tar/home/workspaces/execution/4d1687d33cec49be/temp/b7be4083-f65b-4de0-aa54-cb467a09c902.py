
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd, os
DATA = "workspace/data"
mes = pd.read_csv(f"{DATA}/mes_log.csv", dtype={"run_id":str,"board_id":str,"machine_id":str})
tc = pd.read_csv(f"{DATA}/thermocouples.csv", dtype={"run_id":str,"board_id":str,"tc_id":str})
df_ = pd.read_csv(f"{DATA}/test_defects.csv", dtype={"run_id":str,"lot_id":str})

print("MES rows:", len(mes), "unique runs:", mes.run_id.nunique(), "unique boards:", mes.board_id.nunique())
print("families:", sorted(mes.board_family.unique()))
print("liquidus values:", sorted(mes.solder_liquidus_c.unique()))
print("conveyor speed range:", mes.conveyor_speed_cm_min.min(), mes.conveyor_speed_cm_min.max())
print("board_length_cm:", mes.groupby("board_family")["board_length_cm"].unique().to_dict())
print("loading_factor:", mes.groupby("board_family")["loading_factor"].unique().to_dict())
print("boards_per_min:", mes.groupby("board_family")["boards_per_min"].unique().to_dict())
print()
print("TC rows:", len(tc), "runs in tc:", tc.run_id.nunique())
print("tc per run:", tc.groupby("run_id").size().describe())
print("tc_ids:", sorted(tc.tc_id.unique()))
print("tc_location:", tc.groupby("tc_id")["tc_location"].unique().to_dict())
print("zone range:", tc.zone_id.min(), tc.zone_id.max())
print("time range:", tc.time_s.min(), tc.time_s.max())
print("temp range:", tc.temp_c.min(), tc.temp_c.max())
print()
print("runs in mes not in tc:", sorted(set(mes.run_id) - set(tc.run_id)))
print("runs in tc not in mes:", sorted(set(tc.run_id) - set(mes.run_id)))
print()
print("Defect rows:", len(df_), "runs:", df_.run_id.nunique())
print(df_.inspection_stage.unique(), df_.defect_type.unique())
print(df_[["run_id","defect_type","severity","count","units_tested","units_pass","fp_yield_pct"]].head(10).to_string())
