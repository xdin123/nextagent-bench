
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
df = pd.read_csv("workspace/data/test_defects.csv", dtype=str)
summ = df[df.inspection_stage=="SUMMARY"]
print("SUMMARY rows:", len(summ), "unique runs:", summ.run_id.nunique())
print(summ[["run_id","count","units_tested","units_pass","units_rework","units_scrap","fp_yield_pct"]].head(8).to_string())
# check all runs have exactly one SUMMARY
print("\nSUMMARY per run:", summ.groupby("run_id").size().value_counts().to_dict())
# any run missing from defects?
mes = pd.read_csv("workspace/data/mes_log.csv", dtype=str)
print("runs without SUMMARY:", sorted(set(mes.run_id)-set(summ.run_id)))
