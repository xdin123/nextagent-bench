
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
mes = pd.read_csv("workspace/data/mes_log.csv", dtype={"run_id":str,"board_id":str,"machine_id":str})
print("Columns:", list(mes.columns))
print("\nUnique liquidus values:", sorted(mes.solder_liquidus_c.unique()))
print("\nSample rows:")
print(mes[["run_id","board_family","board_length_cm","boards_per_min","loading_factor","conveyor_speed_cm_min","solder_liquidus_c"]].head(10).to_string())
print("\nPer-family board_length_cm:", mes.groupby("board_family")["board_length_cm"].unique().to_dict())
print("Per-family boards_per_min:", mes.groupby("board_family")["boards_per_min"].unique().to_dict())
print("Per-family loading_factor:", mes.groupby("board_family")["loading_factor"].unique().to_dict())
print("Per-family liquidus:", mes.groupby("board_family")["solder_liquidus_c"].unique().to_dict())
print("\nTotal runs:", mes.run_id.nunique())
print("Runs per family:", mes.groupby("board_family")["run_id"].nunique().to_dict())
