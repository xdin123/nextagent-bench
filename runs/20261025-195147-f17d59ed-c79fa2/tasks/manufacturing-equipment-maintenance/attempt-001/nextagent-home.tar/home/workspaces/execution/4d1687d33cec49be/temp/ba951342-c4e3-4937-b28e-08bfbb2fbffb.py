
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
mes = pd.read_csv("workspace/data/mes_log.csv", dtype=str)
print("oven_model values:", mes.oven_model.value_counts().to_dict())
print("machine_id values:", mes.machine_id.value_counts().to_dict())
print("\npaste_type:", mes.paste_type.value_counts().to_dict())
print("\nrecipe_id:", mes.recipe_id.value_counts().to_dict())
print("\ndowntime_s range:", pd.to_numeric(mes.downtime_s).describe())
