
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
tc = pd.read_csv("workspace/data/thermocouples.csv", dtype=str)
print(tc.groupby(["tc_id","tc_location"]).size())
print("\nTCs per run:")
print(tc.groupby("run_id")["tc_id"].nunique().value_counts().to_dict())
print("\nboards per run:")
print(tc.groupby("run_id")["board_id"].nunique().value_counts().to_dict())
print("\nSample TC rows for R0001:")
print(tc[tc.run_id=="R0001"][["tc_id","tc_location","board_id","zone_id","time_s","temp_c"]].head(12).to_string())
