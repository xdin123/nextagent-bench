
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import json, math

with open('workspace/data.json') as f:
    data = json.load(f)

vehicle_count = data['vehicle_count']
vehicle_capacity = data['vehicle_capacity']
penalty_weight = data['penalty_weight']
stations = data['stations']
print(f"vehicles={vehicle_count}, capacity={vehicle_capacity}, penalty={penalty_weight}, stations={len(stations)}")
print()
print(f"{'id':>4} {'target':>7} {'init':>5} {'cap':>4} {'maxPU':>6} {'maxDO':>6} {'feas1':>6}")
tot_pu_target = 0
tot_do_target = 0
for s in stations:
    t = s['net_rebalancing_target']
    init = s['initial_bikes']
    cap = s['station_capacity']
    max_pu = min(init, vehicle_capacity)          # single-vehicle pickup cap
    max_do = min(cap - init, vehicle_capacity)    # single-vehicle dropoff cap
    if t > 0:
        tot_pu_target += t
        feas = "YES" if max_pu >= t else f"NO(need{t-max_pu}more)"
    else:
        tot_do_target += -t
        feas = "YES" if max_do >= -t else f"NO(need{-t-max_do}more)"
    print(f"{s['id']:>4} {t:>7} {init:>5} {cap:>4} {max_pu:>6} {max_do:>6} {feas:>12}")

print()
print(f"total pickup target = {tot_pu_target}")
print(f"total dropoff target = {tot_do_target}")
print(f"net (pu - do) = {tot_pu_target - tot_do_target}")

# check pyscipopt
try:
    from pyscipopt import Model
    print("\nPySCIPOpt available")
except ImportError as e:
    print("\nPySCIPOpt NOT available:", e)
