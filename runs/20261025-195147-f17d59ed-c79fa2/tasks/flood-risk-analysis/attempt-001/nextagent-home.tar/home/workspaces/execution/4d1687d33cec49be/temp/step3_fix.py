"""Fix: restrict flood-day counting to 2025-04-01..2025-04-07 only (USGS returned Apr 8 data too)."""
import csv
import json
import os

DATES = [f"2025-04-0{d}" for d in range(1, 8)]

with open("temp/nws_thresholds.json") as f:
    thresholds = json.load(f)
with open("temp/usgs_daily_max.json") as f:
    daily_max = json.load(f)

results = []
changed = []
for sid, days in daily_max.items():
    if sid not in thresholds:
        continue
    fs = thresholds[sid]["flood"]
    # old count (all days incl. Apr 8)
    old_count = sum(1 for v in days.values() if v is not None and v >= fs)
    # new count (Apr 1-7 only)
    new_count = sum(
        1 for d in DATES
        if d in days and days[d] is not None and days[d] >= fs
    )
    if old_count != new_count:
        changed.append((sid, old_count, new_count, days.get("2025-04-08"), fs))
    if new_count > 0:
        results.append({"station_id": sid, "flood_days": new_count})

results.sort(key=lambda r: (-r["flood_days"], r["station_id"]))

os.makedirs("workspace/output", exist_ok=True)
out_path = "workspace/output/flood_results.csv"
with open(out_path, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["station_id", "flood_days"])
    for r in results:
        w.writerow([r["station_id"], r["flood_days"]])

print(f"Stations with >=1 flood day (Apr 1-7 only): {len(results)}")
print(f"Total flood days: {sum(r['flood_days'] for r in results)}")
print(f"\nStations whose count changed after excluding Apr 8: {len(changed)}")
for sid, old, new, apr8, fs in changed:
    print(f"  {sid}: {old} -> {new} (Apr 8 max={apr8}, flood stage={fs})")
print(f"\nFinal rows:")
for r in results:
    print(f"  {r['station_id']},{r['flood_days']}")
