"""Sanity check: re-verify a couple of stations from raw data."""
import json
from dataretrieval import nwis
import pandas as pd

with open("temp/nws_thresholds.json") as f:
    thresholds = json.load(f)

for sid in ["04101800", "04117500", "04119000"]:
    df, meta = nwis.get_iv(sites=sid, start="2025-04-01", end="2025-04-07", parameterCd="00065")
    gage_col = [c for c in df.columns if "00065" in str(c) and "_cd" not in str(c)]
    daily = pd.to_numeric(df[gage_col[0]], errors="coerce").resample("D").max()
    fs = thresholds[sid]["flood"]
    print(f"\n{sid} (flood stage {fs} ft):")
    for d, v in daily.items():
        flag = "FLOOD" if v >= fs else ""
        print(f"  {d.date()}: {v:.2f} {flag}")
