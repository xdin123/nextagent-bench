"""Step 3: Detect flood days (daily max >= NWS flood stage) and write output CSV."""
import csv
import json
import os

with open("temp/nws_thresholds.json") as f:
    thresholds = json.load(f)
with open("temp/usgs_daily_max.json") as f:
    daily_max = json.load(f)

results = []
for sid, days in daily_max.items():
    if sid not in thresholds:
        continue
    fs = thresholds[sid]["flood"]
    flood_days = sum(1 for v in days.values() if v is not None and v >= fs)
    if flood_days > 0:
        results.append({"station_id": sid, "flood_days": flood_days, "flood_stage": fs})

# Sort by flood days descending, then station id for determinism
results.sort(key=lambda r: (-r["flood_days"], r["station_id"]))

os.makedirs("workspace/output", exist_ok=True)
out_path = "workspace/output/flood_results.csv"
with open(out_path, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["station_id", "flood_days"])
    for r in results:
        w.writerow([r["station_id"], r["flood_days"]])

print(f"Stations with >=1 flood day: {len(results)} / {len(daily_max)}")
print(f"Total flood days: {sum(r['flood_days'] for r in results)}")
print(f"Written to {out_path}")
print("\nTop 10:")
for r in results[:10]:
    print(f"  {r['station_id']}: {r['flood_days']} days (flood stage {r['flood_stage']} ft)")
