import urllib.request
for url in [
    "https://water.noaa.gov/resources/downloads/reports/nwps_all_gauges_report.csv",
    "https://waterservices.usgs.gov/nwis/iv/?format=rdb&sites=04119000&parameterCd=00065&startDT=2025-04-01&endDT=2025-04-02",
]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            head = r.read(200)
        print("OK", len(head), url[:60])
    except Exception as e:
        print("FAIL", repr(e), url[:60])
