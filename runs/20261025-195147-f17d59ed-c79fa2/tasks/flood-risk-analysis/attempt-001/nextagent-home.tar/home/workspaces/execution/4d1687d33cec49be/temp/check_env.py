import importlib
for m in ["dataretrieval", "pandas", "urllib.request", "requests"]:
    try:
        mod = importlib.import_module(m)
        print(m, "OK", getattr(mod, "__version__", ""))
    except Exception as e:
        print(m, "MISSING", repr(e))
