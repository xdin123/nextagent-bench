"""Step 2: Download USGS instantaneous gage height (00065) for all stations, Apr 1-7 2025.
Saves daily-max aggregation per station to temp/usgs_daily_max.json."""
import json
import time
import pandas as pd
from dataretrieval import nwis

START = "2025-04-01"
END = "2025-04-07"

with open("workspace/data/michigan_stations.txt") as f:
    station_ids = [line.strip() for line in f if line.strip()]

daily_max = {}
failed = []
for i, sid in enumerate(station_ids, 1):
    ok = False
    for attempt in range(3):
        try:
            df, meta = nwis.get_iv(
                sites=sid,
                start=START,
                end=END,
                parameterCd="00065",
            )
            if df is not None and len(df) > 0:
                gage_col = [c for c in df.columns if "00065" in str(c) and "_cd" not in str(c)]
                if gage_col:
                    levels = pd.to_numeric(df[gage_col[0]], errors="coerce")
                    daily = levels.resample("D").max()
                    daily_max[sid] = {
                        str(d.date()): (None if pd.isna(v) else float(v))
                        for d, v in daily.items()
                    }
                    ok = True
                    break
            else:
                failed.append(sid)
                break  # no data, no point retrying
        except Exception as e:
            if attempt == 2:
                failed.append(sid)
                print(f"  FAILED {sid}: {repr(e)[:120]}")
            time.sleep(2 * (attempt + 1))
    if i % 10 == 0 or i == len(station_ids):
        print(f"progress {i}/{len(station_ids)} (ok={len(daily_max)}, failed={len(failed)})")
    time.sleep(0.4)

with open("temp/usgs_daily_max.json", "w") as f:
    json.dump(daily_max, f)
print(f"\nDone. Stations with data: {len(daily_max)}, failed/empty: {len(failed)}")
if failed:
    print("Failed stations:", failed)
