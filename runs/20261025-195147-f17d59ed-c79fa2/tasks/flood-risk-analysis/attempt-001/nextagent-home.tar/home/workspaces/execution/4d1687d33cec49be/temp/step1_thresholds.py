"""Step 1: Download NWS bulk gauge report and extract flood stages for our stations."""
import csv
import io
import json
import urllib.request
import pandas as pd

NWS_URL = "https://water.noaa.gov/resources/downloads/reports/nwps_all_gauges_report.csv"
STATIONS_FILE = "workspace/data/michigan_stations.txt"

# Load station IDs
with open(STATIONS_FILE) as f:
    station_ids = [line.strip() for line in f if line.strip()]
print(f"Stations in file: {len(station_ids)}")

# Download NWS report
req = urllib.request.Request(NWS_URL, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req, timeout=60) as r:
    content = r.read().decode("utf-8")

reader = csv.reader(io.StringIO(content))
headers = next(reader)
# Known NWS quirk: data rows may have 44 cols vs 43 headers -> truncate
data = [row[: len(headers)] for row in reader]
df = pd.DataFrame(data, columns=headers)
print(f"NWS report rows: {len(df)}, columns: {len(df.columns)}")

df["usgs id"] = df["usgs id"].astype(str).str.strip()
df["flood stage"] = pd.to_numeric(df["flood stage"], errors="coerce")

# Match to our stations
thresholds = {}
for sid in station_ids:
    rows = df[df["usgs id"] == sid]
    if len(rows) == 0:
        print(f"  NO NWS MATCH: {sid}")
        continue
    row = rows.iloc[0]
    fs = row["flood stage"]
    if pd.isna(fs) or fs == -9999:
        print(f"  NO FLOOD STAGE: {sid} ({row['location name']})")
        continue
    thresholds[sid] = {
        "name": str(row["location name"]),
        "flood": float(fs),
    }

print(f"\nStations with usable flood stage: {len(thresholds)} / {len(station_ids)}")
with open("temp/nws_thresholds.json", "w") as f:
    json.dump(thresholds, f, indent=2)
print("Saved to temp/nws_thresholds.json")
