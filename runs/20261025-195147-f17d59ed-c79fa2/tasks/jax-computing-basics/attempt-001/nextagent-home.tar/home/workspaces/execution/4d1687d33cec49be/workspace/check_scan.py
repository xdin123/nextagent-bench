import inspect
from jax import lax

print("scan signature:", inspect.signature(lax.scan))
print()
print(inspect.getdoc(lax.scan)[:3000])
