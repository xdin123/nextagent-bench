"""Solve all tasks in problem.json using JAX.

Implements the semantics described by the jax-skills capability:
- basic_reduce : mean of each row (reduce along axis=1)
- map_square   : elementwise square via vmap
- grad_logistic: gradient of mean logistic loss w.r.t. w via jax.grad
- scan_rnn     : RNN forward pass via lax.scan with tanh activation
- jit_mlp      : 2-layer MLP (ReLU hidden) via jax.jit
"""
import os
import json
import numpy as np
import jax
import jax.numpy as jnp
from jax import lax

HERE = os.path.dirname(os.path.abspath(__file__))


def p(path):
    """Resolve a problem.json relative path against the workspace root."""
    return path if os.path.isabs(path) else os.path.join(HERE, path)


def load(path):
    """Load a JAX-compatible array from .npy or .npz."""
    full = p(path)
    if path.endswith(".npz"):
        npz = np.load(full)
        return {k: jnp.asarray(npz[k]) for k in npz.files}
    return jnp.asarray(np.load(full))


def save(data, path):
    """Save a JAX array to .npy (convert to NumPy on save)."""
    np.save(p(path), np.asarray(jax.device_get(data)))


# ---------------------------------------------------------------- 1. basic_reduce
def basic_reduce():
    x = load("data/x.npy")
    assert x.ndim == 2, f"expected 2D input, got shape {x.shape}"
    row_means = jnp.mean(x, axis=1)  # mean of each row
    save(row_means, "basic_reduce.npy")
    return row_means


# ---------------------------------------------------------------- 2. map_square
def map_square():
    x = load("data/x.npy")
    square = jax.vmap(lambda t: t * t)  # vectorized elementwise square
    out = square(x)
    save(out, "map_square.npy")
    return out


# ---------------------------------------------------------------- 3. grad_logistic
def _logistic_loss(w, x, y):
    # mean(log(1 + exp(-y * (x @ w)))), numerically stable via logaddexp
    z = -y * (x @ w)
    return jnp.mean(jnp.logaddexp(jnp.zeros_like(z), z))


def grad_logistic():
    d = load("data/logistic.npz")
    x, y, w = d["x"], d["y"], d["w"]
    assert x.shape[1] == w.shape[0], "x feature dim must match w size"
    assert x.shape[0] == y.shape[0], "x row count must match y size"
    grad_w = jax.grad(_logistic_loss)(w, x, y)
    save(grad_w, "grad_logistic.npy")
    return grad_w


# ---------------------------------------------------------------- 4. scan_rnn
def _rnn_step(h, x_t, Wx, Wh, b):
    h_next = jnp.tanh(Wx @ x_t + Wh @ h + b)
    return h_next, h_next


def scan_rnn():
    d = load("data/seq.npz")
    seq, init, Wx, Wh, b = d["seq"], d["init"], d["Wx"], d["Wh"], d["b"]
    assert seq.ndim == 2, f"expected (T, d_in) sequence, got {seq.shape}"
    assert Wx.shape == (seq.shape[1], init.shape[0]), "Wx shape mismatch"
    assert Wh.shape == (init.shape[0], init.shape[0]), "Wh shape mismatch"
    assert b.shape == init.shape, "bias shape mismatch"
    _, hseq = lax.scan(_rnn_step, init, seq, Wx, Wh, b)
    save(hseq, "scan_rnn.npy")  # sequence of hidden states, shape (T, d_hidden)
    return hseq


# ---------------------------------------------------------------- 5. jit_mlp
def _mlp(X, W1, b1, W2, b2):
    h = jnp.maximum(jnp.zeros_like(X @ W1 + b1), 0.0)  # ReLU hidden layer
    return h @ W2 + b2


def jit_mlp():
    d = load("data/mlp.npz")
    X, W1, b1, W2, b2 = d["X"], d["W1"], d["b1"], d["W2"], d["b2"]
    assert X.shape[1] == W1.shape[0], "X feature dim must match W1 rows"
    assert W1.shape[1] == W2.shape[0], "W1 cols must match W2 rows"
    compiled = jax.jit(_mlp)  # JIT compile
    out = compiled(X, W1, b1, W2, b2)
    save(out, "jit_mlp.npy")
    return out


def main():
    with open(p("problem.json")) as f:
        problems = json.load(f)

    runners = {
        "basic_reduce": basic_reduce,
        "map_square": map_square,
        "grad_logistic": grad_logistic,
        "scan_rnn": scan_rnn,
        "jit_mlp": jit_mlp,
    }

    for prob in problems:
        pid = prob["id"]
        assert pid in runners, f"no runner for problem id {pid!r}"
        out = runners[pid]()
        print(f"[{pid}] input={prob['input']} output={prob['output']} "
              f"shape={out.shape} dtype={out.dtype}")
        print(f"  values={np.asarray(jax.device_get(out)).ravel()[:8]}...")


if __name__ == "__main__":
    main()
