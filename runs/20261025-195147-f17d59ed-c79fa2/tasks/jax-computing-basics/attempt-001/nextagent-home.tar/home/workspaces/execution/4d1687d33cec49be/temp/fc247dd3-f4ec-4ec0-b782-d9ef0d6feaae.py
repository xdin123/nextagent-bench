
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import numpy as np

x = np.load('workspace/data/x.npy')
print("x.npy:", x.shape, x.dtype)
print(x)

for name in ['logistic', 'mlp', 'seq']:
    d = np.load(f'workspace/data/{name}.npz')
    print(f"\n{name}.npz keys:", list(d.keys()))
    for k in d.keys():
        print(f"  {k}: shape={d[k].shape}, dtype={d[k].dtype}")
        if d[k].size <= 20:
            print(f"    values: {d[k]}")
