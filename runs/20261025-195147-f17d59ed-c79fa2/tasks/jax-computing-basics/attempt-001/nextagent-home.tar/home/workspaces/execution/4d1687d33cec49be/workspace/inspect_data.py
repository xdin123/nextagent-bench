import numpy as np

x = np.load('workspace/data/x.npy')
print("x.npy:", x.shape, x.dtype)
print(x)

for name in ['logistic', 'mlp', 'seq']:
    d = np.load(f'workspace/data/{name}.npz')
    print(f"\n{name}.npz keys:", list(d.keys()))
    for k in d.keys():
        print(f"  {k}: shape={d[k].shape}, dtype={d[k].dtype}")
        if d[k].size <= 30:
            print(f"    values: {d[k]}")
