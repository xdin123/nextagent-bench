import jax
import jax.numpy as jnp

print("jax version:", jax.__version__)
print("sum:", jnp.array([1, 2, 3]).sum())

try:
    import jax_skills as jx
    print("jax_skills: AVAILABLE")
    print("dir:", [a for a in dir(jx) if not a.startswith('_')])
except Exception as e:
    print("jax_skills: NOT AVAILABLE ->", repr(e))
