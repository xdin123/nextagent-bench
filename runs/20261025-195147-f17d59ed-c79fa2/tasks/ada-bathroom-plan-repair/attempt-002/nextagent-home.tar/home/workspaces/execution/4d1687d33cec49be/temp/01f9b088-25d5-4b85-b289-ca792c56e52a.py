

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import ezdxf
from collections import Counter

doc = ezdxf.readfile('workspace/input/ada_bath_input.dxf')
msp = doc.modelspace()

layer_counter = Counter()
type_counter = Counter()
for e in msp:
    layer_counter[e.dxf.layer] += 1
    type_counter[e.dxftype()] += 1

print("LAYER COUNTS:")
for k, v in sorted(layer_counter.items()):
    print(f"  {k}: {v}")
print("\nENTITY TYPES:")
for k, v in sorted(type_counter.items()):
    print(f"  {k}: {v}")

# layer table definitions
print("\nLAYERS DEFINED IN TABLE:")
for l in doc.layers:
    print(f"  {l.dxf.name}")
