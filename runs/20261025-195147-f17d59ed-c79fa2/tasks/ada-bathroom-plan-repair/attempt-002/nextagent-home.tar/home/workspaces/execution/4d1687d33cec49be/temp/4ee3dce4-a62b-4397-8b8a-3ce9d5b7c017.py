

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import ezdxf

doc = ezdxf.readfile('workspace/input/ada_bath_input.dxf')
msp = doc.modelspace()

def dump_layer(name):
    print(f"\n===== LAYER: {name} =====")
    for e in msp:
        if e.dxf.layer != name:
            continue
        t = e.dxftype()
        if t == 'LINE':
            print(f"  LINE ({e.dxf.start.x:.2f},{e.dxf.start.y:.2f}) -> ({e.dxf.end.x:.2f},{e.dxf.end.y:.2f})")
        elif t == 'ARC':
            print(f"  ARC c=({e.dxf.center.x:.2f},{e.dxf.center.y:.2f}) r={e.dxf.radius:.2f} a0={e.dxf.start_angle:.1f} a1={e.dxf.end_angle:.1f}")
        elif t == 'CIRCLE':
            print(f"  CIRCLE c=({e.dxf.center.x:.2f},{e.dxf.center.y:.2f}) r={e.dxf.radius:.2f}")
        elif t == 'LWPOLYLINE':
            pts = [(round(x,2), round(y,2)) for x,y in e.get_points()]
            print(f"  LWPOLYLINE closed={e.closed} pts={pts}")
        elif t == 'POLYLINE':
            pts = [(round(v.dxf.location.x,2), round(v.dxf.location.y,2)) for v in e.vertices]
            print(f"  POLYLINE closed={e.closed} pts={pts}")
        elif t == 'SPLINE':
            pts = [(round(p[0],2), round(p[1],2)) for p in e.control_points]
            print(f"  SPLINE ctrl={pts}")
        elif t == 'POINT':
            print(f"  POINT ({e.dxf.location.x:.2f},{e.dxf.location.y:.2f})")
        elif t == 'DIMENSION':
            try:
                print(f"  DIMENSION def=({e.dxf.defpoint.x:.2f},{e.dxf.defpoint.y:.2f}) text='{e.dxf.text}'")
            except Exception as ex:
                print(f"  DIMENSION text='{e.dxf.text}'")
        else:
            print(f"  {t}")

for layer in ['WALL', 'DOOR', 'FIXTURE-WC', 'FIXTURE-LAV', 'FIXT-TUB', 'GRABRAIL', 'CLEARANCE', 'DIMS', '0', 'Defpoints']:
    dump_layer(layer)
