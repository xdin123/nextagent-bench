import time
import numpy as np
import qutip as qt
qt.settings.max_iter = 10000

N = 4
n_max = 16
omega0 = 1.0
omegac = 1.0
g = 2.0 / np.sqrt(N)
kappa = 1.0

# Basis per qubit: [g, e]  (index 0 = ground, index 1 = excited)
sigma_up   = qt.Qobj([[0, 0], [1, 0]])   # |e><g|  raising
sigma_down = qt.Qobj([[0, 1], [0, 0]])   # |g><e|  lowering
sigma_z    = qt.Qobj([[-1, 0], [0, 1]])  # |e><e| - |g><g|
I2 = qt.qeye(2)

def embed(op, site):
    ops = [I2] * N
    ops[site] = op
    return qt.tensor(*ops)

Jp = sum(embed(sigma_up, i) for i in range(N))
Jm = sum(embed(sigma_down, i) for i in range(N))
Jz = 0.5 * sum(embed(sigma_z, i) for i in range(N))

comm = Jp * Jm - Jm * Jp
print("[Jp,Jm]-2Jz max diff:", np.max(np.abs((comm - 2 * Jz).full())))
print("[Jz,Jp]-Jp max diff:", np.max(np.abs((Jz*Jp - Jp*Jz - Jp).full())))

a = qt.destroy(n_max)
ad = a.dag()
Ic = qt.qeye(n_max)
Is = qt.tensor(*([qt.qeye(2)] * N))   # 5-subsystem identity, matches spin dims

t1 = qt.tensor(omegac * ad * a, Is)
t2 = qt.tensor(Ic, omega0 * Jz)
t3 = g * qt.tensor(ad + a, Jp + Jm)
print("t1", t1.dims, "t2", t2.dims, "t3", t3.dims)
H = t1 + t2 + t3
print("H dims:", H.dims, "hermitian:", H.isherm)

# Wigner indexing validation
xvec_small = np.linspace(-6, 6, 1000)
psi_c = qt.coherent(n_max, 1.0)
rho_c = qt.ket2dm(psi_c)
W = qt.wigner(rho_c, xvec_small, xvec_small)
idx = np.unravel_index(np.argmax(W), W.shape)
print("W shape", W.shape, "argmax(i,j)=", idx, "-> x=", xvec_small[idx[1]], "p=", xvec_small[idx[0]], " exp x=sqrt2=%.4f" % np.sqrt(2))
dx = xvec_small[1]-xvec_small[0]
print("W integral ~", np.sum(W)*dx*dx)

# steady state timing case 1
c_ops = [np.sqrt(kappa) * qt.tensor(a, Is)]
for i in range(N):
    c_ops.append(np.sqrt(0.01) * qt.tensor(Ic, embed(sigma_z, i)))
    c_ops.append(np.sqrt(0.1)  * qt.tensor(Ic, embed(sigma_up, i)))
t0 = time.time()
rho_ss = qt.steadystate(H, c_ops, method='eigen')
t1t = time.time()
print("steadystate time (case1):", round(t1t-t0,2), "s")
print("Tr(rho_ss)=", np.real(np.trace(rho_ss.full())))
rho_cav = rho_ss.trace_out([1])
print("rho_cav dims", rho_cav.dims, "Tr=", np.real(np.trace(rho_cav.full())))
print("<n> cavity =", np.real(qt.expect(a.dag()*a, rho_cav)))

for M in [200, 400]:
    xv = np.linspace(-6, 6, M)
    t0 = time.time(); Wm = qt.wigner(rho_cav, xv, xv); t1t = time.time()
    print("Wigner %dx%d time:" % (M,M), round(t1t-t0,2), "s")
