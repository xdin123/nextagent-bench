
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import qutip, numpy, scipy
print('qutip', qutip.__version__)
print('numpy', numpy.__version__)
print('scipy', scipy.__version__)
import qutip as qt
print('has steadystate:', hasattr(qt, 'steadystate'))
print('has wigner:', hasattr(qt, 'wigner'))
print('has jspin:', hasattr(qt, 'jspin'))
print('has dicke:', hasattr(qt, 'dicke'))
