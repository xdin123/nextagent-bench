import time
import numpy as np
import qutip as qt
qt.settings.max_iter = 10000

# ---------------- Parameters ----------------
N = 4
n_max = 16
omega0 = 1.0
omegac = 1.0
g = 2.0 / np.sqrt(N)
kappa = 1.0

# ---------------- Local qubit operators (basis [g, e]) ----------------
sgm_p = qt.Qobj([[0, 1], [0, 0]])    # sigma_+ = |e><g|
sgm_m = qt.Qobj([[0, 0], [1, 0]])    # sigma_- = |g><e|
sgm_z = qt.Qobj([[-1, 0], [0, 1]])   # sigma_z = |e><e| - |g><g|
I2 = qt.qeye(2)

def embed(op, site):
    ops = [I2] * N
    ops[site] = op
    return qt.tensor(*ops)

Jp = sum(embed(sgm_p, i) for i in range(N))
Jm = sum(embed(sgm_m, i) for i in range(N))
Jz = 0.5 * sum(embed(sgm_z, i) for i in range(N))

# Check SU(2) algebra: [Jp, Jm] = 2 Jz ; Jp Jm - Jm Jp
comm = Jp * Jm - Jm * Jp
print("Check [Jp,Jm] == 2 Jz, max diff:", np.max(np.abs((comm - 2 * Jz).full())))
print("Jp dims:", Jp.dims, "spin dim:", 2 ** N)

# ---------------- Cavity + Hamiltonian (order: [cavity, spin]) ----------------
a = qt.destroy(n_max)
ad = a.dag()
Ic = qt.qeye(n_max)
Is = qt.qeye(2 ** N)

H = (qt.tensor(omegac * ad * a, Is)
     + qt.tensor(Ic, omega0 * Jz)
     + g * qt.tensor(ad + a, Jp + Jm))
print("H dims:", H.dims, "H is hermitian:", H.isherm())

# ---------------- Wigner indexing validation ----------------
xvec_small = np.linspace(-6, 6, 1000)
alpha = 1.0
psi_c = qt.coherent(n_max, alpha)
rho_c = qt.ket2dm(psi_c)
W = qt.wigner(rho_c, xvec_small, xvec_small)
print("W shape:", W.shape)
idx = np.unravel_index(np.argmax(W), W.shape)
print("argmax (i,j):", idx, "-> x=", xvec_small[idx[1]], " p=", xvec_small[idx[0]])
print("expected for alpha=1.0 (real): x=sqrt(2)=%.4f p=0" % np.sqrt(2))
# integral of W over phase space should be 1
dx = xvec_small[1] - xvec_small[0]
print("integral of W ~", np.sum(W) * dx * dx)

# ---------------- Steady state timing (case 1) ----------------
gamma_phi = 0.01
gamma_up = 0.1
c_ops = [np.sqrt(kappa) * qt.tensor(a, Is)]
for i in range(N):
    c_ops.append(np.sqrt(gamma_phi) * qt.tensor(Ic, sgm_z))  # placeholder, fix below
# Rebuild c_ops correctly
c_ops = [np.sqrt(kappa) * qt.tensor(a, Is)]
for i in range(N):
    c_ops.append(np.sqrt(gamma_phi) * qt.tensor(Ic, embed(sgm_z, i)))
    c_ops.append(np.sqrt(gamma_up) * qt.tensor(Ic, embed(sgm_p, i)))

t0 = time.time()
rho_ss = qt.steadystate(H, c_ops, method='mkl')
t1 = time.time()
print("steadystate time (case1):", round(t1 - t0, 2), "s")
print("rho_ss type:", type(rho_ss), "dims:", rho_ss.dims)
print("Tr(rho_ss) =", np.real(np.trace(rho_ss.full())))

# Trace out spins -> cavity state (cavity is subsystem 0)
rho_cav = rho_ss.trace_out([1])
print("rho_cav dims:", rho_cav.dims, "Tr =", np.real(np.trace(rho_cav.full())))
n_avg = np.real((a.dag() * a).tr(rho_cav) if hasattr((a.dag()*a),'tr') else (rho_cav * (a.dag()*a)).tr())
print("<n> cavity =", np.real((qt.expect(a.dag()*a, rho_cav))))

# ---------------- Wigner timing on moderate grids ----------------
for M in [200, 400]:
    xv = np.linspace(-6, 6, M)
    t0 = time.time()
    Wm = qt.wigner(rho_cav, xv, xv)
    t1 = time.time()
    print("Wigner %dx%d time:" % (M, M), round(t1 - t0, 2), "s")
