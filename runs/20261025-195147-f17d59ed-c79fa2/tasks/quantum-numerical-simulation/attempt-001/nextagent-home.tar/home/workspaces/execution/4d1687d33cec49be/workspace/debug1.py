import numpy as np
import qutip as qt
qt.settings.max_iter = 10000
N = 4
n_max = 16

sgm_p = qt.Qobj([[0, 1], [0, 0]])
sgm_m = qt.Qobj([[0, 0], [1, 0]])
sgm_z = qt.Qobj([[-1, 0], [0, 1]])
I2 = qt.qeye(2)

# single qubit check
c1 = sgm_p * sgm_m - sgm_m * sgm_p
print("single [sp,sm] - sz max diff:", np.max(np.abs((c1 - sgm_z).full())))

def embed(op, site):
    ops = [I2] * N
    ops[site] = op
    return qt.tensor(*ops)

Jp = sum(embed(sgm_p, i) for i in range(N))
Jm = sum(embed(sgm_m, i) for i in range(N))
Jz = 0.5 * sum(embed(sgm_z, i) for i in range(N))
print("Jp dims:", Jp.dims, "shape:", Jp.shape)
comm = Jp * Jm - Jm * Jp
d = np.max(np.abs((comm - 2 * Jz).full()))
print("4qubit [Jp,Jm]-2Jz max diff:", d)

# inspect where it differs
diff = (comm - 2 * Jz).full()
idx = np.unravel_index(np.argmax(np.abs(diff)), diff.shape)
print("argmax idx:", idx, "val:", diff[idx])
print("comm at idx:", comm.full()[idx], "2Jz at idx:", (2*Jz).full()[idx])

# Now the H construction pieces
a = qt.destroy(n_max)
ad = a.dag()
Ic = qt.qeye(n_max)
Is = qt.qeye(2 ** N)
print("ad shape:", ad.shape, "Is shape:", Is.shape, "Ic shape:", Ic.shape)
p1 = omegac = 1.0
t1 = qt.tensor(p1 * ad * a, Is)
print("t1 dims:", t1.dims)
