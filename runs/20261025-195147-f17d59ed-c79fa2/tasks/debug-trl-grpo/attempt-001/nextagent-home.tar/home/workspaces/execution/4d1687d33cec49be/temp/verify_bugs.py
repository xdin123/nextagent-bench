"""Pre-fix verification: demonstrate the suspected bugs in workspace/trl."""
import sys

sys.path.insert(0, "workspace/trl")

import torch
import torch.nn.functional as F

from trl.trainer.utils import decode_and_strip_padding, selective_log_softmax


class FakeTokenizer:
    pad_token = None

    def batch_decode(self, ids, skip_special_tokens=True):
        return [" ".join(str(int(t)) for t in row) for row in ids]


print("=" * 70)
print("BUG 1: selective_log_softmax vs F.log_softmax reference (float32)")
print("=" * 70)
torch.manual_seed(0)
logits = torch.randn(4, 8, 50)
index = torch.randint(0, 50, (4, 8))
ref = F.log_softmax(logits, dim=-1).gather(-1, index.unsqueeze(-1)).squeeze(-1)
got = selective_log_softmax(logits, index)
print(f"max|ref - got|          = {(ref - got).abs().max().item():.6f}")
print(f"sign-flip hypothesis    = {torch.allclose(got, -ref, atol=1e-5)}")
print(f"ref max (must be <=0)   = {ref.max().item():.6f}")
print(f"got max (must be <=0)   = {got.max().item():.6f}")
# near-one-hot: dominant token log-prob should be ~0 (slightly negative)
hot = torch.zeros(1, 1, 20)
hot[0, 0, 0] = 20.0
idx = torch.tensor([[0]])
print(f"near-one-hot dominant   = {selective_log_softmax(hot, idx).item():.6f} (ref {F.log_softmax(hot, -1).gather(-1, idx.unsqueeze(-1)).squeeze(-1).item():.6f})")

print()
print("=" * 70)
print("BUG 2: decode_and_strip_padding on degenerate shapes")
print("=" * 70)
tok = FakeTokenizer()
cases = {
    "full think+answer": torch.tensor([[1, 2, 9, 3, 4]]),  # 1 2 </think> 3 4  (9 = sentinel for tag)
    "no tags at all": torch.tensor([[1, 2, 3, 4]]),
    "only prefix": torch.tensor([[1, 2, 8]]),  # 1 2 <think>
    "only suffix": torch.tensor([[9, 1, 2]]),  # </think> 1 2
}
# build texts directly to avoid mapping sentinel ids
class TextTok:
    pad_token = None
    def __init__(self, texts): self.texts = texts
    def batch_decode(self, ids, skip_special_tokens=True):
        return self.texts

texts = [
    "Let me think. </think>\n<answer>25+50=75</answer>",
    "<answer>25+50=75</answer>",
    "Let me think step by step...",
    "</think>\n<answer>75</answer>",
]
out = decode_and_strip_padding(torch.zeros(4, 1, dtype=torch.long), TextTok(texts))
for name, t, o in zip(cases, texts, out):
    flag = "" if o.strip() else "   <-- BLANKED (reward sees empty text -> 0.0)"
    print(f"{name:20s} in={t[:45]!r:48s} out={o!r}{flag}")

print()
print("=" * 70)
print("BUG 3: advantage scaling constant")
print("=" * 70)
import re
src = open("workspace/trl/trl/trainer/grpo_trainer.py").read()
m = re.search(r"advantages = advantages / \(std_grouped_rewards \+ ([0-9.eE+-]+)\)", src)
print(f"found: advantages = advantages / (std_grouped_rewards + {m.group(1)})")
rewards = torch.tensor([0.0, 0.0, 0.0, 1.0])  # one correct in group of 4
adv = rewards - rewards.mean()
print(f"raw advantages (non-zero): {adv.tolist()}")
print(f"with +{m.group(1)}: max|adv| = {(adv / (rewards.std() + float(m.group(1)))).abs().max():.3e}")
print(f"with +1e-4 (upstream):      max|adv| = {(adv / (rewards.std() + 1e-4)).abs().max():.3e}")
