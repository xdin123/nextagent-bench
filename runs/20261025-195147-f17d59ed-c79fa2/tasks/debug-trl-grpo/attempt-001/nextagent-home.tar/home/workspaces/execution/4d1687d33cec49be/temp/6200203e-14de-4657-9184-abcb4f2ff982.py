
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

path = "workspace/trl/trl/trainer/utils.py"
src = open(path).read()

# Build the tag without writing it literally (avoids tag-interp of the source).
tag = "</" + "think>"

old = (
    '        if "' + tag + '" in text:\n'
    '            text = text.split("' + tag + '", 1)[-1].strip()\n'
    '        else:\n'
    '            text = ""\n'
)
new = (
    '        if "' + tag + '" in text:\n'
    '            text = text.split("' + tag + '", 1)[-1].strip()\n'
)

assert src.count(old) == 1, f"expected exactly 1 match, found {src.count(old)}"
src = src.replace(old, new)
open(path, "w").write(src)
print("decode_and_strip_padding else-branch removed OK")
