
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

path = "workspace/trl/trl/trainer/utils.py"
lines = open(path).read().split("\n")

# Verify the target block before deleting.
assert lines[1504].strip() == "else:", repr(lines[1504])
assert "No closing" in lines[1505], repr(lines[1505])
assert lines[1506].strip() == 'text = ""', repr(lines[1506])
assert lines[1507].strip() == "result.append(text)", repr(lines[1507])

# Remove lines 1505,1506,1507 (0-indexed 1504,1505,1506)
del lines[1504:1507]
open(path, "w").write("\n".join(lines))
print("Removed else-branch. New block:")
for i in range(1499, 1508):
    print(i+1, repr(lines[i]))
