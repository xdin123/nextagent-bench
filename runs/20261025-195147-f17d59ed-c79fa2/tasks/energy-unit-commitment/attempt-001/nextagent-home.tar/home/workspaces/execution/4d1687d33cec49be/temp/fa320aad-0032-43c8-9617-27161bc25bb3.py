

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import json
import numpy as np

with open("workspace/network.json") as f:
    data = json.load(f)

T = data["time_periods"]
demand = np.array(data["demand"], dtype=float)
reserves = np.array(data["reserves"], dtype=float)
tg = data["thermal_generators"]
rg = data["renewable_generators"]

print("T =", T)
print("demand range: %.2f .. %.2f" % (demand.min(), demand.max()))
print("reserves range: %.2f .. %.2f" % (reserves.min(), reserves.max()))

# Thermal checks
issues = []
pmins, pmaxs, ramps, minups, mindowns = [], [], [], [], []
for name, g in tg.items():
    pmin = g["power_output_minimum"]; pmax = g["power_output_maximum"]
    if pmin > pmax: issues.append(f"{name}: pmin>pmax")
    if g["ramp_up_limit"] <= 0 or g["ramp_down_limit"] <= 0: issues.append(f"{name}: bad ramp")
    if g["power_output_t0"] < 0 or g["power_output_t0"] > pmax: issues.append(f"{name}: bad t0 output")
    if g["unit_on_t0"] not in (0,1): issues.append(f"{name}: bad unit_on_t0")
    if g["unit_on_t0"] == 0 and g["power_output_t0"] != 0: issues.append(f"{name}: off at t0 but output>0")
    if g["unit_on_t0"] == 1 and not (pmin <= g["power_output_t0"] <= pmax): issues.append(f"{name}: on at t0, output out of range")
    # startup tiers
    lags = [s["lag"] for s in g["startup"]]
    if lags != sorted(lags): issues.append(f"{name}: unsorted startup lags")
    # piecewise curve
    pts = g["piecewise_production"]
    mws = [p["mw"] for p in pts]
    costs = [p["cost"] for p in pts]
    if mws != sorted(mws): issues.append(f"{name}: unsorted curve mw")
    if not (mws[0] >= pmin - 1e-9 and mws[-1] <= pmax + 1e-9): issues.append(f"{name}: curve outside limits {mws[0]}..{mws[-1]} vs {pmin}..{pmax}")
    if mws[0] > pmin + 1e-9: issues.append(f"{name}: curve starts above pmin: {mws[0]} vs {pmin}")
    if mws[-1] < pmax - 1e-9: issues.append(f"{name}: curve ends below pmax: {mws[-1]} vs {pmax}")
    # monotone costs
    if any(c2 <= c1 for c1, c2 in zip(costs, costs[1:])): issues.append(f"{name}: non-increasing costs")
    # check slopes (marginal costs)
    slopes = [(c2-c1)/(m2-m1) for (m1,c1),(m2,c2) in zip(pts, pts[1:])]
    # initial conditions consistency
    if g["unit_on_t0"] == 1 and g["time_up_t0"] <= 0: issues.append(f"{name}: on t0 but time_up_t0<=0")
    if g["unit_on_t0"] == 0 and g["time_down_t0"] <= 0: issues.append(f"{name}: off t0 but time_down_t0<=0")
    pmins.append(pmin); pmaxs.append(pmax)
    ramps.append(g["ramp_up_limit"])
    minups.append(g["time_up_minimum"]); mindowns.append(g["time_down_minimum"])

print("\nThermal issues:", issues if issues else "none")
print("pmin range: %.1f..%.1f, pmax range: %.1f..%.1f" % (min(pmins), max(pmins), min(pmaxs), max(pmaxs)))
print("total thermal capacity: %.2f" % sum(pmaxs))
print("minup range:", min(minups), max(minups), " mindown range:", min(mindowns), max(mindowns))

# must_run units
mr = [n for n,g in tg.items() if g["must_run"]]
print("must_run units:", mr)

# units on at t0
on0 = [(n, g["power_output_t0"], g["time_up_t0"]) for n,g in tg.items() if g["unit_on_t0"]==1]
print("units on at t0:", on0)

# renewable checks
rissues = []
tot_renew_max = np.zeros(T)
tot_renew_min = np.zeros(T)
for name, r in rg.items():
    mn = np.array(r["power_output_minimum"], float); mx = np.array(r["power_output_maximum"], float)
    if len(mn) != T or len(mx) != T: rissues.append(f"{name}: wrong length")
    if (mn > mx + 1e-9).any(): rissues.append(f"{name}: min>max")
    if mn.min() < -1e-9 or mx.max() < -1e-9: rissues.append(f"{name}: negative")
    tot_renew_max += mx; tot_renew_min += mn

print("\nRenewable issues:", rissues if rissues else "none")
print("total renewable max range: %.1f..%.1f" % (tot_renew_max.min(), tot_renew_max.max()))
print("total renewable min range: %.1f..%.1f" % (tot_renew_min.min(), tot_renew_min.max()))

# feasibility: can thermal meet demand - renewable max + reserves?
net_load_max = demand - tot_renew_max  # thermal must at least cover this
need = net_load_max + reserves
print("\nmax thermal needed (demand - renew max + reserve): %.2f at hour %d" % (need.max(), int(need.argmax())+1))
print("thermal total capacity: %.2f" % sum(pmaxs))
# min thermal: demand - renew max, but each on unit must produce >= pmin
# check: is demand - renew_max >= 0 everywhere? (i.e., renewables never exceed demand)
print("min of (demand - renew_max): %.2f" % net_load_max.min())
print("min of (demand - renew_min) thermal headroom check: thermal must be <= capacity:", (demand - tot_renew_min).max(), "vs cap", sum(pmaxs))
