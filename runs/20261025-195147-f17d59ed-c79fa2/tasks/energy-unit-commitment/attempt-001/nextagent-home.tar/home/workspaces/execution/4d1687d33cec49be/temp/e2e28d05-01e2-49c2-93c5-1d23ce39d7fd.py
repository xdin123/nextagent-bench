

# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import json

with open("workspace/network.json") as f:
    data = json.load(f)

print("Top-level keys:", list(data.keys()))
print("time_periods:", data["time_periods"])
print("demand len:", len(data["demand"]))
print("reserves len:", len(data["reserves"]))
print("num thermal:", len(data["thermal_generators"]))
print("num renewable:", len(data.get("renewable_generators", {})))

# Inspect a thermal generator
tg = data["thermal_generators"]
names = list(tg.keys())
print("\nFirst 5 thermal names:", names[:5])
print("Last 5 thermal names:", names[-5:])
print("\nSample thermal generator (full):")
print(json.dumps(tg[names[0]], indent=2))

rg = data.get("renewable_generators", {})
rnames = list(rg.keys())
print("\nFirst 5 renewable names:", rnames[:5])
print("\nSample renewable generator (full):")
print(json.dumps(rg[rnames[0]], indent=2))
