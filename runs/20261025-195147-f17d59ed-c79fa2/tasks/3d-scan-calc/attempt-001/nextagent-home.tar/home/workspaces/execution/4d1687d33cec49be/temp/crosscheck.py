import collections, struct

path = 'workspace/scan_data.stl'
with open(path, 'rb') as f:
    f.read(80)
    count = struct.unpack('<I', f.read(4))[0]
    tris = []
    for _ in range(count):
        data = f.read(50)
        vals = struct.unpack('<12fH', data)
        # standard binary STL: 0-2 normal, 3-5 v1, 6-8 v2, 9-11 v3, 12 attr
        v1 = (vals[3], vals[4], vals[5])
        v2 = (vals[6], vals[7], vals[8])
        v3 = (vals[9], vals[10], vals[11])
        tris.append((v1, v2, v3, vals[12]))

print('triangles:', len(tris))

def tri_vol(t):
    v1, v2, v3 = t[:3]
    return (v1[0]*(v2[1]*v3[2]-v2[2]*v3[1])
           + v1[1]*(v2[2]*v3[0]-v2[0]*v3[2])
           + v1[2]*(v2[0]*v3[1]-v2[1]*v3[0])) / 6.0

def components(quant):
    vmap = collections.defaultdict(list)
    for i, t in enumerate(tris):
        for v in t[:3]:
            vmap[quant(v)].append(i)
    seen = set()
    comps = []
    for i in range(len(tris)):
        if i in seen:
            continue
        q = collections.deque([i]); seen.add(i)
        idxs = []
        while q:
            c = q.popleft(); idxs.append(c)
            for v in tris[c][:3]:
                for n in vmap[quant(v)]:
                    if n not in seen:
                        seen.add(n); q.append(n)
        comps.append(idxs)
    return comps

def analyze(idxs):
    signed = sum(tri_vol(tris[i]) for i in idxs)
    absvol = sum(abs(tri_vol(tris[i])) for i in idxs)
    ids = collections.Counter(tris[i][3] for i in idxs)
    edges = collections.Counter()
    for i in idxs:
        v1, v2, v3 = tris[i][:3]
        edges[(v1, v2)] += 1
        edges[(v2, v3)] += 1
        edges[(v3, v1)] += 1
    open_edges = sum(1 for _, c in edges.items() if c == 1)
    return signed, absvol, ids, open_edges

for name, quant in [
    ('exact', lambda v: v),
    ('5dec (skill method)', lambda v: (round(v[0],5), round(v[1],5), round(v[2],5))),
]:
    comps = components(quant)
    print(f'\n=== {name}: {len(comps)} components ===')
    rows = []
    for idxs in comps:
        s, a, ids, oe = analyze(idxs)
        rows.append((a, len(idxs), ids, oe, s))
    rows.sort(reverse=True)
    print('top 8 (sum|tri|, ntris, mat_ids, open_edges, signed):')
    for r in rows[:8]:
        print('  vol=%.6f ntris=%d ids=%s open_edges=%d signed=%.6f' % (r[0], r[1], dict(r[2]), r[3], r[4]))

# global material id distribution
print('\nglobal material id distribution:', dict(collections.Counter(t[3] for t in tris)))

# Skill reported: volume 6242.890312594918, mat_id 42, 53 components
print('\nSKILL RESULT: volume=6242.890312594918 mat_id=42 components=53')
