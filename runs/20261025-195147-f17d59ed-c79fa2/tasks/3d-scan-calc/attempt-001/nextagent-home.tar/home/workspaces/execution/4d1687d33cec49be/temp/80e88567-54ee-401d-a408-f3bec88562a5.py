
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import os, struct
s = os.path.getsize('workspace/scan_data.stl')
print('size', s)
print('tri_count', (s-84)/50)
with open('workspace/scan_data.stl','rb') as f:
    hdr = f.read(80)
    cnt = struct.unpack('<I', f.read(4))[0]
print('header:', hdr[:40])
print('declared count:', cnt)
# peek first triangle
data = f.read(50)
vals = struct.unpack('<12fH', data)
print('first tri floats+attr:', vals)
