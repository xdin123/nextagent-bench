import collections, struct
with open('workspace/scan_data.stl','rb') as f:
    f.read(80); count = struct.unpack('<I', f.read(4))[0]
    tris=[]
    for _ in range(count):
        v=struct.unpack('<12fH', f.read(50))
        tris.append(((v[3],v[4],v[5]),(v[6],v[7],v[8]),(v[9],v[10],v[11]),v[12]))
main=[t for t in tris if t[3]==42]
print('main tris:', len(main))
und=collections.Counter()
for t in main:
    a,b,c=t[:3]
    for e in ((a,b),(b,c),(c,a)):
        und[frozenset(e)] += 1
open_e=sum(1 for k,c in und.items() if c==1)
print('undirected edges:', len(und), 'open(boundary) edges:', open_e)
xs=[p[0] for t in main for p in t[:3]]; ys=[p[1] for t in main for p in t[:3]]; zs=[p[2] for t in main for p in t[:3]]
print('bbox x: %.4f..%.4f  y: %.4f..%.4f  z: %.4f..%.4f' % (min(xs),max(xs),min(ys),max(ys),min(zs),max(zs)))
vol=6242.890312594918
mass=vol*5.55
print('mass =', mass)
