
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import geopandas as gpd
import warnings
warnings.filterwarnings('ignore')

bounds = gpd.read_file('workspace/PB2002_boundaries.json')
pa_b = bounds[bounds['Name'].str.contains('PA')].copy()

# Check: is Name.str.contains('PA') equivalent to PlateA/PlateB == 'PA'?
by_code = bounds[(bounds['PlateA']=='PA') | (bounds['PlateB']=='PA')]
print('by Name contains PA:', len(pa_b))
print('by PlateA/B == PA:', len(by_code))
print('same set:', set(pa_b.index) == set(by_code.index))
print()

# Check antimeridian crossing: any segment with coords jumping > 180 deg in lon
import shapely
def crosses_antimeridian(line):
    coords = list(line.coords)
    for a, b in zip(coords[:-1], coords[1:]):
        if abs(a[0] - b[0]) > 180:
            return True
    return False

cross = []
for idx, row in pa_b.iterrows():
    g = row.geometry
    if g.geom_type == 'MultiLineString':
        if any(crosses_antimeridian(ls) for ls in g.geoms):
            cross.append((idx, row['Name'], g.bounds))
    else:
        if crosses_antimeridian(g):
            cross.append((idx, row['Name'], g.bounds))

print('PA boundary segments crossing antimeridian:', len(cross))
for c in cross:
    print('  ', c)
print()
# Show all PA boundary bounds to see lon ranges
print('All PA boundary lon ranges (minx, maxx):')
for idx, row in pa_b.iterrows():
    b = row.geometry.bounds
    print(f"  {row['Name']:8s} {row['Type']:10s} lon[{b[0]:8.2f}, {b[2]:8.2f}] lat[{b[1]:7.2f},{b[3]:7.2f}]")
