
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import geopandas as gpd
import warnings
warnings.filterwarnings('ignore')

plates = gpd.read_file('workspace/PB2002_plates.json')
bounds = gpd.read_file('workspace/PB2002_boundaries.json')

print('Plates CRS:', plates.crs)
print('Boundaries CRS:', bounds.crs)
print()
print('Pacific plate rows:')
pa = plates[plates['Code'] == 'PA']
print(pa[['Code','PlateName']].to_string())
print('n geometries for PA:', len(pa))
for i, g in enumerate(pa.geometry):
    print(f'  geom {i}: {g.geom_type}, bounds={g.bounds}')
print()
print('Boundaries involving PA:')
pa_b = bounds[bounds['Name'].str.contains('PA')]
print(pa_b[['Name','PlateA','PlateB','Type']].to_string())
print('n PA boundaries:', len(pa_b))
