
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import geopandas as gpd
import warnings
warnings.filterwarnings('ignore')

plates = gpd.read_file('workspace/PB2002_plates.json')
pa = plates[plates['Code'] == 'PA'].geometry.iloc[0]
print('PA geometry type:', pa.geom_type)
print('n polygons in MultiPolygon:', len(pa.geoms))
for i, g in enumerate(pa.geoms):
    print(f'  polygon {i}: {g.geom_type}, bounds={g.bounds}, area(4326)={g.area:.1f}')
print()
# Check validity
print('is_valid:', pa.is_valid)
print()
# How many earthquakes total
import json
with open('workspace/earthquakes_2024.json') as f:
    eq = json.load(f)
print('total earthquake features:', len(eq['features']))
