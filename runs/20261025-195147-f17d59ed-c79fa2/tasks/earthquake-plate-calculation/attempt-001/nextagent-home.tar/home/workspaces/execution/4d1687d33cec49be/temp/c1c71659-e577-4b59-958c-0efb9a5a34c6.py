
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import geopandas as gpd
from shapely.geometry import Point
import json, warnings
warnings.filterwarnings('ignore')

# Load
plates = gpd.read_file('workspace/PB2002_plates.json')
bounds = gpd.read_file('workspace/PB2002_boundaries.json')
with open('workspace/earthquakes_2024.json') as f:
    eq = json.load(f)

# Build earthquake GDF
feats = eq['features']
rows = []
for ft in feats:
    p = ft['properties']
    c = ft['geometry']['coordinates']
    rows.append({
        'id': ft.get('id'),
        'place': p.get('place'),
        'time': p.get('time'),
        'magnitude': p.get('mag'),
        'latitude': c[1],
        'longitude': c[0],
    })
import pandas as pd
df = pd.DataFrame(rows)
geom = [Point(r['longitude'], r['latitude']) for r in rows]
gdf_eq = gpd.GeoDataFrame(df, geometry=geom, crs='EPSG:4326')
print('total earthquakes:', len(gdf_eq))

# Pacific plate polygon
pa = plates[plates['Code'] == 'PA'].geometry.unary_union
print('PA geom type:', pa.geom_type, 'is_valid:', pa.is_valid)

# Filter within Pacific plate (in 4326)
inside = gdf_eq[gdf_eq.geometry.within(pa)].copy()
print('earthquakes within Pacific plate:', len(inside))

# Project to metric CRS
METRIC = 'EPSG:4087'
inside_proj = inside.to_crs(METRIC)

# Pacific plate boundaries (all PA-* segments)
pa_b = bounds[bounds['Name'].str.contains('PA')]
pa_b_proj = pa_b.to_crs(METRIC)
boundary_geom = pa_b_proj.geometry.unary_union
print('PA boundary segments:', len(pa_b))

# Distance to boundary (meters -> km)
inside['distance_km'] = inside_proj.geometry.distance(boundary_geom) / 1000.0

# Sort
inside = inside.sort_values('distance_km', ascending=False)
print('\nTop 10 furthest earthquakes from Pacific plate boundary:')
print(inside[['id','place','magnitude','latitude','longitude','distance_km']].head(10).to_string())
