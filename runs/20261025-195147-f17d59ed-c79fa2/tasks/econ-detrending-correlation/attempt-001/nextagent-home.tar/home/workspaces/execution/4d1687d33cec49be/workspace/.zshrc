
. "$HOME/.local/bin/env"
