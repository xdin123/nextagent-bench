
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
import numpy as np
import re
from statsmodels.tsa.filters.hp_filter import hp_filter

def extract(path, valcol=1):
    df = pd.read_excel(path, header=None)
    annual = {}
    quarters = {}
    for i in range(len(df)):
        label = df.iat[i, 0]
        val = df.iat[i, valcol]
        if not isinstance(label, str):
            continue
        lab = label.strip()
        m_ann = re.match(r'^(\d{4})\.?$', lab)
        m_q2 = re.match(r'^(\d{4}):\s*(I{1,3}V?|IV)\s*p?\.$', lab)
        if m_ann and m_ann.group(1).isdigit():
            yr = int(m_ann.group(1))
            if isinstance(val, (int, float)) and not np.isnan(val):
                annual[yr] = float(val)
        elif m_q2:
            yr = int(m_q2.group(1))
            if isinstance(val, (int, float)) and not np.isnan(val):
                quarters.setdefault(yr, []).append(float(val))
    return annual, quarters

pce_ann, pce_q = extract("workspace/ERP-2025-table10.xls")
pfi_ann, pfi_q = extract("workspace/ERP-2025-table12.xls")

print("PCE annual years:", sorted(pce_ann.keys())[:5], "...", sorted(pce_ann.keys())[-3:])
print("PFI annual years:", sorted(pfi_ann.keys())[:5], "...", sorted(pfi_ann.keys())[-3:])
print("PCE 2024 quarters:", pce_q.get(2024))
print("PFI 2024 quarters:", pfi_q.get(2024))

years = list(range(1973, 2025))
pce = [pce_ann.get(y, np.mean(pce_q[y])) for y in years]
pfi = [pfi_ann.get(y, np.mean(pfi_q[y])) for y in years]

cpi = pd.read_excel("workspace/CPI.xlsx", header=0)
cpi_map = dict(zip(cpi.iloc[:,0].astype(int), cpi.iloc[:,1].astype(float)))
cpi_series = [cpi_map[y] for y in years]

real_pce = np.array(pce) / np.array(cpi_series)
real_pfi = np.array(pfi) / np.array(cpi_series)

trend_pce, cyc_pce = hp_filter(np.log(real_pce), lambd=100)
trend_pfi, cyc_pfi = hp_filter(np.log(real_pfi), lambd=100)

corr = np.corrcoef(cyc_pce, cyc_pfi)[0,1]
print("2024 PCE:", pce[-1], "2024 PFI:", pfi[-1])
print("CPI 1973:", cpi_series[0], "CPI 2024:", cpi_series[-1])
print("Correlation:", corr)
print("Rounded:", round(corr, 5))

with open("workspace/answer.txt", "w") as f:
    f.write(f"{corr:.5f}")
print("Wrote answer.txt")
