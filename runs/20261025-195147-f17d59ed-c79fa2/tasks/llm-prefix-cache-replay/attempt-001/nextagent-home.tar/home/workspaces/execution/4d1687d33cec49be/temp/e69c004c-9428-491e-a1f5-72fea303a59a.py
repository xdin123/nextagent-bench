
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import json
r = json.load(open("workspace/report.json"))
print({k: r[k] for k in r if k != "per_request"})
print("per_request entries:", len(r["per_request"]))
print("first 3:", r["per_request"][:3])
print("last 1:", r["per_request"][-1])
assert sum(x["prompt_tokens"] for x in r["per_request"]) == r["total_prompt_tokens"]
assert sum(x["hit_tokens"] for x in r["per_request"]) == r["total_hit_tokens"]
assert abs(r["overall_hit_rate"] - r["total_hit_tokens"]/r["total_prompt_tokens"]) < 1e-15
assert all(x["hit_tokens"] <= x["prompt_tokens"] for x in r["per_request"])
assert r["final_cache_blocks"] <= 4096
n = 0
seen = set()
for line in open("workspace/trace.jsonl"):
    line = line.strip()
    if line:
        n += 1
        seen.update(json.loads(line)["hash_ids"])
print("trace requests:", n, "distinct blocks:", len(seen))
print("OK")
