#!/usr/bin/env python3
"""Replay a KV prefix-cache trace through an S3FIFO block cache (per prefix-cache-replay skill)."""
import json
from collections import OrderedDict

with open("workspace/config.json") as f:
    cfg = json.load(f)

block_size = cfg["block_size"]
capacity = cfg["cache_capacity_blocks"]
policy = cfg["policy"]
assert policy == "S3FIFO", f"expected S3FIFO, got {policy}"
small_ratio = cfg["s3fifo"]["small_ratio"]
max_freq = cfg["s3fifo"]["max_freq"]

small_cap = round(capacity * small_ratio)   # canonical: round(), not int()
main_cap = capacity - small_cap
ghost_cap = main_cap

S = OrderedDict()  # hash -> freq (FIFO, tail = newest)
M = OrderedDict()  # hash -> freq
G = OrderedDict()  # hash -> None (metadata only)


def insert_to_G(h):
    if h in G:
        del G[h]
    elif len(G) >= ghost_cap:
        G.popitem(last=False)
    G[h] = None


def admit_to_M(h, freq):
    # second-chance drain until exactly one real eviction to G
    while len(M) >= main_cap:
        victim = next(iter(M))
        vf = M[victim]
        if vf >= 1:
            del M[victim]
            M[victim] = vf - 1  # requeue at tail
        else:
            del M[victim]
            insert_to_G(victim)
            break
    M[h] = freq


def admit_to_S(h):
    while len(S) >= small_cap:
        victim, vf = S.popitem(last=False)
        if vf >= 1:
            admit_to_M(victim, vf)  # freq preserved
        else:
            insert_to_G(victim)
    S[h] = 0


def resident(h):
    return h in S or h in M


total_prompt = 0
total_hit = 0
per_request = []

with open("workspace/trace.jsonl") as f:
    for idx, line in enumerate(f):
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        L = req["input_length"]
        hashes = req["hash_ids"]

        # 1) residency check at arrival: longest contiguous prefix
        k = 0
        for h in hashes:
            if resident(h):
                k += 1
            else:
                break
        hit_tokens = min(k * block_size, L)

        # 2) access every block in order (hits update freq; misses admit)
        for h in hashes:
            if h in S:
                S[h] = min(S[h] + 1, max_freq)
            elif h in M:
                M[h] = min(M[h] + 1, max_freq)
            elif h in G:
                del G[h]
                admit_to_M(h, 0)  # ghost fast-track, freq 0
            else:
                admit_to_S(h)

        total_prompt += L
        total_hit += hit_tokens
        per_request.append({"idx": idx, "prompt_tokens": L, "hit_tokens": hit_tokens})

final_blocks = len(S) + len(M)
report = {
    "total_requests": len(per_request),
    "total_prompt_tokens": total_prompt,
    "total_hit_tokens": total_hit,
    "overall_hit_rate": total_hit / total_prompt,
    "final_cache_blocks": final_blocks,
    "per_request": per_request,
}

with open("workspace/report.json", "w") as f:
    json.dump(report, f, indent=2)

# sanity checks
assert sum(r["hit_tokens"] for r in per_request) == total_hit
assert sum(r["prompt_tokens"] for r in per_request) == total_prompt
assert abs(report["overall_hit_rate"] - total_hit / total_prompt) == 0.0
assert final_blocks <= capacity
print(f"requests={len(per_request)} prompt={total_prompt} hit={total_hit} "
      f"rate={total_hit / total_prompt:.6f} final={final_blocks} "
      f"(S={len(S)} M={len(M)} G={len(G)})")
