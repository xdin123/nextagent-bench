import shutil, subprocess, glob, os

try:
    import PIL
    print("PIL", PIL.__version__)
except Exception as e:
    print("no PIL:", e)

print("soffice:", shutil.which("soffice") or shutil.which("libreoffice"))
print("fc-list:", shutil.which("fc-list"))

# search common font locations
found = []
for pat in ["/usr/share/fonts/**/arial*.ttf", "/usr/share/fonts/**/LiberationSans*.ttf",
            "/usr/share/fonts/**/*Arial*.ttf", "/usr/share/fonts/**/DejaVuSans*.ttf"]:
    found += glob.glob(pat, recursive=True)
print("fonts found:", found[:10])
