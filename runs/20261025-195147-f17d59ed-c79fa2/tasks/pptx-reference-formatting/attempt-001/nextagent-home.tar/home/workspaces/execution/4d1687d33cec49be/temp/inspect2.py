import re, glob, xml.etree.ElementTree as ET

print("=== presentation.xml sldSz ===")
data = open('temp/pptx-unpacked/ppt/presentation.xml').read()
m = re.search(r'<p:sldSz[^>]*/>', data)
print(m.group(0) if m else "not found")

print("\n=== presentation.xml.rels ===")
print(open('temp/pptx-unpacked/ppt/_rels/presentation.xml.rels').read())

print("\n=== slide2 rels ===")
print(open('temp/pptx-unpacked/ppt/slides/_rels/slide2.xml.rels').read())

print("\n=== layouts ===")
for i in range(1, 12):
    p = f'temp/pptx-unpacked/ppt/slideLayouts/slideLayout{i}.xml'
    d = open(p).read()
    name = re.search(r'<p:cSld name="([^"]*)"', d)
    types = sorted(set(re.findall(r'<p:ph type="([^"]*)"', d)))
    print(f"layout{i}: name={name.group(1) if name else '?'} ph_types={types}")

print("\n=== which layout each slide uses ===")
for i in range(1, 7):
    p = f'temp/pptx-unpacked/ppt/slides/_rels/slide{i}.xml.rels'
    d = open(p).read()
    m = re.search(r'slideLayouts/(slideLayout\d+\.xml)', d)
    print(f"slide{i} -> {m.group(1) if m else '?'}")
