import re, glob, xml.etree.ElementTree as ET

ns = {
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
}

for f in sorted(glob.glob('temp/pptx-unpacked/ppt/slides/slide*.xml'), key=lambda x: int(re.search(r'(\d+)', x).group(1))):
    tree = ET.parse(f)
    root = tree.getroot()
    print('=' * 80)
    print(f)
    for sp in root.iter('{http://schemas.openxmlformats.org/presentationml/2006/main}sp'):
        nv = sp.find('.//p:nvSpPr/p:cNvPr', ns)
        ph = sp.find('.//p:nvSpPr/p:nvPr/p:ph', ns)
        xfrm = sp.find('.//p:spPr/a:xfrm', ns)
        off = xfrm.find('a:off', ns) if xfrm is not None else None
        ext = xfrm.find('a:ext', ns) if xfrm is not None else None
        pos = (off.get('x'), off.get('y'), ext.get('cx'), ext.get('cy')) if off is not None else None
        phinfo = (ph.get('type'), ph.get('idx')) if ph is not None else None
        texts = []
        for t in sp.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}t'):
            texts.append(t.text or '')
        # run properties
        rprs = []
        for rpr in sp.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}rPr'):
            rprs.append({k: v for k, v in rpr.attrib.items()})
        print(f"  shape id={nv.get('id') if nv is not None else '?'} name={nv.get('name') if nv is not None else '?'} ph={phinfo} pos={pos}")
        print(f"    text: {texts!r}")
        if rprs:
            print(f"    rPr: {rprs}")
