#!/usr/bin/env python3
"""Step-test calibration of the HVAC room.

Excitation design: step heater power 0 -> 50% held for 120 s (240 samples at
dt = 0.5 s). 50% power gives a steady-state rise of ~K*50 ~ 6 C (to ~24 C),
well inside the 30 C safety limit, while 120 s ~ 3 time constants captures the
full first-order transient.
"""
import json
import sys

sys.path.insert(0, "workspace")
from hvac_simulator import HVACSimulator

CONFIG = "workspace/room_config.json"
HEATER_POWER = 50.0
DURATION = 120.0  # seconds


def main():
    sim = HVACSimulator(config_path=CONFIG)
    t0 = sim.reset()

    data = [{"time": 0.0, "temperature": round(t0, 4), "heater_power": 0.0}]
    for r in sim.run_open_loop(HEATER_POWER, DURATION):
        data.append({
            "time": r["time"],
            "temperature": r["temperature"],
            "heater_power": r["heater_power"],
        })

    log = {
        "phase": "calibration",
        "heater_power_test": HEATER_POWER,
        "data": data,
    }
    with open("workspace/calibration_log.json", "w") as f:
        json.dump(log, f, indent=2)

    print(f"Calibration complete: {len(data)} points over {data[-1]['time']} s")
    print(f"Initial T = {t0:.2f} C, final T = {data[-1]['temperature']:.2f} C")


if __name__ == "__main__":
    main()
