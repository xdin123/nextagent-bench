#!/usr/bin/env python3
"""Closed-loop PI control of the HVAC room to the 22.0 C setpoint.

Runs 160 s (>= 150 s required) with back-calculation anti-windup, then writes
control_log.json and metrics.json.
"""
import json

import numpy as np

import sys
sys.path.insert(0, "workspace")
from hvac_simulator import HVACSimulator

CONFIG = "workspace/room_config.json"
DURATION = 160.0  # seconds (requirement: >= 150 s)


def main():
    with open("workspace/tuned_gains.json") as f:
        g = json.load(f)
    Kp, Ki = float(g["Kp"]), float(g["Ki"])

    sim = HVACSimulator(config_path=CONFIG)
    sp = float(sim.get_setpoint())
    dt = float(sim.get_dt())

    T0 = sim.reset()
    integral = 0.0
    data = [{
        "time": 0.0,
        "temperature": round(T0, 4),
        "setpoint": sp,
        "heater_power": 0.0,
        "error": round(sp - T0, 4),
    }]

    meas = T0
    steps = int(DURATION / dt)
    for _ in range(steps):
        err = sp - meas
        integral += err * dt
        u_unclamped = Kp * err + Ki * integral
        u = float(np.clip(u_unclamped, 0.0, 100.0))
        integral -= (u_unclamped - u) / Kp * dt  # back-calculation anti-windup

        r = sim.step(u)
        meas = r["temperature"]
        data.append({
            "time": r["time"],
            "temperature": r["temperature"],
            "setpoint": sp,
            "heater_power": r["heater_power"],
            "error": round(sp - r["temperature"], 4),
        })

    with open("workspace/control_log.json", "w") as f:
        json.dump({"phase": "control", "setpoint": sp, "data": data}, f, indent=2)

    # ---- Metrics ----
    times = np.array([d["time"] for d in data])
    temps = np.array([d["temperature"] for d in data])
    t0_meas = float(temps[0])
    step = sp - t0_meas
    max_temp = float(np.max(temps))
    overshoot = max(0.0, (max_temp - sp) / step)

    # Rise time: 10% -> 90% of the step
    lo = t0_meas + 0.1 * step
    hi = t0_meas + 0.9 * step
    t10 = float(times[np.argmax(temps >= lo)]) if np.any(temps >= lo) else None
    t90 = float(times[np.argmax(temps >= hi)]) if np.any(temps >= hi) else None
    rise_time = float(t90 - t10) if (t10 is not None and t90 is not None) else None

    # Settling time: last time the measurement leaves +/-2% of setpoint
    band = 0.02 * sp
    outside = np.abs(temps - sp) > band
    settling_time = float(times[np.where(outside)[0][-1]]) if np.any(outside) else 0.0

    # Steady-state error: mean deviation over the final 20 s
    ss_mask = times >= (times[-1] - 20.0)
    ss_error = float(abs(np.mean(temps[ss_mask]) - sp))

    metrics = {
        "rise_time": round(rise_time, 2) if rise_time is not None else None,
        "overshoot": round(overshoot, 5),
        "settling_time": round(settling_time, 2),
        "steady_state_error": round(ss_error, 5),
        "max_temp": round(max_temp, 4),
    }
    with open("workspace/metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"Control run complete: {len(data)} points over {times[-1]} s")
    print(f"Initial T = {t0_meas:.2f} C, final T = {temps[-1]:.2f} C")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
