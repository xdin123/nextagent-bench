#!/usr/bin/env python3
"""Estimate first-order parameters (K, tau) from calibration step data.

Model: T(t) = T0 + K*u*(1 - exp(-t/tau)), u = calibration step amplitude.
T0 is fit as a free parameter so sensor noise on the initial reading does not
bias K and tau.
"""
import json

import numpy as np
from scipy.optimize import curve_fit

with open("workspace/calibration_log.json") as f:
    log = json.load(f)

u = float(log["heater_power_test"])
data = log["data"]

# Use the post-step portion of the data (heater power > 0)
t = np.array([d["time"] for d in data if d["heater_power"] > 0])
y = np.array([d["temperature"] for d in data if d["heater_power"] > 0])


def model(t, T0, K, tau):
    return T0 + K * u * (1.0 - np.exp(-t / tau))


# Initial guesses: T0 from first sample, K from final rise, tau from 63.2% point
T0_guess = float(y[0])
K_guess = max((float(y[-1]) - float(y[0])) / u, 1e-3)
rise = float(y[-1]) - float(y[0])
if rise > 0:
    tau_guess = float(t[np.argmin(np.abs(y - (y[0] + 0.632 * rise)))])
else:
    tau_guess = 30.0

popt, _ = curve_fit(
    model, t, y,
    p0=[T0_guess, K_guess, tau_guess],
    bounds=([10.0, 1e-3, 5.0], [26.0, 1.0, 300.0]),
)
T0_fit, K_fit, tau_fit = (float(v) for v in popt)

y_pred = model(t, *popt)
resid = y - y_pred
ss_res = float(np.sum(resid ** 2))
ss_tot = float(np.sum((y - np.mean(y)) ** 2))
r_squared = 1.0 - ss_res / ss_tot
fitting_error = float(np.sqrt(np.mean(resid ** 2)))

out = {
    "K": round(K_fit, 6),
    "tau": round(tau_fit, 3),
    "r_squared": round(r_squared, 5),
    "fitting_error": round(fitting_error, 5),
}
with open("workspace/estimated_params.json", "w") as f:
    json.dump(out, f, indent=2)

print(f"Fitted T0 = {T0_fit:.3f} C (initial reading {T0_guess:.3f} C)")
print(json.dumps(out, indent=2))
