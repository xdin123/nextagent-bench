#!/usr/bin/env python3
"""IMC tuning of a PI controller from the estimated first-order model.

For G(s) = K / (tau*s + 1):
    Kp = tau / (K * lambda)
    Ki = 1 / (K * lambda)
    Kd = 0

lambda = 0.5 * tau gives a closed-loop time constant of ~20 s, so the
settling time is ~4*lambda ~ 80 s, comfortably under the 120 s target, with
minimal overshoot (the IMC zero cancels the process pole).
"""
import json

with open("workspace/estimated_params.json") as f:
    p = json.load(f)

K = float(p["K"])
tau = float(p["tau"])

LAMBDA_FACTOR = 0.5
lam = LAMBDA_FACTOR * tau
Kp = tau / (K * lam)
Ki = 1.0 / (K * lam)

gains = {
    "Kp": round(Kp, 6),
    "Ki": round(Ki, 6),
    "Kd": 0.0,
    "lambda": round(lam, 3),
}
with open("workspace/tuned_gains.json", "w") as f:
    json.dump(gains, f, indent=2)

print(json.dumps(gains, indent=2))
