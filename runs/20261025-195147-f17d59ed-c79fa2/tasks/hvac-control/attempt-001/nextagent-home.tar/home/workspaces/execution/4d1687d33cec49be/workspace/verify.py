#!…/bin/env python3
"""Cross-check all pipeline outputs against the task requirements."""
import json

cal = json.load(open("workspace/calibration_log.json"))
est = json.load(open("workspace/estimated_params.json"))
tun = json.load(open("workspace/tuned_gains.json"))
ctl = json.load(open("workspace/control_log.json"))
met = json.load(open("workspace/metrics.json"))

checks = []
# Calibration requirements
checks.append(("calibration >=30s", cal["data"][-1]["time"] >= 30.0, cal["data"][-1]["time"]))
checks.append(("calibration >=20 points", len(cal["data"]) >= 20, len(cal["data"])))
checks.append(("calibration keys", set(cal) == {"phase", "heater_power_test", "data"}, sorted(cal)))
checks.append(("calibration point keys",
               all(set(d) == {"time", "temperature", "heater_power"} for d in cal["data"]), True))

# Control requirements
dur = ctl["data"][-1]["time"]
checks.append(("control duration >=150s", dur >= 150.0, dur))
checks.append(("control setpoint 22.0", ctl["setpoint"] == 22.0, ctl["setpoint"]))
checks.append(("control point keys",
               all(set(d) == {"time", "temperature", "setpoint", "heater_power", "error"}
                   for d in ctl["data"]), True))
checks.append(("heater within 0-100%",
               all(0.0 <= d["heater_power"] <= 100.0 for d in ctl["data"]), True))

# Performance targets
checks.append(("steady-state error <0.5C", met["steady_state_error"] < 0.5, met["steady_state_error"]))
checks.append(("settling time <120s", met["settling_time"] < 120.0, met["settling_time"]))
checks.append(("overshoot <10%", met["overshoot"] < 0.10, met["overshoot"]))
checks.append(("max temp <30C", met["max_temp"] < 30.0, met["max_temp"]))

# Cross-check metrics against raw control data
temps = [d["temperature"] for d in ctl["data"]]
sp = ctl["setpoint"]
checks.append(("max_temp matches data", abs(max(temps) - met["max_temp"]) < 1e-6, max(temps)))
final_err = abs(temps[-1] - sp)
checks.append(("final |error| <0.5C", final_err < 0.5, round(final_err, 4)))

ok = True
for name, passed, val in checks:
    print(f"{'PASS' if passed else 'FAIL'}  {name:32s} {val}")
    ok = ok and passed

print()
print("estimated_params:", est)
print("tuned_gains     :", tun)
print("metrics         :", met)
print()
print("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED")
