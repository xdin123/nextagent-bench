import fitz

doc = fitz.open("workspace/input/input.pdf")
page = doc[0]
d = page.get_text("rawdict")
for b in d["blocks"]:
    if b["type"] != 0:
        continue
    for l in b["lines"]:
        for s in l["spans"]:
            txt = "".join(c["c"] for c in s["chars"])
            if txt.strip() == "":
                continue
            # origin of first char = baseline
            o = s["chars"][0]["origin"]
            o_last = s["chars"][-1]["origin"]
            bbox = s["bbox"]
            print(f"{txt!r:45} origin0=({o[0]:.1f},{o[1]:.1f}) origin_last=({o_last[0]:.1f},{o_last[1]:.1f}) bbox=({bbox[0]:.1f},{bbox[1]:.1f},{bbox[2]:.1f},{bbox[3]:.1f}) size={s['size']:.1f} font={s['font']}")
