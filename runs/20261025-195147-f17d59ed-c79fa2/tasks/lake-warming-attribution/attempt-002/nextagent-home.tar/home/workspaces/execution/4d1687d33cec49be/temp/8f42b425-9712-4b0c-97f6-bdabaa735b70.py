
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import pandas as pd
from scipy import stats

df = pd.read_csv('workspace/data/water_temperature.csv')
years = df['Year'].values
values = df['WaterTemperature'].values
print(f"n = {len(values)}, years {years.min()}-{years.max()}")

# Parametric: linear regression
lr = stats.linregress(years, values)
print(f"LinRegress: slope={lr.slope:.6f}, p={lr.pvalue:.6f}, R2={lr.rvalue**2:.4f}")

# Non-parametric: Mann-Kendall / Sen's slope
try:
    import pymannkendall as mk
    res = mk.original_test(values)
    print(f"MK: slope={res.slope:.6f}, p={res.p:.6f}, trend={res.trend}")
except ImportError:
    print("pymannkendall not installed")
