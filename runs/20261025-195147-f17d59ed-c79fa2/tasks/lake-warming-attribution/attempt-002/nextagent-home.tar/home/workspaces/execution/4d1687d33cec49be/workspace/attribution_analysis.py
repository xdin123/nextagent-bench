import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from factor_analyzer import FactorAnalyzer

# ---------- Load and merge all data ----------
wt = pd.read_csv('workspace/data/water_temperature.csv')
clim = pd.read_csv('workspace/data/climate.csv')
land = pd.read_csv('workspace/data/land_cover.csv')
hydro = pd.read_csv('workspace/data/hydrology.csv')

df = wt.merge(clim, on='Year').merge(land, on='Year').merge(hydro, on='Year')
print(f"Merged: {len(df)} rows, years {df['Year'].min()}-{df['Year'].max()}")

# ---------- Category classification ----------
categories = {
    'Heat':   ['AirTempLake', 'Shortwave', 'Longwave'],
    'Flow':   ['Precip', 'Inflow', 'Outflow'],
    'Wind':   ['WindSpeedLake'],
    'Human':  ['DevelopedArea', 'AgricultureArea'],
}
pca_vars = [v for vs in categories.values() for v in vs]
print("Variables:", pca_vars)

X = df[pca_vars].values
y = df['WaterTemperature'].values

# ---------- Global PCA with varimax rotation ----------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

fa = FactorAnalyzer(n_factors=4, rotation='varimax')
fa.fit(X_scaled)
scores = fa.transform(X_scaled)

loadings = pd.DataFrame(fa.loadings_, index=pca_vars, columns=[f'PC{i+1}' for i in range(4)])
print("\n--- Factor loadings ---")
print(loadings.round(3))

eigenvalues, _ = fa.get_eigenvalues()
print(f"\nEigenvalues (unrotated): {np.round(eigenvalues, 3)}")

# ---------- Map each PC to its dominant category ----------
def pc_to_category(pc_idx):
    col = loadings.iloc[:, pc_idx]
    # For each category, sum absolute loadings of its variables
    cat_load = {cat: col[vars_].abs().sum() for cat, vars_ in categories.items()}
    return max(cat_load, key=cat_load.get), cat_load

pc_map = {}
for i in range(4):
    cat, cat_load = pc_to_category(i)
    pc_map[i] = cat
    print(f"PC{i+1} -> {cat} | category loading sums: " +
          ", ".join(f"{c}={v:.2f}" for c, v in sorted(cat_load.items(), key=lambda kv: -kv[1])))

# ---------- R² decomposition ----------
def calc_r2(X, y):
    model = LinearRegression()
    model.fit(X, y)
    y_pred = model.predict(X)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    return 1 - (ss_res / ss_tot)

full_r2 = calc_r2(scores, y)
print(f"\nFull model R²: {full_r2:.4f}")

pc_contribs = {}
for i in range(4):
    others = [j for j in range(4) if j != i]
    r2_without = calc_r2(scores[:, others], y)
    pc_contribs[i] = full_r2 - r2_without
    print(f"PC{i+1} ({pc_map[i]}): R² without = {r2_without:.4f}, contribution = {pc_contribs[i]:.4f}")

# If two PCs map to the same category, sum their per-PC contributions
cat_contribs = {}
for i in range(4):
    cat = pc_map[i]
    cat_contribs[cat] = cat_contribs.get(cat, 0.0) + pc_contribs[i]

print("\n--- Category contributions (R² units) ---")
for c, v in sorted(cat_contribs.items(), key=lambda kv: -kv[1]):
    print(f"{c}: {v:.4f}  ({v*100:.2f}%)")

# ---------- Dominant category ----------
dominant = max(cat_contribs, key=cat_contribs.get)
dominant_pct = cat_contribs[dominant] * 100
print(f"\nDominant category: {dominant} with {dominant_pct:.2f}%")

# ---------- Output ----------
import os
os.makedirs('workspace/output', exist_ok=True)
out = pd.DataFrame({'variable': [dominant], 'contribution': [round(dominant_pct, 2)]})
out.to_csv('workspace/output/dominant_factor.csv', index=False)
print("\nWrote workspace/output/dominant_factor.csv")
print(out)
