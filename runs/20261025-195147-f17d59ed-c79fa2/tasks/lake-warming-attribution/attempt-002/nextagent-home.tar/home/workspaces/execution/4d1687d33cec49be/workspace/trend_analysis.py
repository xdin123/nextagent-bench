import pandas as pd
from scipy import stats

df = pd.read_csv('workspace/data/water_temperature.csv')
years = df['Year'].values
values = df['WaterTemperature'].values
print(f"n = {len(values)}, years {years.min()}-{years.max()}")

# Parametric: linear regression
lr = stats.linregress(years, values)
print(f"LinRegress: slope={lr.slope:.6f}, p={lr.pvalue:.6f}, R2={lr.rvalue**2:.4f}")

# Non-parametric: Mann-Kendall / Sen's slope (preferred for environmental data)
try:
    import pymannkendall as mk
    res = mk.original_test(values)
    print(f"MK: slope={res.slope:.6f}, p={res.p:.6f}, trend={res.trend}")
    slope, pval = res.slope, res.p
except ImportError:
    print("pymannkendall not installed, falling back to linregress")
    slope, pval = lr.slope, lr.pvalue

import os
os.makedirs('workspace/output', exist_ok=True)
out = pd.DataFrame({'slope': [slope], 'p-value': [pval]})
out.to_csv('workspace/output/trend_result.csv', index=False)
print("Wrote workspace/output/trend_result.csv")
print(out)
