
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3, sys
from itertools import permutations, combinations
sys.path.insert(0, '.nextagent/skills/civ6lib/scripts')
from placement_rules import Tile, DistrictType, get_placement_rules, calculate_max_specialty_districts
from adjacency_rules import get_adjacency_calculator
from hex_utils import get_neighbors, hex_distance

conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
W = 44
feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()
TERRAIN_MAP = {'TERRAIN_GRASS':'GRASS','TERRAIN_PLAINS':'PLAINS','TERRAIN_GRASS_MOUNTAIN':'MOUNTAIN','TERRAIN_COAST':'COAST','TERRAIN_OCEAN':'OCEAN','TERRAIN_LAKE':'LAKE'}
tiles = {}
for pid, terr, imp in rows:
    x, y = pid % W, pid // W
    tname = TERRAIN_MAP.get(terr, terr)
    feat = feats.get(pid)
    rv = rivers.get(pid)
    river_edges = []
    if rv:
        if rv[0]: river_edges.append(1)
        if rv[1]: river_edges.append(3)
        if rv[2]: river_edges.append(2)
        if rv[3] and rv[3]>=0: river_edges.append(0)
        if rv[4] and rv[4]>=0: river_edges.append(5)
        if rv[5] and rv[5]>=0: river_edges.append(4)
    is_fp = feat == 'FEATURE_FLOODPLAINS_PLAINS'
    tiles[(x,y)] = Tile(x=x,y=y,terrain=tname,feature=feat,is_floodplains=is_fp,river_edges=river_edges)

# Land tiles (settleable + district-able): non-water, non-mountain, non-geothermal (for districts)
land_tiles = [(x,y) for (x,y),t in tiles.items() if not t.is_water and not t.is_mountain]
print(f"Land tiles: {len(land_tiles)}")
print(sorted(land_tiles))

# Max specialty districts for pop 9
print(f"Max specialty districts (pop 9): {calculate_max_specialty_districts(9)}")

# Theoretical max per district type on this map (upper bound, ignoring interactions)
# Campus: geothermal(2)+reef(2) only adjacent at (21,14). Max = 2+2+1(mtn)+2(2 jungle)+3(6 districts) = 10
# But realistic with 3 districts total: campus can get geothermal+reef+1mtn+2jungle+2districts = 7
# Holy Site: max mountain+forest. Best: (23,12) has 1 mtn + 3 forest = 1+1 = 2. (23,13) has 1 mtn + 2 forest = 1+1=2
# Commercial Hub: river(2) + 3 districts (6 adj) = 2+3 = 5 max, but with 3 districts total: 2+2=4 or 2+3=5
# So theoretical max with 3 districts: Campus 7 + HS 2 + Hub 4 = 13? But interactions matter.

# Let's do a proper search: enumerate all valid combos of 3 specialty districts + city center
# City center must be on land. Districts must be within 3 of CC, on land, non-geothermal, non-overlapping.

calc = get_adjacency_calculator(tiles)

# Candidate city centers: land tiles
cc_candidates = land_tiles

# For each CC, find valid district tiles (within 3, land, not geothermal, not CC)
def valid_district_tiles(cc, tiles):
    vt = []
    for (x,y),t in tiles.items():
        if t.is_water or t.is_mountain: continue
        if t.feature == 'FEATURE_GEOTHERMAL_FISSURE': continue
        if (x,y) == cc: continue
        if hex_distance(x,y,cc[0],cc[1]) > 3: continue
        vt.append((x,y))
    return vt

# District types to consider (specialty, one each)
dtypes = [DistrictType.CAMPUS, DistrictType.HOLY_SITE, DistrictType.COMMERCIAL_HUB,
          DistrictType.THEATER_SQUARE, DistrictType.INDUSTRIAL_ZONE, DistrictType.HARBOR]

best = (0, None)
best_list = []

# To keep it tractable, only consider CC candidates that are near the feature-rich area
# The island is small; let's just try all CC on land
for cc in cc_candidates:
    vdt = valid_district_tiles(cc, tiles)
    if len(vdt) < 3: continue
    # Try all combinations of 3 district tiles
    for combo in combinations(vdt, 3):
        # Try all assignments of 3 district types to 3 tiles
        for dts in permutations(dtypes, 3):
            placements = {cc: DistrictType.CITY_CENTER}
            for (dt, (x,y)) in zip(dts, combo):
                placements[(x,y)] = dt
            total, per = calc.calculate_total_adjacency(placements)
            if total > best[0]:
                best = (total, (cc, dict(zip(dts, combo))))
                best_list = [(total, cc, dict(zip([d.name for d in dts], list(combo))))]
            elif total == best[0] and total > 0:
                best_list.append((total, cc, dict(zip([d.name for d in dts], list(combo)))))

print(f"\nBest total: {best[0]}")
print(f"Best CC: {best[1][0]}")
print(f"Best districts: {best[1][1]}")
print(f"\nNumber of solutions with this score: {len(best_list)}")
for sol in best_list[:10]:
    print(f"  {sol[0]}: CC={sol[1]} districts={sol[2]}")
