
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3, sys
sys.path.insert(0, '.nextagent/skills/civ6lib/scripts')
from placement_rules import Tile, DistrictType, get_placement_rules
from adjacency_rules import get_adjacency_calculator
from hex_utils import get_neighbors, hex_distance

conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
W = 44
feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()
TERRAIN_MAP = {'TERRAIN_GRASS':'GRASS','TERRAIN_PLAINS':'PLAINS','TERRAIN_GRASS_MOUNTAIN':'MOUNTAIN','TERRAIN_COAST':'COAST','TERRAIN_OCEAN':'OCEAN','TERRAIN_LAKE':'LAKE'}
tiles = {}
for pid, terr, imp in rows:
    x, y = pid % W, pid // W
    tname = TERRAIN_MAP.get(terr, terr)
    feat = feats.get(pid)
    rv = rivers.get(pid)
    river_edges = []
    if rv:
        if rv[0]: river_edges.append(1)
        if rv[1]: river_edges.append(3)
        if rv[2]: river_edges.append(2)
        if rv[3] and rv[3]>=0: river_edges.append(0)
        if rv[4] and rv[4]>=0: river_edges.append(5)
        if rv[5] and rv[5]>=0: river_edges.append(4)
    is_fp = feat == 'FEATURE_FLOODPLAINS_PLAINS'
    tiles[(x,y)] = Tile(x=x,y=y,terrain=tname,feature=feat,is_floodplains=is_fp,river_edges=river_edges)

# Solution A: CC(21,13), Campus(21,14), Hub(22,14), HS(23,12)
placements_A = {
    (21,13): DistrictType.CITY_CENTER,
    (21,14): DistrictType.CAMPUS,
    (22,14): DistrictType.COMMERCIAL_HUB,
    (23,12): DistrictType.HOLY_SITE,
}
calc = get_adjacency_calculator(tiles)
total_A, per_A = calc.calculate_total_adjacency(placements_A)
print("=== Solution A: CC(21,13), Campus(21,14), Hub(22,14), HS(23,12) ===")
print(f"Total: {total_A}")
for name, res in per_A.items():
    print(f"  {name}: {res.total_bonus}")
    for k, v in res.breakdown.items():
        print(f"    {k}: count={v['count']} bonus={v['bonus']}")

# Validate
rules = get_placement_rules(tiles, city_center=(21,13), population=9)
for (x,y), dt in placements_A.items():
    if dt == DistrictType.CITY_CENTER: continue
    r = rules.validate_placement(dt, x, y, {k:v for k,v in placements_A.items() if (k,v)!=(x,y)})
    print(f"  {dt.name} at ({x},{y}): valid={r.valid} errors={r.errors}")

# Solution B: CC(21,13), Campus(21,14), Hub(22,14), HS(22,13) [original]
placements_B = {
    (21,13): DistrictType.CITY_CENTER,
    (21,14): DistrictType.CAMPUS,
    (22,14): DistrictType.COMMERCIAL_HUB,
    (22,13): DistrictType.HOLY_SITE,
}
total_B, per_B = calc.calculate_total_adjacency(placements_B)
print(f"\n=== Solution B: CC(21,13), Campus(21,14), Hub(22,14), HS(22,13) ===")
print(f"Total: {total_B}")
for name, res in per_B.items():
    print(f"  {name}: {res.total_bonus}")

# Solution C: CC(22,13), Campus(21,14), Hub(22,14), HS(23,12)
placements_C = {
    (22,13): DistrictType.CITY_CENTER,
    (21,14): DistrictType.CAMPUS,
    (22,14): DistrictType.COMMERCIAL_HUB,
    (23,12): DistrictType.HOLY_SITE,
}
total_C, per_C = calc.calculate_total_adjacency(placements_C)
print(f"\n=== Solution C: CC(22,13), Campus(21,14), Hub(22,14), HS(23,12) ===")
print(f"Total: {total_C}")
for name, res in per_C.items():
    print(f"  {name}: {res.total_bonus}")
