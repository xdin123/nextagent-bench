
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3, json
conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
W = 44
feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()
land = []
for pid, terr, imp in rows:
    if terr in ('TERRAIN_GRASS','TERRAIN_PLAINS','TERRAIN_GRASS_MOUNTAIN','TERRAIN_COAST'):
        x, y = pid % W, pid // W
        land.append({'id': pid, 'x': x, 'y': y, 'terrain': terr, 'imp': imp,
                     'feature': feats.get(pid),
                     'river': rivers.get(pid)})
land.sort(key=lambda t: (t['y'], t['x']))
for t in land:
    print(t)
print("total land+coast:", len(land))
print("land-only:", sum(1 for t in land if not t['terrain'].endswith('COAST')))
print("mountains:", [t['id'] for t in land if 'MOUNTAIN' in t['terrain']])
print("coast with feature:", [(t['id'],t['feature']) for t in land if t['terrain']=='TERRAIN_COAST' and t['feature']])
