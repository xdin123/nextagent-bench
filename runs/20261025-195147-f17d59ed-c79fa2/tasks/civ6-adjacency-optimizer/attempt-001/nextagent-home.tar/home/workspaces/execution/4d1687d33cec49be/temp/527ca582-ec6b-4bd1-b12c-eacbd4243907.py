
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3, sys
sys.path.insert(0, '.nextagent/skills/civ6lib/scripts')
from placement_rules import Tile, DistrictType
from adjacency_rules import get_adjacency_calculator
from hex_utils import get_neighbors

conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
W = 44
feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()
TERRAIN_MAP = {'TERRAIN_GRASS':'GRASS','TERRAIN_PLAINS':'PLAINS','TERRAIN_GRASS_MOUNTAIN':'MOUNTAIN','TERRAIN_COAST':'COAST','TERRAIN_OCEAN':'OCEAN','TERRAIN_LAKE':'LAKE'}
tiles = {}
for pid, terr, imp in rows:
    x, y = pid % W, pid // W
    tname = TERRAIN_MAP.get(terr, terr)
    feat = feats.get(pid)
    rv = rivers.get(pid)
    river_edges = []
    if rv:
        if rv[0]: river_edges.append(1)
        if rv[1]: river_edges.append(3)
        if rv[2]: river_edges.append(2)
        if rv[3] and rv[3]>=0: river_edges.append(0)
        if rv[4] and rv[4]>=0: river_edges.append(5)
        if rv[5] and rv[5]>=0: river_edges.append(4)
    is_fp = feat == 'FEATURE_FLOODPLAINS_PLAINS'
    tiles[(x,y)] = Tile(x=x,y=y,terrain=tname,feature=feat,is_floodplains=is_fp,river_edges=river_edges)

print("=== Neighbors of (23,12) with features ===")
for n in get_neighbors(23,12):
    t = tiles.get(n)
    print(f"  {n}: terrain={t.terrain if t else None} feature={t.feature if t else None} mountain={t.is_mountain if t else None}")

# Manually count forests adjacent to (23,12)
forest_count = 0
for n in get_neighbors(23,12):
    t = tiles.get(n)
    if t and t.feature:
        if 'FEATURE_FOREST' in t.feature:
            forest_count += 1
            print(f"  FOREST match: {n} -> {t.feature}")
print(f"Manual forest count for (23,12): {forest_count}")
