
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3, sys
from itertools import combinations, permutations
sys.path.insert(0, '.nextagent/skills/civ6lib/scripts')
from placement_rules import Tile, DistrictType, get_placement_rules, calculate_max_specialty_districts
from adjacency_rules import get_adjacency_calculator
from hex_utils import get_neighbors, hex_distance

conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
W = 44
feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()
TERRAIN_MAP = {'TERRAIN_GRASS':'GRASS','TERRAIN_PLAINS':'PLAINS','TERRAIN_GRASS_MOUNTAIN':'MOUNTAIN','TERRAIN_COAST':'COAST','TERRAIN_OCEAN':'OCEAN','TERRAIN_LAKE':'LAKE'}
tiles = {}
for pid, terr, imp in rows:
    x, y = pid % W, pid // W
    tname = TERRAIN_MAP.get(terr, terr)
    feat = feats.get(pid)
    rv = rivers.get(pid)
    river_edges = []
    if rv:
        if rv[0]: river_edges.append(1)
        if rv[1]: river_edges.append(3)
        if rv[2]: river_edges.append(2)
        if rv[3] and rv[3]>=0: river_edges.append(0)
        if rv[4] and rv[4]>=0: river_edges.append(5)
        if rv[5] and rv[5]>=0: river_edges.append(4)
    is_fp = feat == 'FEATURE_FLOODPLAINS_PLAINS'
    tiles[(x,y)] = Tile(x=x,y=y,terrain=tname,feature=feat,is_floodplains=is_fp,river_edges=river_edges)

calc = get_adjacency_calculator(tiles)
land = [(x,y) for (x,y),t in tiles.items() if not t.is_water and not t.is_mountain]

# Prune: only CC candidates within 3 of the feature cluster (features at x 20-24, y 11-15)
feat_tiles = [(21,13),(20,13),(20,14),(20,15),(22,11),(21,15),(23,11),(23,12),(23,13),(24,12)]
cc_cands = [c for c in land if any(hex_distance(c,f) <= 4 for f in feat_tiles)]
print(f"CC candidates: {len(cc_cands)}")

dtypes = [DistrictType.CAMPUS, DistrictType.HOLY_SITE, DistrictType.COMMERCIAL_HUB,
          DistrictType.THEATER_SQUARE, DistrictType.INDUSTRIAL_ZONE, DistrictType.HARBOR]

best = (0, None)
count_best = 0
for cc in cc_cands:
    vdt = [(x,y) for (x,y),t in tiles.items()
           if not t.is_water and not t.is_mountain
           and t.feature != 'FEATURE_GEOTHERMAL_FISSURE'
           and (x,y) != cc and hex_distance(x,y,cc[0],cc[1]) <= 3]
    # prune district tiles: keep only tiles that are adjacent to a feature/river OR adjacent to another vdt tile
    interesting = set()
    for (x,y) in vdt:
        for n in get_neighbors(x,y):
            t = tiles.get(n)
            if t and (t.feature or t.is_mountain or t.has_river):
                interesting.add((x,y))
                break
    for (x,y) in vdt:
        for n in get_neighbors(x,y):
            if n in vdt:
                interesting.add((x,y))
                break
    vdt2 = [t for t in vdt if t in interesting]
    for combo in combinations(vdt2, 3):
        for dts in permutations(dtypes, 3):
            placements = {cc: DistrictType.CITY_CENTER}
            for dt, (x,y) in zip(dts, combo):
                placements[(x,y)] = dt
            total, _ = calc.calculate_total_adjacency(placements)
            if total > best[0]:
                best = (total, (cc, {d.name: l for d, l in zip(dts, combo)}))
                count_best = 1
            elif total == best[0] and best[0] > 0:
                count_best += 1

print(f"BEST TOTAL: {best[0]}")
print(f"CC: {best[1][0]}, districts: {best[1][1]}")
print(f"Number of tied solutions: {count_best}")

# Also check 2-district and 1-district solutions can't beat it (they can't: max 2 districts = 7+3=10 < 12)
# And check 3 districts with different type sets already covered by permutations of 6 types
