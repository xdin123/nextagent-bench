
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3
conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
print("Map:", cur.execute("SELECT * FROM Map").fetchall())
print("MetaData:", cur.execute("SELECT * FROM MetaData").fetchall())
print("Terrain:", cur.execute("SELECT TerrainType, COUNT(*) FROM Plots GROUP BY 1 ORDER BY 2 DESC").fetchall())
print("Features:", cur.execute("SELECT FeatureType, COUNT(*) FROM PlotFeatures GROUP BY 1 ORDER BY 2 DESC").fetchall())
print("PlotAttributes:", cur.execute("SELECT Type, Name, COUNT(*) FROM PlotAttributes GROUP BY 1,2 ORDER BY 3 DESC").fetchall())
print("StartPositions:", cur.execute("SELECT * FROM StartPositions").fetchall())
print("PlotRivers sample:", cur.execute("SELECT * FROM PlotRivers").fetchall())
print("PlotCliffs:", cur.execute("SELECT * FROM PlotCliffs").fetchall())
