import sqlite3, sys, json
from itertools import combinations, permutations
sys.path.insert(0, '.nextagent/skills/civ6lib/scripts')
from placement_rules import Tile, DistrictType, get_placement_rules, calculate_max_specialty_districts
from adjacency_rules import get_adjacency_calculator
from hex_utils import get_neighbors, hex_distance

DB = 'workspace/_roots/data/maps/e2e_test_case_0.Civ6Map'
conn = sqlite3.connect(DB)
cur = conn.cursor()
W = 44
feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()
TERRAIN_MAP = {'TERRAIN_GRASS':'GRASS','TERRAIN_PLAINS':'PLAINS','TERRAIN_GRASS_MOUNTAIN':'MOUNTAIN','TERRAIN_COAST':'COAST','TERRAIN_OCEAN':'OCEAN','TERRAIN_LAKE':'LAKE'}
tiles = {}
for pid, terr, imp in rows:
    x, y = pid % W, pid // W
    tname = TERRAIN_MAP.get(terr, terr)
    feat = feats.get(pid)
    rv = rivers.get(pid)
    river_edges = []
    if rv:
        if rv[0]: river_edges.append(1)
        if rv[1]: river_edges.append(3)
        if rv[2]: river_edges.append(2)
        if rv[3] and rv[3]>=0: river_edges.append(0)
        if rv[4] and rv[4]>=0: river_edges.append(5)
        if rv[5] and rv[5]>=0: river_edges.append(4)
    is_fp = feat == 'FEATURE_FLOODPLAINS_PLAINS'
    tiles[(x,y)] = Tile(x=x,y=y,terrain=tname,feature=feat,is_floodplains=is_fp,river_edges=river_edges)

calc = get_adjacency_calculator(tiles)
land = [(x,y) for (x,y),t in tiles.items() if not t.is_water and not t.is_mountain]

feat_tiles = [(21,13),(20,13),(20,14),(20,15),(22,11),(21,15),(23,11),(23,12),(23,13),(24,12)]
cc_cands = [c for c in land if any(hex_distance(c[0],c[1],f[0],f[1]) <= 4 for f in feat_tiles)]
print("CC candidates:", len(cc_cands))

dtypes = [DistrictType.CAMPUS, DistrictType.HOLY_SITE, DistrictType.COMMERCIAL_HUB,
          DistrictType.THEATER_SQUARE, DistrictType.INDUSTRIAL_ZONE, DistrictType.HARBOR]

best = (0, None)
count_best = 0
for cc in cc_cands:
    vdt = [(x,y) for (x,y),t in tiles.items()
           if not t.is_water and not t.is_mountain
           and t.feature != 'FEATURE_GEOTHERMAL_FISSURE'
           and (x,y) != cc and hex_distance(x,y,cc[0],cc[1]) <= 3]
    interesting = set()
    for (x,y) in vdt:
        for n in get_neighbors(x,y):
            t = tiles.get(n)
            if t and (t.feature or t.is_mountain or t.has_river):
                interesting.add((x,y))
                break
    for (x,y) in vdt:
        for n in get_neighbors(x,y):
            if n in vdt:
                interesting.add((x,y))
                break
    vdt2 = [t for t in vdt if t in interesting]
    for combo in combinations(vdt2, 3):
        for dts in permutations(dtypes, 3):
            placements = {cc: DistrictType.CITY_CENTER}
            for dt, (x,y) in zip(dts, combo):
                placements[(x,y)] = dt
            total, _ = calc.calculate_total_adjacency(placements)
            if total > best[0]:
                best = (total, (cc, {d.name: list(l) for d, l in zip(dts, combo)}))
                count_best = 1
            elif total == best[0] and best[0] > 0:
                count_best += 1

print("BEST TOTAL:", best[0])
print("CC:", best[1][0], "districts:", best[1][1])
print("Tied solutions:", count_best)

# ---- Validate the best solution with the placement rules engine ----
cc = tuple(best[1][0])
districts = {k: v for k, v in best[1][1].items()}
rules = get_placement_rules(tiles, city_center=cc, population=9)
placements_map = {cc: DistrictType.CITY_CENTER}
all_ok = True
for name, (x, y) in districts.items():
    dt = DistrictType[name]
    existing = {k: v for k, v in placements_map.items() if k != (x, y)}
    r = rules.validate_placement(dt, x, y, existing)
    if not r.valid:
        all_ok = False
        print(f"INVALID: {name} at ({x},{y}): {r.errors}")
    placements_map[(x,y)] = dt
print("All placements valid:", all_ok)

# ---- Final library-confirmed adjacency breakdown ----
total, per = calc.calculate_total_adjacency(placements_map)
print("FINAL TOTAL (library):", total)
out = {}
for name, res in per.items():
    out[name] = res.total_bonus
    print(f"  {name}: {res.total_bonus}")
print("Sum check:", sum(out.values()), "==", total)

# ---- Write solution JSON ----
solution = {
    "city_center": list(cc),
    "placements": {k: list(v) for k, v in districts.items()},
    "adjacency_bonuses": {k: v for k, v in out.items() if k != 'CITY_CENTER'},
    "total_adjacency": total,
}
import os
os.makedirs('workspace/_roots/output', exist_ok=True)
with open('workspace/_roots/output/scenario_3.json', 'w') as f:
    json.dump(solution, f, indent=2)
print("WROTE workspace/_roots/output/scenario_3.json")
print(json.dumps(solution, indent=2))
