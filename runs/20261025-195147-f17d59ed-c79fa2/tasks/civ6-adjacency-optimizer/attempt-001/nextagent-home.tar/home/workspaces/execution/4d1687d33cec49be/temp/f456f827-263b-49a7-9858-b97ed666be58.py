
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3, json, sys
sys.path.insert(0, '.nextagent/skills/civ6lib/scripts')
from placement_rules import Tile, DistrictType, PlacementRules, get_placement_rules
from adjacency_rules import AdjacencyCalculator, get_adjacency_calculator
from hex_utils import get_neighbors, hex_distance

conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
W = 44

feats = dict(cur.execute("SELECT ID, FeatureType FROM PlotFeatures").fetchall())
rivers = {r[0]: r[1:] for r in cur.execute("SELECT * FROM PlotRivers").fetchall()}
rows = cur.execute("SELECT ID, TerrainType, IsImpassable FROM Plots").fetchall()

TERRAIN_MAP = {
    'TERRAIN_GRASS': 'GRASS', 'TERRAIN_PLAINS': 'PLAINS',
    'TERRAIN_GRASS_MOUNTAIN': 'MOUNTAIN', 'TERRAIN_COAST': 'COAST',
    'TERRAIN_OCEAN': 'OCEAN', 'TERRAIN_LAKE': 'LAKE',
}

tiles = {}
for pid, terr, imp in rows:
    x, y = pid % W, pid // W
    tname = TERRAIN_MAP.get(terr, terr)
    feat = feats.get(pid)
    rv = rivers.get(pid)
    river_edges = []
    if rv:
        if rv[0]: river_edges.append(1)
        if rv[1]: river_edges.append(3)
        if rv[2]: river_edges.append(2)
        if rv[3] and rv[3] >= 0: river_edges.append(0)
        if rv[4] and rv[4] >= 0: river_edges.append(5)
        if rv[5] and rv[5] >= 0: river_edges.append(4)
    is_fp = feat == 'FEATURE_FLOODPLAINS_PLAINS'
    tiles[(x, y)] = Tile(x=x, y=y, terrain=tname, feature=feat,
                         is_floodplains=is_fp, river_edges=river_edges)

# Verify adjacency relationships
print("=== Adjacency verification ===")
print(f"Campus (22,13) neighbors: {get_neighbors(22,13)}")
print(f"  Geothermal (21,13) adjacent? {(21,13) in get_neighbors(22,13)}")
print(f"  Mountain (22,11) adjacent? {(22,11) in get_neighbors(22,13)}")
print(f"  Jungle (20,13) adjacent? {(20,13) in get_neighbors(22,13)}")
print(f"  Jungle (20,15) adjacent? {(20,15) in get_neighbors(22,13)}")
print(f"  Reef (20,14) adjacent? {(20,14) in get_neighbors(22,13)}")
print(f"Holy Site (23,13) neighbors: {get_neighbors(23,13)}")
print(f"  Forest (23,11) adjacent? {(23,11) in get_neighbors(23,13)}")
print(f"  Forest (24,12) adjacent? {(24,12) in get_neighbors(23,13)}")
print(f"  Campus (22,13) adjacent? {(22,13) in get_neighbors(23,13)}")
print(f"  Hub (22,14) adjacent? {(22,14) in get_neighbors(23,13)}")
print(f"Hub (22,14) neighbors: {get_neighbors(22,14)}")
print(f"  Geothermal (21,13) adjacent? {(21,13) in get_neighbors(22,14)}")
print(f"  Campus (22,13) adjacent? {(22,13) in get_neighbors(22,14)}")
print(f"  Holy Site (23,13) adjacent? {(23,13) in get_neighbors(22,14)}")
print(f"  On river? {tiles[(22,14)].has_river} edges={tiles[(22,14)].river_edges}")
print(f"City Center (21,13) to Campus (22,13) dist: {hex_distance(21,13,22,13)}")
print(f"City Center (21,13) to Holy Site (23,13) dist: {hex_distance(21,13,23,13)}")
print(f"City Center (21,13) to Hub (22,14) dist: {hex_distance(21,13,22,14)}")

# Now run the library calculator on my candidate solution
placements = {
    (21,13): DistrictType.CITY_CENTER,
    (22,13): DistrictType.CAMPUS,
    (23,13): DistrictType.HOLY_SITE,
    (22,14): DistrictType.COMMERCIAL_HUB,
}
calc = get_adjacency_calculator(tiles)
total, per_district = calc.calculate_total_adjacency(placements)
print(f"\n=== Library calculation ===")
print(f"Total: {total}")
for name, res in per_district.items():
    print(f"  {name}: {res.total_bonus}")
    for k, v in res.breakdown.items():
        print(f"    {k}: count={v['count']} bonus={v['bonus']}")
