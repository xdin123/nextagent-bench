
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import sqlite3
conn = sqlite3.connect('workspace/_roots/data/maps/e2e_test_case_0.Civ6Map')
cur = conn.cursor()
for t in ['MetaData','Map','Plots','PlotAttributes','PlotRivers','PlotResources','PlotFeatures','PlotImprovements','Districts','Cities','DistrictAttributes','StartPositions']:
    cur.execute(f"PRAGMA table_info({t})")
    cols = cur.fetchall()
    print(f"== {t}: {[c[1] for c in cols]}")
    cur.execute(f"SELECT COUNT(*) FROM {t}")
    print("   rows:", cur.fetchone()[0])
