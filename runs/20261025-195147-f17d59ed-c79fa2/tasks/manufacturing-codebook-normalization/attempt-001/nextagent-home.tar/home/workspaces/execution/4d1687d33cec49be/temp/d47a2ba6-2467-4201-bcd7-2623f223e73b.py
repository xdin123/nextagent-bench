
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re
with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

rr = collections.Counter(r['raw_reason_text'] for r in rows)
total = len(rows)
# cumulative coverage
cum = 0
for i, (t, c) in enumerate(rr.most_common()):
    cum += c
    if i < 200 or cum/total < 0.999:
        pass
# how many templates needed for 99% coverage
cum = 0
for i, (t, c) in enumerate(rr.most_common(), 1):
    cum += c
    if cum/total >= 0.99:
        print(f"99% coverage with {i} distinct texts, total distinct {len(rr)}")
        break
# tail: texts with count 1
ones = sum(1 for t,c in rr.items() if c==1)
print("texts appearing once:", ones)
# show texts 40..120
print("\n--- ranks 40-130 ---")
for i, (t, c) in enumerate(rr.most_common(), 1):
    if 40 <= i <= 130:
        print(c, "|", t)
