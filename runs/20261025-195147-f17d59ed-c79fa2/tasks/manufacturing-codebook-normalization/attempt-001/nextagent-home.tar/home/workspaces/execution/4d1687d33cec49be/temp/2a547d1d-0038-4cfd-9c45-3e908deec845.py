
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re

with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

CAT_SIG = {
 'FIXTURE_CONTACT': ['fixture','pogo','接触不良','探针接触','reseat','接触不好','接触差','接触','重插后偶尔OK','sometimes passes'],
 'FLASH_FAIL': ['flash','烧录失败','写入失败','program','write','reflash','重烧','flahs','reflahs'],
 'COLD_SOLDER': ['cold solder','虚焊','浮高','intermittent','功能不稳','疑似虚','solder'],
 'OPEN': ['open','开路','像开路','开鲁'],
 'SHORT': ['short','短路','短露','桥连','possible bridge','bridge','像短路','连锡'],
 'LEAKAGE': ['hipot','leakage','漏电','绝缘不良','insulation','超规','漏點'],
 'MISSING': ['missing','少件','漏贴','少锡'],
 'ESD': ['esd','静电'],
 'BOOT_FAIL': ['boot','os fail','启动','卡logo','进不了系统','stuck','cannot boot','启动不了','开机'],
 'CHECKSUM_FAIL': ['crc','checksum','verify','校验','数据异常','程序包'],
 'VERSION_MISMATCH': ['version','版本不符','下错程序','fw版本','mismatch','wrong fw'],
 'CAL_DATA_FAIL': ['cal data','rf cal','校准数据','nv write','重校','recal'],
 'CONNECTOR_WEAR': ['connector','sma','插拔','insertion loss','loss大','磨损'],
 'CONTAMINATION': ['contamination','residue','助焊剂','污染','清洗'],
 'PROBE_WORN': ['probe worn','探针磨损','worn','换针'],
 'PRESSURE_MARK': ['pressure mark','压伤','pad damage'],
 'REVERSED': ['reversed','polarity','反向','装反','极性'],
 'CURRENT_HIGH': ['current high','icc','功耗高','静态电流','idle current','电流偏高'],
 'HIGH_RES': ['high_res'],
}
def top_cat(s):
    sl=s.lower(); best=None;bestn=-1
    for cat,sigs in CAT_SIG.items():
        n=sum(1 for x in sigs if x in sl)
        if n>bestn: bestn=n;best=cat
    return best if bestn>0 else None

# fail_code -> dominant category (using whole text top cat)
fc_cat = collections.defaultdict(collections.Counter)
for r in rows:
    c = top_cat(r['raw_reason_text'])
    fc_cat[r['fail_code']][c]+=1
print("fail_code -> dominant text category:")
for fc in sorted(fc_cat):
    top = fc_cat[fc].most_common(3)
    tot=sum(fc_cat[fc].values())
    print(f"  {fc:6s} n={tot:4d}  {top}")
