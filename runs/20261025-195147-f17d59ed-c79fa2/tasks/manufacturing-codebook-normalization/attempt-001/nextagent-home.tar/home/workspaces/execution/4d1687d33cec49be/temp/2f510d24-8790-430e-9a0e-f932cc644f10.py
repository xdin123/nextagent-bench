
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re
with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))
rr = collections.Counter(r['raw_reason_text'] for r in rows)
# Show count==1 texts (the noisy tail) - sample 60
ones = [t for t,c in rr.items() if c==1]
print("count==1 texts:", len(ones))
for t in ones[:60]:
    print("  ", t)
