
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re

with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

# Define atom variants (reason phrases) seen in data -> canonical (category, component)
ATOMS = {
 # (category, component or None)
 'SW_NODE OS (open) seen': ('OPEN','SW_NODE'), 'SW_NODE OS，像开路': ('OPEN','SW_NODE'),
 'SW_NODE OS (short) seen': ('SHORT','SW_NODE'), 'SW_NODE OS，像短路': ('SHORT','SW_NODE'),
 'SW_NODE open, suspect cold solder/missing solder': ('COLD_SOLDER','SW_NODE'), 'SW_NODE 开路，疑似虚焊/少锡': ('COLD_SOLDER','SW_NODE'),
 'SW_NODE short, possible solder bridge': ('SHORT','SW_NODE'), 'SW_NODE 短路，可能连锡/桥连': ('SHORT','SW_NODE'),
 'SW_NODE intermittent, suspect cold solder': ('COLD_SOLDER','SW_NODE'), 'SW_NODE 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','SW_NODE'),
 'VBUS_SNS short, possible solder bridge': ('SHORT','VBUS_SNS'), 'VBUS_SNS 短路，可能连锡/桥连': ('SHORT','VBUS_SNS'),
 'VBUS_SNS intermittent, suspect cold solder': ('COLD_SOLDER','VBUS_SNS'), 'VBUS_SNS 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','VBUS_SNS'),
 'idle current high, suspect partial short/component issue': ('CURRENT_HIGH',None), '静态电流偏高，疑似短路趋势/器件异常': ('CURRENT_HIGH',None),
 '治具/探针接触不良，重插后偶尔OK': ('FIXTURE_CONTACT',None), 'fixture contact unstable, reseat sometimes passes': ('FIXTURE_CONTACT',None),
 '治具/探针接處不良，重插后偶尔OK': ('FIXTURE_CONTACT',None), '治俱/探针接触不良，重插后偶尔OK': ('FIXTURE_CONTACT',None),
 '探针磨损导致接触差，建议换针': ('PROBE_WORN',None), 'probe worn causing bad contact, replace pin': ('PROBE_WORN',None),
 '烧录失败/写入失败，重烧不稳定': ('FLASH_FAIL',None), 'program/flash write failed, reflash unstable': ('FLASH_FAIL',None),
 'program/flahs write failed, reflahs unstable': ('FLASH_FAIL',None),
 '校验失败/CRC挂，疑似程序包或数据异常': ('CHECKSUM_FAIL',None), 'CRC/checksum verify failed, package/data issue': ('CHECKSUM_FAIL',None),
 '版本不符/下错程序，需确认FW版本': ('VERSION_MISMATCH',None), 'version mismatch, wrong FW written': ('VERSION_MISMATCH',None),
 'OS fail，启动不了': ('BOOT_FAIL',None), 'OS fail, cannot boot': ('BOOT_FAIL',None),
 'RF校准数据写读失败，重校仍挂': ('CAL_DATA_FAIL',None), 'RF cal data R/W failed, recal still NG': ('CAL_DATA_FAIL',None),
 'SMA连接器磨损，插拔损耗大': ('CONNECTOR_WEAR',None), 'SMA connector wear, insertion loss high': ('CONNECTOR_WEAR',None),
 '助焊剂残留/污染': ('CONTAMINATION',None), 'flux residue/contamination': ('CONTAMINATION',None),
 'HiPot 漏电超规，疑似绝缘不良/污染': ('LEAKAGE',None), 'HiPot leakage over limit, suspect insulation/contamination': ('LEAKAGE',None),
 'high_res': ('HIGH_RES',None), '高阻': ('HIGH_RES',None),
 # P2 components
 'R152_NET open, suspect cold solder/missing solder': ('COLD_SOLDER','R152'), 'R152_NET 开路，疑似虚焊/少锡': ('COLD_SOLDER','R152'),
 'R152_NET OS (open) seen': ('OPEN','R152'), 'R152_NET OS，像开路': ('OPEN','R152'),
 'R152_NET OS (short) seen': ('SHORT','R152'), 'R152_NET OS，像短路': ('SHORT','R152'),
 'R152_NET short, possible solder bridge': ('SHORT','R152'), 'R152_NET 短路，可能连锡/桥连': ('SHORT','R152'),
 'R152_NET intermittent, suspect cold solder': ('COLD_SOLDER','R152'), 'R152_NET 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','R152'),
 'I2C_SDA open, suspect cold solder/missing solder': ('COLD_SOLDER','I2C_SDA'), 'I2C_SDA 开路，疑似虚焊/少锡': ('COLD_SOLDER','I2C_SDA'),
 'I2C_SDA OS (open) seen': ('OPEN','I2C_SDA'), 'I2C_SDA OS，像开路': ('OPEN','I2C_SDA'),
 'I2C_SDA short, possible solder bridge': ('SHORT','I2C_SDA'), 'I2C_SDA 短路，可能连锡/桥连': ('SHORT','I2C_SDA'),
 'I2C_SDA intermittent, suspect cold solder': ('COLD_SOLDER','I2C_SDA'), 'I2C_SDA 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','I2C_SDA'),
 'I2C_SCL open, suspect cold solder/missing solder': ('COLD_SOLDER','I2C_SCL'), 'I2C_SCL 开路，疑似虚焊/少锡': ('COLD_SOLDER','I2C_SCL'),
 'I2C_SCL OS (open) seen': ('OPEN','I2C_SCL'), 'I2C_SCL OS，像开路': ('OPEN','I2C_SCL'),
 'I2C_SCL short, possible solder bridge': ('SHORT','I2C_SCL'), 'I2C_SCL 短路，可能连锡/桥连': ('SHORT','I2C_SCL'),
 'I2C_SCL intermittent, suspect cold solder': ('COLD_SOLDER','I2C_SCL'), 'I2C_SCL 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','I2C_SCL'),
 'SPI_MISO open, suspect cold solder/missing solder': ('COLD_SOLDER','SPI_MISO'), 'SPI_MISO 开路，疑似虚焊/少锡': ('COLD_SOLDER','SPI_MISO'),
 'SPI_MISO OS (open) seen': ('OPEN','SPI_MISO'), 'SPI_MISO OS，像开路': ('OPEN','SPI_MISO'),
 'SPI_MISO short, possible solder bridge': ('SHORT','SPI_MISO'), 'SPI_MISO 短路，可能连锡/桥连': ('SHORT','SPI_MISO'),
 'SPI_MISO intermittent, suspect cold solder': ('COLD_SOLDER','SPI_MISO'), 'SPI_MISO 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','SPI_MISO'),
 'SPI_MOSI open, suspect cold solder/missing solder': ('COLD_SOLDER','SPI_MOSI'), 'SPI_MOSI 开路，疑似虚焊/少锡': ('COLD_SOLDER','SPI_MOSI'),
 'SPI_MOSI OS (open) seen': ('OPEN','SPI_MOSI'), 'SPI_MOSI OS，像开路': ('OPEN','SPI_MOSI'),
 'RESET_N open, suspect cold solder/missing solder': ('COLD_SOLDER','RESET_N'), 'RESET_N 开路，疑似虚焊/少锡': ('COLD_SOLDER','RESET_N'),
 'RESET_N OS (open) seen': ('OPEN','RESET_N'), 'RESET_N OS，像开路': ('OPEN','RESET_N'),
 'SCAN_IDCODE open, suspect cold solder/missing solder': ('COLD_SOLDER','SCAN_IDCODE'), 'SCAN_IDCODE 开路，疑似虚焊/少锡': ('COLD_SOLDER','SCAN_IDCODE'),
 'SCAN_IDCODE OS (open) seen': ('OPEN','SCAN_IDCODE'), 'SCAN_IDCODE OS，像开路': ('OPEN','SCAN_IDCODE'),
 'U12_VDD 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','U12_VDD'), 'U12_VDD intermittent, suspect cold solder': ('COLD_SOLDER','U12_VDD'),
 'U12_VDD 短路，可能连锡/桥连': ('SHORT','U12_VDD'), 'U12_VDD short, possible solder bridge': ('SHORT','U12_VDD'),
 'U12_VDD OS (open) seen': ('OPEN','U12_VDD'), 'U12_VDD OS，像开路': ('OPEN','U12_VDD'),
 'BOUNDARY_SHORT 开路，疑似虚焊/少锡': ('COLD_SOLDER','BOUNDARY_SHORT'), 'BOUNDARY_SHORT open, suspect cold solder/missing solder': ('COLD_SOLDER','BOUNDARY_SHORT'),
 'BOUNDARY_SHORT 短路，可能连锡/桥连': ('SHORT','BOUNDARY_SHORT'), 'BOUNDARY_SHORT short, possible solder bridge': ('SHORT','BOUNDARY_SHORT'),
 'Idle_Current 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','Idle_Current'), 'Idle_Current intermittent, suspect cold solder': ('COLD_SOLDER','Idle_Current'),
 'ANT_FEED 功能不稳，疑似虚焊/浮高': ('COLD_SOLDER','ANT_FEED'), 'ANT_FEED intermittent, suspect cold solder': ('COLD_SOLDER','ANT_FEED'),
}
# Also typo variants
TYPO = {'疑似虚汉/少锡':'疑似虚焊/少锡'}

# For each atom, which products/stations/failcodes
atom_info = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
unmatched_texts = collections.Counter()
for r in rows:
    t = r['raw_reason_text']
    found = False
    for a in ATOMS:
        if a in t:
            found = True
            key = (a,)
            atom_info[key]['product'][r['product_id']] += 1
            atom_info[key]['station'][r['station']] += 1
            atom_info[key]['fail_code'][r['fail_code']] += 1
    if not found:
        unmatched_texts[t] += 1

print("=== ATOM x PRODUCT (product counts per atom) ===")
for a in sorted(ATOMS):
    prods = atom_info[(a,)]['product']
    if prods:
        print(f"  {a[:55]:55s} -> {dict(prods)}")
print("\n=== unmatched text count (no atom found):", sum(unmatched_texts.values()), "distinct:", len(unmatched_texts))
for t,c in unmatched_texts.most_common(25):
    print(f"   {c:4d} | {t}")
