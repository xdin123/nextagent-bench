
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re

with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

texts = [r['raw_reason_text'] for r in rows]

# Collect all distinct "tokens" separated by common delimiters: , / + ; space CJK
# First, let's see what kinds of whitespace and delimiters exist
delims = collections.Counter()
for t in texts:
    for ch in t:
        if ch in ' ,;/+&，、；;：:\u3000':
            delims[ch]+=1
print("delimiter char counts:", dict(delims))

# Split each text on delimiters into candidate atoms, strip, drop empties
atom_counter = collections.Counter()
for t in texts:
    # split on these
    parts = re.split(r'[,，/;；、+&\s]+', t)
    for p in parts:
        p = p.strip()
        if p:
            atom_counter[p]+=1

print("\ntotal distinct atoms (after split):", len(atom_counter))
print("\n--- all atoms with count >= 5 ---")
for a,c in atom_counter.most_common():
    if c>=5:
        print(f"{c:6d} | {a}")
