
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections
for p in ['P1_POWER','P2_CTRL','P3_RF']:
    with open(f'workspace/data/codebook_{p}.csv', newline='', encoding='utf-8') as f:
        cb = list(csv.DictReader(f))
    print(f"\n===== {p} ({len(cb)}) fields={list(cb[0].keys())} =====")
    for e in cb:
        comp = e.get('component_ref') or e.get('component') or ''
        print(f"  {e['code']:18s} | {e['category_lv2']:16s} | scope={e['station_scope']:22s} | kw={e['keywords_examples']}")
