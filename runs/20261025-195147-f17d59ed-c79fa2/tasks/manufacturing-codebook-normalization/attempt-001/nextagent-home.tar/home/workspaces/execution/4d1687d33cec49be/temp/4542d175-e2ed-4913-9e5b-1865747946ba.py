
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections
with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))
print("total rows:", len(rows))
print("columns:", list(rows[0].keys()))
print("\nproduct_id counts:", collections.Counter(r['product_id'] for r in rows))
print("\nstation counts:", collections.Counter(r['station'] for r in rows))
print("\nfail_code counts:", collections.Counter(r['fail_code'] for r in rows))
print("\ntest_item counts:", collections.Counter(r['test_item'] for r in rows))
print("\nengineer_id counts:", collections.Counter(r['engineer_id'] for r in rows))
print("\nresult counts:", collections.Counter(r['result'] for r in rows))
rr = collections.Counter(r['raw_reason_text'] for r in rows)
print("\ndistinct raw_reason_text:", len(rr))
# top 40 most common raw reason texts
for t, c in rr.most_common(40):
    print(c, "|", t)
