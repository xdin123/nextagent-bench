
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re, json

# Load codebooks
codebooks = {}
for p in ['P1_POWER','P2_CTRL','P3_RF']:
    with open(f'workspace/data/codebook_{p}.csv', newline='', encoding='utf-8') as f:
        cb = list(csv.DictReader(f))
    codebooks[p] = cb
    # check code uniqueness & station scopes
    codes = [e['code'] for e in cb]
    assert len(codes) == len(set(codes)), (p, "dup codes")
    cats = collections.Counter((e['category_lv2'], ';'.join(e['station_scope'].split(';')) if isinstance(e['station_scope'],str) else e['station_scope']) for e in cb)
    print(p, "entries:", len(cb), "distinct cats:", len(set(e['category_lv2'] for e in cb)))

with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

# product id anomalies
bad = [r for r in rows if r['product_id'] not in codebooks]
print("\nrows with product_id not in codebooks:", len(bad))
for r in bad[:10]:
    print("  ", r['record_id'], repr(r['product_id']), r['station'], r['raw_reason_text'][:60])

# station values
print("\nstations in logs:", sorted(set(r['station'] for r in rows)))
# stations in codebooks
allsc = set()
for p,cb in codebooks.items():
    for e in cb:
        allsc.update(e['station_scope'].split(';'))
print("stations in codebooks:", sorted(allsc))

# product x station distribution
print("\nproduct x station:")
ps = collections.Counter((r['product_id'], r['station']) for r in rows)
for k in sorted(ps):
    print("  ", k, ps[k])
