
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re

with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

# Load codebooks
codebooks = {}
for p in ['P1_POWER','P2_CTRL','P3_RF']:
    with open(f'workspace/data/codebook_{p}.csv', newline='', encoding='utf-8') as f:
        codebooks[p] = list(csv.DictReader(f))

# Build a keyword->category index per product (from keywords_examples + label + category)
def kw_index(cb):
    idx = {}
    for e in cb:
        kws = [k.strip().lower() for k in e['keywords_examples'].split(',')]
        kws += [e['category_lv2'].lower()]
        for k in kws:
            idx.setdefault(k, set()).add(e['category_lv2'])
    return idx

# Keyword signatures for each category (hand-derived from codebook keywords)
CAT_SIG = {
 'FIXTURE_CONTACT': ['fixture','pogo','接触不良','探针','reseat','unstable','contact','接触不好','接触差','建议换针','接触'],
 'FLASH_FAIL': ['flash','烧录失败','写入失败','program','write','reflash','重烧','write fail'],
 'COLD_SOLDER': ['cold solder','虚焊','浮高','solder','intermittent','功能不稳','疑似虚'],
 'OPEN': ['open','开路','像开路','开鲁'],
 'SHORT': ['short','短路','短露','桥连','possible bridge','bridge','像短路'],
 'LEAKAGE': ['hipot','leakage','漏电','绝缘不良','insulation','超规','漏點'],
 'MISSING': ['missing','少件','漏贴','少锡','missing solder'],
 'ESD': ['esd','静电'],
 'BOOT_FAIL': ['boot','os fail','启动','卡logo','进不了系统','stuck','cannot boot','启动不了','开机'],
 'CHECKSUM_FAIL': ['crc','checksum','verify','校验','数据异常','程序包'],
 'VERSION_MISMATCH': ['version','版本不符','下错程序','fw版本','mismatch','wrong fw'],
 'CAL_DATA_FAIL': ['cal data','rf cal','校准数据','nv write','重校','recal'],
 'CONNECTOR_WEAR': ['connector','sma','插拔','insertion loss','loss大','磨损'],
 'CONTAMINATION': ['contamination','residue','助焊剂','污染','清洗','flahs'],
 'PROBE_WORN': ['probe worn','探针磨损','pin','worn','换针','接處'],
 'PRESSURE_MARK': ['pressure mark','压伤','pad damage','压伤pad'],
 'REVERSED': ['reversed','polarity','反向','装反','极性'],
 'CURRENT_HIGH': ['current high','icc','功耗高','静态电流','idle current','电流偏高'],
 'HIGH_RES': ['high_res'],
}

def cat_of_text(t):
    tl = t.lower()
    scores = collections.Counter()
    for cat, sigs in CAT_SIG.items():
        for s in sigs:
            if s in tl:
                scores[cat]+=1
    return scores

# Check: for texts with " / " separator, do the blocks share the same top category?
multi = collections.Counter()
diff = 0
same = 0
examples_diff = []
for t,c in collections.Counter(r['raw_reason_text'] for r in rows).items():
    if ' / ' in t:
        blocks = t.split(' / ')
        tops = []
        for b in blocks:
            sc = cat_of_text(b)
            tops.append(sc.most_common(1)[0][0] if sc else None)
        if len(set(tops))>1:
            diff+=1
            if len(examples_diff)<15:
                examples_diff.append((t,tops))
        else:
            same+=1
print("texts with ' / ' separator:", same+diff)
print("  same top-category across blocks:", same)
print("  DIFFERENT top-category across blocks:", diff)
print("\n--- examples of DIFFERENT-category blocks ---")
for t,tops in examples_diff:
    print("  TOPS:", tops)
    print("   ", t)
