
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import csv, collections, re
with open('workspace/data/test_center_logs.csv', newline='', encoding='utf-8') as f:
    rd = csv.DictReader(f)
    print("columns:", rd.fieldnames)
    rows = list(rd)
print("n rows:", len(rows))
print("\nsample row:", rows[0])
# check record_id format
print("\nrecord_id samples:", [r['record_id'] for r in rows[:5]])
# check for any raw_reason_text with leading/trailing whitespace or odd chars
odd = 0
for r in rows:
    t = r['raw_reason_text']
    if t != t.strip():
        odd += 1
print("texts with leading/trailing ws:", odd)
# check meta-note frequency
meta = sum(1 for r in rows if 'Station=' in r['raw_reason_text'] or 'FailCode=' in r['raw_reason_text'])
print("texts with Station=/FailCode= meta:", meta)
# check result field values
print("\nresult values:", dict(collections.Counter(r['result'] for r in rows)))
# any empty raw_reason_text?
empty = sum(1 for r in rows if not r['raw_reason_text'].strip())
print("empty raw_reason_text:", empty)
