import os, sys, subprocess
print("CWD:", os.getcwd())
print("HOME:", os.environ.get("HOME"))
print("USER:", os.environ.get("USER"))
print("PYTHON:", sys.executable, sys.version)
# check pip
try:
    import importlib.util as u
    for m in ["torch","transformers","trl","datasets","accelerate","numpy","huggingface_hub","tokenizers","safetensors","bitsandbytes","deepspeed"]:
        print(m, "OK" if u.find_spec(m) else "MISSING")
except Exception as e:
    print("err", e)
