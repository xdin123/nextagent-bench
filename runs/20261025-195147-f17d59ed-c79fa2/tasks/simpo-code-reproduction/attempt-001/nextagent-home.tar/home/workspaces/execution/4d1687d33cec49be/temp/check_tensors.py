import torch, os
print("CWD:", os.getcwd())
p1 = "workspace/SimPO/unit_test/tensors/policy_chosen_logps.pt"
p2 = "workspace/SimPO/unit_test/tensors/policy_rejected_logps.pt"
c = torch.load(p1)
r = torch.load(p2)
print("chosen shape:", tuple(c.shape), "dtype:", c.dtype)
print("rejected shape:", tuple(r.shape), "dtype:", r.dtype)
print("chosen:", c.tolist())
print("rejected:", r.tolist())
print("chosen min/max:", c.min().item(), c.max().item())
print("rejected min/max:", r.min().item(), r.max().item())
print("cuda:", torch.cuda.is_available())
