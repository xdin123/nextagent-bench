import json, re

d = json.load(open("workspace/SimPO/paper.json"))
full = "\n".join(str(v) for v in d.values())

# Find sections mentioning the objective / loss
for kw in ["SimPO objective", "target reward margin", "length normaliz", "Eq. (4)", "Eq. (5)", "Eq. (6)", "Eq. (7)", "loss function", "we define the", "reward margin"]:
    print("==== KW:", kw)
    for m in re.finditer(re.escape(kw), full):
        s = max(0, m.start()-200)
        print(full[s:m.start()+400].replace("\n", " "))
        print("----")
    print()
