import json

d = json.load(open("workspace/SimPO/paper.json"))
print(type(d))
if isinstance(d, dict):
    for k, v in d.items():
        print("KEY:", k, type(v))
        s = str(v)
        print(s[:600])
        print("-----")
elif isinstance(d, list):
    print(len(d))
    for i, item in enumerate(d[:5]):
        print(i, str(item)[:500])
