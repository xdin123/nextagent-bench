
# NextAgent compatibility: Python 3.6 subprocess.run lacks capture_output/text.
import subprocess as _nextagent_subprocess

_nextagent_original_subprocess_run = _nextagent_subprocess.run

def _nextagent_subprocess_run_compat(*popenargs, **kwargs):
    if "capture_output" in kwargs:
        capture_output = kwargs.pop("capture_output")
        if capture_output:
            if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
                raise ValueError("stdout and stderr arguments may not be used with capture_output.")
            kwargs["stdout"] = _nextagent_subprocess.PIPE
            kwargs["stderr"] = _nextagent_subprocess.PIPE
    if "text" in kwargs:
        kwargs["universal_newlines"] = kwargs.pop("text")
    return _nextagent_original_subprocess_run(*popenargs, **kwargs)

_nextagent_subprocess.run = _nextagent_subprocess_run_compat

import struct, collections

path = 'workspace/scan_data.stl'
with open(path, 'rb') as f:
    data = f.read()

print('file size:', len(data))
header = data[:80]
print('header (repr):', repr(header[:60]))
count = struct.unpack('<I', data[80:84])[0]
print('triangle count:', count, 'expected size:', 84 + 50*count)

tris = []
off = 84
for i in range(count):
    rec = data[off:off+50]
    vals = struct.unpack('<12f', rec[:48])
    attr = struct.unpack('<H', rec[48:50])[0]
    v1 = vals[3:6]; v2 = vals[6:9]; v3 = vals[9:12]
    tris.append((v1, v2, v3, attr))
    off += 50

print('parsed up to offset:', off, 'of', len(data))

# coordinate ranges
xs = [c[0] for t in tris for c in t[:3]]
ys = [c[1] for t in tris for c in t[:3]]
zs = [c[2] for t in tris for c in t[:3]]
print('x range:', min(xs), max(xs))
print('y range:', min(ys), max(ys))
print('z range:', min(zs), max(zs))

# material id distribution
id_counts = collections.Counter(t[3] for t in tris)
print('material id distribution:', dict(id_counts))

# independent signed volume (divergence theorem)
def signed_vol(tri_list):
    s = 0.0
    for v1, v2, v3, _ in tri_list:
        # (v1 . (v2 x v3))
        cx = v2[1]*v3[2] - v2[2]*v3[1]
        cy = v2[2]*v3[0] - v2[0]*v3[2]
        cz = v2[0]*v3[1] - v2[1]*v3[0]
        s += v1[0]*cx + v1[1]*cy + v1[2]*cz
    return s / 6.0

total_signed = signed_vol(tris)
print('total signed volume (all tris):', total_signed, 'abs:', abs(total_signed))

# connected components via vertex hashing (exact float equality first)
vm = collections.defaultdict(list)
for i, t in enumerate(tris):
    for v in t[:3]:
        vm[(v[0], v[1], v[2])].append(i)

seen = set()
comps = []
for i in range(len(tris)):
    if i in seen:
        continue
    q = collections.deque([i]); seen.add(i); comp = []
    while q:
        c = q.popleft(); comp.append(c)
        for v in tris[c][:3]:
            for n in vm[(v[0], v[1], v[2])]:
                if n not in seen:
                    seen.add(n); q.append(n)
    comps.append(comp)

print('num components (exact vertex match):', len(comps))
comp_info = []
for comp in comps:
    vol = abs(signed_vol([tris[i] for i in comp]))
    ids = collections.Counter(tris[i][3] for i in comp)
    comp_info.append((vol, len(comp), ids))
comp_info.sort(reverse=True)
print('top 8 components by volume:')
for vol, n, ids in comp_info[:8]:
    print(f'  vol={vol:.6f} ntri={n} mat_ids={dict(ids)}')
print('sum of component volumes:', sum(c[0] for c in comp_info))

# check largest component material uniformity
largest = max(comp_info, key=lambda c: c[0])
comp_idx = None
for comp in comps:
    if abs(abs(signed_vol([tris[i] for i in comp])) - largest[0]) < 1e-12:
        comp_idx = comp
        break
ids_all = [tris[i][3] for i in comp_idx]
print('largest comp: ntri=', len(comp_idx), 'unique mat ids:', set(ids_all))
