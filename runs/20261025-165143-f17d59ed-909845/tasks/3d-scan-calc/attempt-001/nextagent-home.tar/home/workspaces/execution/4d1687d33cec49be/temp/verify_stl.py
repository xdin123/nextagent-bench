import struct, collections

path = 'workspace/scan_data.stl'
with open(path, 'rb') as f:
    data = f.read()

print('file size:', len(data))
print('header (repr):', repr(data[:60]))
count = struct.unpack('<I', data[80:84])[0]
print('triangle count:', count, 'expected size:', 84 + 50*count)

tris = []
off = 84
for i in range(count):
    rec = data[off:off+50]
    vals = struct.unpack('<12f', rec[:48])
    attr = struct.unpack('<H', rec[48:50])[0]
    v1 = vals[3:6]; v2 = vals[6:9]; v3 = vals[9:12]
    tris.append((v1, v2, v3, attr))
    off += 50

print('parsed up to offset:', off, 'of', len(data))

xs = [c[0] for t in tris for c in t[:3]]
ys = [c[1] for t in tris for c in t[:3]]
zs = [c[2] for t in tris for c in t[:3]]
print('x range:', min(xs), max(xs))
print('y range:', min(ys), max(ys))
print('z range:', min(zs), max(zs))

id_counts = collections.Counter(t[3] for t in tris)
print('material id distribution:', dict(id_counts))

def signed_vol(tri_list):
    s = 0.0
    for v1, v2, v3, _ in tri_list:
        cx = v2[1]*v3[2] - v2[2]*v3[1]
        cy = v2[2]*v3[0] - v2[0]*v3[2]
        cz = v2[0]*v3[1] - v2[1]*v3[0]
        s += v1[0]*cx + v1[1]*cy + v1[2]*cz
    return s / 6.0

total_signed = signed_vol(tris)
print('total signed volume (all tris):', total_signed, 'abs:', abs(total_signed))

# exact vertex match components
vm = collections.defaultdict(list)
for i, t in enumerate(tris):
    for v in t[:3]:
        vm[(v[0], v[1], v[2])].append(i)

seen = set()
comps = []
for i in range(len(tris)):
    if i in seen:
        continue
    q = collections.deque([i]); seen.add(i); comp = []
    while q:
        c = q.popleft(); comp.append(c)
        for v in tris[c][:3]:
            for n in vm[(v[0], v[1], v[2])]:
                if n not in seen:
                    seen.add(n); q.append(n)
    comps.append(comp)

print('num components (exact vertex match):', len(comps))
comp_info = []
for comp in comps:
    vol = abs(signed_vol([tris[i] for i in comp]))
    ids = collections.Counter(tris[i][3] for i in comp)
    comp_info.append((vol, len(comp), ids, comp))
comp_info.sort(key=lambda c: c[0], reverse=True)
print('top 8 components by volume:')
for vol, n, ids, _ in comp_info[:8]:
    print(f'  vol={vol:.6f} ntri={n} mat_ids={dict(ids)}')
print('sum of component volumes:', sum(c[0] for c in comp_info))

# largest component detail
largest_vol, largest_n, largest_ids, comp_idx = comp_info[0]
print('largest comp: ntri=', largest_n, 'unique mat ids:', set(largest_ids), 'vol=', largest_vol)

# check signed volume sign of largest (orientation sanity)
sv = signed_vol([tris[i] for i in comp_idx])
print('largest comp signed volume:', sv)

# bounding box of largest comp
lx = [c[0] for i in comp_idx for c in tris[i][:3]]
ly = [c[1] for i in comp_idx for c in tris[i][:3]]
lz = [c[2] for i in comp_idx for c in tris[i][:3]]
print('largest bbox x:', min(lx), max(lx), 'y:', min(ly), max(ly), 'z:', min(lz), max(lz))
bb_vol = (max(lx)-min(lx))*(max(ly)-min(ly))*(max(lz)-min(lz))
print('bbox volume:', bb_vol, 'fill ratio:', largest_vol/bb_vol)

# debris components: check their volumes and ids
print('all components (vol, ntri, ids):')
for vol, n, ids, _ in comp_info:
    print(f'  vol={vol:.4f} ntri={n} ids={dict(ids)}')
